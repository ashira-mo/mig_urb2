#first setwd

`%notin%` <- Negate(`%in%`)
library(pacman)
pacman::p_load(foreign, readxl, readstata13, car, stringi, readxl, gdata, labelled, ipumsr, readstata13, dplyr, tidyr, tidyverse, gmodels)
geomigp<-read.dta13("geomig1_p.dta") 
geolev1<-read_excel("geolev1.xlsx")
geolev2<-read.dta13("geolev2.dta")
geomig5<-read.dta13("geomig1_5.dta") %>%
  rename(code=var1, geomig1_5=var3) %>%
  mutate(code=as.integer(code))

#cameroon 2005, both 3-year and 5-year
# cm05id<-read.dta("/africa calibrate rates/3-year in/CM_2005.dta") 
# id<-cm05id$rownum
# cm05<-read.dta13("Cameroon2005.dta", convert.factors=T, generate.factors=T, nonint.factors=T) 
# WUP=0.485
# sample<-sum(cm05$perwt)
# lev1<-cm05 %>%
#   group_by(geolev1) %>%
#   summarise(pop=sum(perwt), 
#             urban=sum(perwt[urban=="Urban"]))
# total<-cm05 %>%
#   summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
#             weight=0.485/upert)
# lev1<-lev1 %>%
#   mutate(urban=urban/pop*total$weight, 
#          pop=pop/sample) %>%
#   arrange(-urban) %>%
#   mutate(ur=ifelse(urban<=0.5, 0, 1),  
#          usr=ifelse(urban<=0.5, 0, 
#                     ifelse(urban>0.5 & urban<=0.85, 1, 2)))
# cm05<-cm05 %>%
#   left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
#   rename(prov_act_ur=ur, prov_act_usr=usr) %>%
#   dplyr::left_join(geomig5, by="geomig1_5") %>%  
#   rename(geomig1_pcode=code) %>%
#   mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
#   left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
#   rename(prov_5_ur=ur, prov_5_usr=usr) %>%
#   mutate(caseid=(serial*100) + pernum,
#          #verify that geomig1_pcode is coded consistently with migratep
#          geomig1_pcode=ifelse(migrate5 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 120099, 
#                               ifelse(migrate5=="Abroad", 120097, 
#                                      ifelse(migrate5 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 120098, geomig1_pcode))),
#          prov_5_ur=ifelse(geomig1_pcode==120099, NA, 
#                           ifelse(geomig1_pcode==120097, 5, 
#                                  ifelse(geomig1_pcode %in% c(120098, NA), 9, prov_5_ur))), 
#          prov_5_usr=ifelse(geomig1_pcode==120099, NA,
#                            ifelse(geomig1_pcode==120097, 5,
#                                   ifelse(geomig1_pcode %in% c(120098, NA), 9, prov_5_usr))),
#          prov_act_cor=ifelse(geolev1==120097, 5, 
#                              ifelse(geolev1 %in% c(120098, 120099, NA), 9,
#                                     ifelse(geolev1==120002, 2, #120002 region centre sud where capital Yaounde situates, the capital 
#                                            ifelse(geolev1 %notin% c(120097, 120098, 120099, NA, 120002) & prov_act_ur==0, 0, 
#                                                   ifelse(geolev1 %notin% c(120097, 120098, 120099, NA, 120002) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
#          prov_5_cor=ifelse(geomig1_pcode==120099, NA,
#                            ifelse(geomig1_pcode==120002, 2, 
#                                   ifelse(geomig1_pcode!=120002 & prov_5_usr==5, 5,
#                                          ifelse(geomig1_pcode!=120002 & prov_5_usr==9, 9,
#                                                 ifelse(geomig1_pcode!=120002 & prov_5_usr==0, 0,
#                                                        ifelse(geomig1_pcode!=120002 & (prov_5_usr==1 | prov_5_usr==2), 3,NA)))))),
#          educ=as.integer(edattain),
#          educ=ifelse(educ==1, NA, 
#                      ifelse(educ==2, 0, 
#                             ifelse(educ==3, 1, 
#                                    ifelse(educ>=4 & educ<=5, 2, NA)))),
#          age=as.integer(age)-1,
#          age=ifelse(age>100, NA, age),
#          age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
#                          60:64=16;65:69=17;70:74=18;75:79=19;else=20")) %>%
#   arrange(serial, pernum) %>%
#   mutate(rownum=row_number(serial)) %>%
#   filter(rownum %in% id)
# write.dta(cm05, "/africa calibrate rates/5-year in/CM_2005.dta")
# write.dta(cm05, "/africa calibrate rates/5-year out/CM_2005.dta")
# 
#mozambique 2007, both 1-year and 5-year but 5-year does not have geomig1_5
# mz07id<-read.dta("/africa calibrate rates/1-year in/MZ_2007.dta") %>%
#   mutate(uniqueid=paste0(serial, "and", pernum))
# uniqueid<-mz07id$uniqueid
# mz07<-read.dta13("Mozambique2007.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
# WUP=0.304
# sample<-sum(mz07$perwt)
# lev1<-mz07 %>%
#   group_by(geolev1) %>%
#   summarise(pop=sum(perwt), 
#             urban=sum(perwt[urban=="Urban"]))
# total<-mz07 %>%
#   summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
#             weight=0.304/upert)
# lev1<-lev1 %>%
#   mutate(urban=urban/pop, 
#          pop=pop/sample) %>%
#   arrange(-urban)
# repeat {
#   print(WUP-sum(lev1$urban*lev1$pop))
#   lev1=lev1 %>%
#     mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
#            urban=urban*(1+weight),
#            uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
#            popa=ifelse(urban>1, pop, 0), 
#            popa=sum(popa), 
#            urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
#            urban=ifelse(urban>1, 1, urban))
#   if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
#     break
#   }
# }
# sum(lev1$urban*lev1$pop)
# lev1<-lev1 %>%
#   mutate(ur=ifelse(urban<=0.5, 0, 1),  
#          usr=ifelse(urban<=0.5, 0, 
#                     ifelse(urban>0.5 & urban<=0.85, 1, 2)))
# mz071<-mz07 %>%
#   left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
#   rename(prov_act_ur=ur, prov_act_usr=usr) %>%
#   dplyr::left_join(geomig5, by="geomig1_5") %>%  
#   rename(geomig1_pcode=code) %>%
#   mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
#   left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
#   rename(prov_5_ur=ur, prov_5_usr=usr) %>%
#   mutate(caseid=(serial*100) + pernum,
#          #verify that geomig1_pcode is coded consistently with migratep
#          geomig1_pcode=ifelse(migrate5 %in% c("NIU (Not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 508099, 
#                               ifelse(migrate5=="Abroad", 508097, 
#                                      ifelse(migrate5 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 508098, geomig1_pcode)))),
#          prov_5_ur=ifelse(geomig1_pcode==508099, NA, 
#                           ifelse(geomig1_pcode==508097, 5, 
#                                  ifelse(geomig1_pcode %in% c(508098, NA), 9, prov_5_ur))), 
#          prov_5_usr=ifelse(geomig1_pcode==508099, NA,
#                            ifelse(geomig1_pcode==508097, 5,
#                                   ifelse(geomig1_pcode %in% c(508098, NA), 9, prov_5_usr))),
#          prov_act_cor=ifelse(geolev1==508097, 5, 
#                              ifelse(geolev1 %in% c(508098, 508099, NA), 9,
#                                     ifelse(geolev1==508011, 2, #508011 maputo city, the capital 
#                                            ifelse(geolev1 %notin% c(508097, 508098, 508099, NA, 508011) & prov_act_usr==0, 0, 
#                                                   ifelse(geolev1 %notin% c(508097, 508098, 508099, NA, 508011) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
#          prov_5_cor=ifelse(geomig1_pcode==508099,NA,
#                            ifelse(geomig1_pcode==508011, 2,
#                                   ifelse(geomig1_pcode!=508011 & prov_5_usr==5, 5,
#                                          ifelse(geomig1_pcode!=508011 & prov_5_usr==9, 9,
#                                                 ifelse(geomig1_pcode!=508011 & prov_5_usr==0, 0,
#                                                        ifelse(geomig1_pcode!=508011 & (prov_5_usr==1 | prov_5_usr==2), 3,NA)))))),
#          educ=as.integer(edattain),
#          educ=ifelse(educ==1, NA, 
#                      ifelse(educ==2, 0, 
#                             ifelse(educ==3, 1, 
#                                    ifelse(educ>=4 & educ<=5, 2, NA)))),
#          age=as.integer(age)-1,
#          age=ifelse(age>100, NA, age),
#          age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
#                          60:64=16;65:69=17;70:74=18;75:79=19;else=20")) %>%
#   mutate(id=paste0(serial, "and", pernum)) %>%
#   filter(id %in% uniqueid)
# write.dta(mz07, "/africa calibrate rates/5-year in/MZ_2007.dta")
# write.dta(mz07, "/africa calibrate rates/5-year out/MZ_2007.dta")

#Ghana 2000
gh00<-read.dta13("Ghana2000.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.439
sample<-sum(gh00$perwt)
lev1<-gh00 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-gh00 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.439/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
gh00<-gh00 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig5, by="geomig1_5") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_5_ur=ur, prov_5_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate5 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 288099, 
                              ifelse(migrate5=="Abroad", 288097, #generated
                                     ifelse(migrate5 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 288098, geomig1_pcode))),
         prov_5_ur=ifelse(geomig1_pcode==288099, NA, 
                          ifelse(geomig1_pcode==288097, 5, 
                                 ifelse(geomig1_pcode %in% c(288098, NA), 9, prov_5_ur))), 
         prov_5_usr=ifelse(geomig1_pcode==288099, NA,
                           ifelse(geomig1_pcode==288097, 5,
                                  ifelse(geomig1_pcode %in% c(288098, NA), 9, prov_5_usr))),
         prov_act_cor=ifelse(geolev1==288097, 5, 
                             ifelse(geolev1 %in% c(288098, 288099, NA), 9,
                                    ifelse(geolev1==288003, 2, #288003 great accra, the capital 
                                           ifelse(geolev1 %notin% c(288097, 288098, 288099, NA, 288003) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(288097, 288098, 288099, NA, 288003) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_5_cor=ifelse(geomig1_pcode==288099, NA,
                           ifelse(geomig1_pcode==288003, 2, 
                                  ifelse(geomig1_pcode!=288003 & prov_5_usr==5, 5,
                                         ifelse(geomig1_pcode!=288003 & prov_5_usr==9, 9,
                                                ifelse(geomig1_pcode!=288003 & prov_5_usr==0, 0,
                                                       ifelse(geomig1_pcode!=288003 & (prov_5_usr==1 | prov_5_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
#%>%sample_frac(0.05)
write.dta(gh00, "/africa calibrate rates/5-year in/GH_2000.dta")
write.dta(gh00, "/africa calibrate rates/5-year out/GH_2000.dta")

#Mauritius 1990, geomig1_pcode merged with geolev1 instead of geomig5
mu90<-read.dta13("Mauritius1990.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.439
sample<-sum(mu90$perwt)
lev1<-mu90 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-mu90 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.439/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
mu90<-mu90 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geolev1, by=c("geomig1_5"="province")) %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_5_ur=ur, prov_5_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate5 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 480099, 
                              ifelse(migrate5=="Abroad", 480097, #generated
                                     ifelse(migrate5 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 480098, geomig1_pcode))),
         prov_5_ur=ifelse(geomig1_pcode==480099, NA, 
                          ifelse(geomig1_pcode==480097, 5, 
                                 ifelse(geomig1_pcode %in% c(480098, NA), 9, prov_5_ur))), 
         prov_5_usr=ifelse(geomig1_pcode==480099, NA,
                           ifelse(geomig1_pcode==480097, 5,
                                  ifelse(geomig1_pcode %in% c(480098, NA), 9, prov_5_usr))),
         prov_act_cor=ifelse(geolev1==480097, 5, 
                             ifelse(geolev1 %in% c(480098, 480099, NA), 9,
                                    ifelse(geolev1==480011, 2, #480011 port louis, the capital 
                                           ifelse(geolev1 %notin% c(480097, 480098, 480099, NA, 480011) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(480097, 480098, 480099, NA, 480011) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_5_cor=ifelse(geomig1_pcode==480099, NA,
                           ifelse(geomig1_pcode==480011, 2, 
                                  ifelse(geomig1_pcode!=480011 & prov_5_usr==5, 5,
                                         ifelse(geomig1_pcode!=480011 & prov_5_usr==9, 9,
                                                ifelse(geomig1_pcode!=480011 & prov_5_usr==0, 0,
                                                       ifelse(geomig1_pcode!=480011 & (prov_5_usr==1 | prov_5_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
#%>%sample_frac(0.05)
write.dta(mu90, "/africa calibrate rates/5-year in/MU_1990.dta")
write.dta(mu90, "/africa calibrate rates/5-year out/MU_1990.dta")

#Mauritius 2000, geomig1_pcode merged with geolev1
mu00<-read.dta13("Mauritius2000.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.427
sample<-sum(mu00$perwt)
lev1<-mu00 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-mu00 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.427/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
mu00<-mu00 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geolev1, by=c("geomig1_5"="province")) %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_5_ur=ur, prov_5_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate5 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 480099, 
                              ifelse(migrate5=="Abroad", 480097, #generated
                                     ifelse(migrate5 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 480098, geomig1_pcode))),
         prov_5_ur=ifelse(geomig1_pcode==480099, NA, 
                          ifelse(geomig1_pcode==480097, 5, 
                                 ifelse(geomig1_pcode %in% c(480098, NA), 9, prov_5_ur))), 
         prov_5_usr=ifelse(geomig1_pcode==480099, NA,
                           ifelse(geomig1_pcode==480097, 5,
                                  ifelse(geomig1_pcode %in% c(480098, NA), 9, prov_5_usr))),
         prov_act_cor=ifelse(geolev1==480097, 5, 
                             ifelse(geolev1 %in% c(480098, 480099, NA), 9,
                                    ifelse(geolev1==480011, 2, #480011 port louis, the capital 
                                           ifelse(geolev1 %notin% c(480097, 480098, 480099, NA, 480011) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(480097, 480098, 480099, NA, 480011) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_5_cor=ifelse(geomig1_pcode==480099, NA,
                           ifelse(geomig1_pcode==480011, 2, 
                                  ifelse(geomig1_pcode!=480011 & prov_5_usr==5, 5,
                                         ifelse(geomig1_pcode!=480011 & prov_5_usr==9, 9,
                                                ifelse(geomig1_pcode!=480011 & prov_5_usr==0, 0,
                                                       ifelse(geomig1_pcode!=480011 & (prov_5_usr==1 | prov_5_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"))
#%>%sample_frac(0.1)
write.dta(mu00, "/africa calibrate rates/5-year in/MU_2000.dta")
write.dta(mu00, "/africa calibrate rates/5-year out/MU_2000.dta")

#Mauritius 2011, geomig1_pcode merged with geolev1
mu11<-read.dta13("Mauritius2011.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.414
sample<-sum(mu11$perwt)
lev1<-mu11 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-mu11 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.414/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
mu11<-mu11 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geolev1, by=c("geomig1_5"="province")) %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_5_ur=ur, prov_5_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate5 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 480099, 
                              ifelse(migrate5=="Abroad", 480097, #generated
                                     ifelse(migrate5 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 480098, geomig1_pcode))),
         prov_5_ur=ifelse(geomig1_pcode==480099, NA, 
                          ifelse(geomig1_pcode==480097, 5, 
                                 ifelse(geomig1_pcode %in% c(480098, NA), 9, prov_5_ur))), 
         prov_5_usr=ifelse(geomig1_pcode==480099, NA,
                           ifelse(geomig1_pcode==480097, 5,
                                  ifelse(geomig1_pcode %in% c(480098, NA), 9, prov_5_usr))),
         prov_act_cor=ifelse(geolev1==480097, 5, 
                             ifelse(geolev1 %in% c(480098, 480099, NA), 9,
                                    ifelse(geolev1==480011, 2, #480011 port louis, the capital 
                                           ifelse(geolev1 %notin% c(480097, 480098, 480099, NA, 480011) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(480097, 480098, 480099, NA, 480011) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_5_cor=ifelse(geomig1_pcode==480099, NA,
                           ifelse(geomig1_pcode==480011, 2, 
                                  ifelse(geomig1_pcode!=480011 & prov_5_usr==5, 5,
                                         ifelse(geomig1_pcode!=480011 & prov_5_usr==9, 9,
                                                ifelse(geomig1_pcode!=480011 & prov_5_usr==0, 0,
                                                       ifelse(geomig1_pcode!=480011 & (prov_5_usr==1 | prov_5_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
#%>%sample_frac(0.1)
write.dta(mu11, "/africa calibrate rates/5-year in/MU_2011.dta")
write.dta(mu11, "/africa calibrate rates/5-year out/MU_2011.dta")

#Senegal 2002
sn02<-read.dta13("Senegal2002.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.406
sample<-sum(sn02$perwt)
lev1<-sn02 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-sn02 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.406/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
sn02<-sn02 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geolev1, by=c("geomig1_5"="province")) %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_5_ur=ur, prov_5_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate5 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 686099, #generated
                              ifelse(migrate5=="Abroad", 686097, #generated
                                     ifelse(migrate5 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 686098, geomig1_pcode))),
         prov_5_ur=ifelse(geomig1_pcode==686099, NA, 
                          ifelse(geomig1_pcode==686097, 5, 
                                 ifelse(geomig1_pcode %in% c(686098, NA), 9, prov_5_ur))), 
         prov_5_usr=ifelse(geomig1_pcode==686099, NA,
                           ifelse(geomig1_pcode==686097, 5,
                                  ifelse(geomig1_pcode %in% c(686098, NA), 9, prov_5_usr))),
         prov_act_cor=ifelse(geolev1==686097, 5, 
                             ifelse(geolev1 %in% c(686098, 686099, NA), 9,
                                    ifelse(geolev1==686001, 2, #480011 port louis, the capital 
                                           ifelse(geolev1 %notin% c(686097, 686098, 686099, NA, 686001) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(686097, 686098, 686099, NA, 686001) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_5_cor=ifelse(geomig1_pcode==686099, NA,
                           ifelse(geomig1_pcode==686001, 2, 
                                  ifelse(geomig1_pcode!=686001 & prov_5_usr==5, 5,
                                         ifelse(geomig1_pcode!=686001 & prov_5_usr==9, 9,
                                                ifelse(geomig1_pcode!=686001 & prov_5_usr==0, 0,
                                                       ifelse(geomig1_pcode!=686001 & (prov_5_usr==1 | prov_5_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
#%>%sample_frac(0.05)
write.dta(sn02, "/africa calibrate rates/5-year in/SN_2002.dta")
write.dta(sn02, "/africa calibrate rates/5-year out/SN_2002.dta")

#south africa 2001
za01<-read.dta13("Southafrica2001.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.574
sample<-sum(za01$perwt)
lev1<-za01 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-za01 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.574/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
za01<-za01 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig5, by="geomig1_5") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_5_ur=ur, prov_5_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate5 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 710099, 
                              ifelse(migrate5=="Abroad", 710097, 
                                     ifelse(migrate5 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 710098, geomig1_pcode))),
         prov_5_ur=ifelse(geomig1_pcode==710099, NA, 
                          ifelse(geomig1_pcode==710097, 5, 
                                 ifelse(geomig1_pcode %in% c(710098, NA), 9, prov_5_ur))), 
         prov_5_usr=ifelse(geomig1_pcode==710099, NA,
                           ifelse(geomig1_pcode==710097, 5,
                                  ifelse(geomig1_pcode %in% c(710098, NA), 9, prov_5_usr))),
         prov_act_cor=ifelse(geolev1==710097, 5, 
                             ifelse(geolev1 %in% c(710098, 710099, NA), 9,
                                    ifelse(geolev1==710001, 2, #710001 western cape where capital cape town situates, the capital 
                                           ifelse(geolev1 %notin% c(710097, 710098, 710099, NA, 710001) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(710097, 710098, 710099, NA, 710001) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_5_cor=ifelse(geomig1_pcode==710099, NA,
                           ifelse(geomig1_pcode==710001, 2, 
                                  ifelse(geomig1_pcode!=710001 & prov_5_usr==5, 5,
                                         ifelse(geomig1_pcode!=710001 & prov_5_usr==9, 9,
                                                ifelse(geomig1_pcode!=710001 & prov_5_usr==0, 0,
                                                       ifelse(geomig1_pcode!=710001 & (prov_5_usr==1 | prov_5_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
#%>%sample_frac(0.025)
write.dta(za01, "/africa calibrate rates/5-year in/ZA_2001.dta")
write.dta(za01, "/africa calibrate rates/5-year out/ZA_2001.dta")
