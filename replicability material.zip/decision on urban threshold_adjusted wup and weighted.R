#first setwd

`%notin%` <- Negate(`%in%`)
library(pacman)
pacman::p_load(foreign, cowplot, readxl, grid, gridExtra,gdata, labelled, ipumsr, readstata13, dplyr, tidyr, tidyverse, gmodels)
geomig5<-read.dta13("geomig1_5.dta") %>%
  dplyr::rename(code=var1, geomig1_5=var3) %>%
  mutate(code=as.integer(code))

#china82
china82<-read.dta13("china82-10.dta") %>%
  select(province, urban82, pop82)
WUP=0.209
ipums<-china82$urban82[1]
cn82<-china82 %>%
  slice(-1) %>%
  filter(!is.na(urban82)) %>%
  mutate(urban82=urban82/100) %>%
  arrange(-urban82) %>%
  mutate(province=factor(province,levels = province)) 
plot1<-ggplot()+ geom_bar(data=cn82, aes(province, urban82), width=cn82$pop82*5,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(cn82$urban82*cn82$pop82), color="red"), size=1.5)+
  geom_hline(aes(yintercept = WUP, color="blue"), size=1.5)+
  ggtitle("china 1982")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','adjusted IPUMS')) +
  theme(axis.text.x=element_blank(),
                axis.ticks.x=element_blank()) + theme(legend.position="none")

lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop82))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop82))

#china90
china90<-read.dta13("china82-10.dta") %>%
  select(province, urban90, pop90) %>%
  rename(urban=urban90, pop=pop90)
WUP=0.264
ipums<-china90$urban[1]
cn90<-china90 %>%
  slice(-1) %>%
  filter(!is.na(urban)) %>%
  arrange(-urban) %>%
  mutate(province=factor(province,levels = province))
repeat {
  print(WUP-sum(cn90$urban*cn90$pop))
  cn90=cn90 %>%
    mutate(weight=WUP-sum(cn90$urban*cn90$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(cn90$urban*cn90$pop) < 0.0000001){
    break
  }
}
sum(cn90$urban*cn90$pop)
plot2<-ggplot()+ geom_bar(data=cn90, aes(province, urban), width=cn90$pop*5,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(cn90$urban*cn90$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = WUP, color="blue"), size=1.5)+
  ggtitle("china 1990")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','adjusted IPUMS')) +
  theme(axis.text.x=element_blank(),
        axis.ticks.x=element_blank()) + theme(legend.position="none")
lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
order(lev1$urban-lag(lev1$urban))

#china00
china00<-read.dta("china00.dta")
total<-china00 %>%
  summarise(upert=sum(urban=="Urban")/length(urban), 
            weight=0.359/upert)
WUP=0.359
sample<-sum(china00$perwt)
cn00<-china00 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"])) %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(geolev1=factor(geolev1,levels = geolev1))
repeat {
  print(WUP-sum(cn00$urban*cn00$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(cn00$urban*cn00$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(cn00$urban*cn00$pop) < 0.0000001){
    break
  }
}
sum(cn00$urban*cn00$pop)
plot3<-ggplot()+ geom_bar(data=cn00, aes(geolev1, urban), width=cn00$pop*8,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(cn00$urban*cn00$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = 0.359, color="blue"), size=1.5)+
  ggtitle("china 2000")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','adjusted IPUMS')) +
  theme(axis.text.x=element_blank(),
        axis.ticks.x=element_blank()) + theme(legend.position="none")

lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))

lev1$urban00
order(lev1$urban00-lag(lev1$urban00))

#china10
# china10<-read.dta13("china82-10.dta") %>%
#   select(province, urban10, pop10) %>%
#   rename(urban=urban10, pop=pop10)
# WUP=0.492
# ipums<-china10$urban[1]
# cn10<-china10 %>%
#   slice(-1) %>%
#   filter(!is.na(urban)) %>%
#   mutate(urban=urban/100) %>%
#   arrange(-urban) %>%
#   mutate(province=factor(province,levels = province))
# repeat {
#   print(WUP-sum(cn10$urban*cn10$pop))
#   lev1=lev1 %>%
#     mutate(weight=WUP-sum(cn10$urban*cn10$pop), 
#            urban=urban*(1+weight),
#            uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
#            popa=ifelse(urban>1, pop, 0), 
#            popa=sum(popa), 
#            urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
#            urban=ifelse(urban>1, 1, urban))
#   if (WUP-sum(cn10$urban*cn10$pop) < 0.0000001){
#     break
#   }
# }
# sum(lev1$urban*lev1$pop)
# plot4<-ggplot()+ geom_bar(data=lev1, aes(province, urban), width=lev1$pop*5,stat="identity") +
#   xlab("geolev1") + ylab("% urban")+
#   geom_hline(aes(yintercept = sum(lev1$urban*lev1$pop), color="red"), size=1.5)+
#   geom_hline(aes(yintercept = WUP, color="blue"), size=1.5)+
#   ggtitle("china 2010")+ylim(0,1)+
#   scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
#                       values =c('red'='red','blue'='blue'), labels = c('WUP','adjusted IPUMS')) +
#   theme(axis.text.x=element_blank(),
#         axis.ticks.x=element_blank()) + theme(legend.position="none")
# 
# lev2<-lev1 %>%
#   mutate(thre1=ifelse(urban<0.5, 1, 
#                       ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
#          thre2=ifelse(urban<0.4, 1, 
#                       ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
# threshold1<-lev2 %>%
#   group_by(thre1) %>%
#   summarise(sum(pop))
# threshold2<-lev2 %>%
#   group_by(thre2) %>%
#   summarise(sum(pop))
# lev1$urban10
# order(lev1$urban10-lag(lev1$urban10))

#indo71, geolev1. length(unique(indo10$geomig1_5))==length(unique(indo05$mig1_5_id))
indo71<-read.dta("indo71.dta")
WUP=0.173
sample<-sum(indo71$perwt)
id71<-indo71 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-indo71 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.173/upert)
id71<-id71 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(geolev1=factor(geolev1 ,levels = geolev1))
plot4<-ggplot()+ geom_bar(data=id71, aes(geolev1, urban), width=id71$pop*8,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(id71$urban*id71$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = 0.173, color="blue"), size=1.5)+
  ggtitle("indonesia 1971")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','adjusted IPUMS')) +
  theme(axis.text.x=element_blank(),
        axis.ticks.x=element_blank()) + theme(legend.position="none")

lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))

lev1$uperc1
order(lev1$uperc1-lag(lev1$uperc1))

#indo76
indo76<-read.dta("indo76.dta")
WUP=0.199
sample<-sum(indo76$perwt)
id76<-indo76 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-indo76 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.199/upert)
id76<-id76 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(geolev1=factor(geolev1 ,levels = geolev1))
repeat {
  print(WUP-sum(id76$urban*id76$pop))
  id76=id76 %>%
    mutate(weight=WUP-sum(id76$urban*id76$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(id76$urban*id76$pop) < 0.0000001){
    break
  }
}
sum(id76$urban*id76$pop)
plot5<-ggplot()+ geom_bar(data=id76, aes(geolev1, urban), width=id76$pop*5,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(id76$urban*id76$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = 0.199, color="blue"), size=1.5)+
  ggtitle("indonesia 1976")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','adjusted IPUMS')) +
  theme(axis.text.x=element_blank(),
        axis.ticks.x=element_blank()) + theme(legend.position="none")

lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))

lev1$uperc1
order(lev1$uperc1-lag(lev1$uperc1))

#indo80, not necessary to adjust
indo80<-read.dta("indo80.dta")
sample<-sum(indo80$perwt)
id80<-indo80 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-indo80 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.221/upert)
id80<-id80 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(geolev1=factor(geolev1 ,levels = geolev1))
plot6<-ggplot()+ geom_bar(data=id80, aes(geolev1, urban), width=id80$pop*5,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(id80$urban*id80$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = 0.221, color="blue"), size=1.5)+
  ggtitle("indonesia 1980")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','IPUMS')) +
  theme(axis.text.x=element_blank(),
        axis.ticks.x=element_blank()) + theme(legend.position="none")

plot<-plot_grid(plot1, plot2, plot3, plot4, plot5, plot6, nrow=2)
legend_b <- get_legend(plot6 + theme(legend.position="bottom"))
p <- plot_grid(plot, legend_b, ncol = 1, rel_heights = c(1, .05))

lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$uperc1
order(lev1$uperc1-lag(lev1$uperc1))

#indo85
indo85<-read.dta("indo85.dta")
sample<-sum(indo85$perwt)
lev1<-indo85 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-indo85 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.261/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(geolev1=factor(geolev1,levels = geolev1))
ggplot()+ geom_bar(data=lev1, aes(geolev1, urban), width=lev1$pop*5,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(lev1$urban*lev1$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = 0.261, color="blue"), size=1.5)+
  ggtitle("indonesia 1985, weighted")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','adjusted IPUMS'))

lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$uperc1
order(lev1$uperc1-lag(lev1$uperc1))

#indo90, not necessary to adjust
indo90<-read.dta("indo90.dta")
sample<-sum(indo90$perwt)
total<-indo90 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.306/upert)
lev1<-indo90 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"])) %>%
  ungroup() %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(geolev1=factor(geolev1 ,levels = geolev1))
ggplot()+ geom_bar(data=lev1, aes(geolev1, urban), width=lev1$pop*5,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = total$upert, color="red"), size=1.5)+
  geom_hline(aes(yintercept = 0.306, color="blue"), size=1.5)+
  ggtitle("indonesia 1990, weighted")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','IPUMS'))
lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$uperc1
order(lev1$uperc1-lag(lev1$uperc1))

#indo95
indo95<-read.dta("indo95.dta")
sample<-sum(indo95$perwt)
lev1<-indo95 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-indo95 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.361/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(geolev1=factor(geolev1,levels = geolev1))
ggplot()+ geom_bar(data=lev1, aes(geolev1, urban), width=lev1$pop*5,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(lev1$urban*lev1$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = 0.361, color="blue"), size=1.5)+
  ggtitle("indonesia 1995, weighted")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','adjusted IPUMS'))
lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$uperc1
order(lev1$uperc1-lag(lev1$uperc1))

#indo00, not necessary to adjust
indo00<-read.dta("indo00.dta")
sample<-sum(indo00$perwt)
total<-indo00 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.42/upert)
lev1<-indo00 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"])) %>%
  ungroup() %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(geolev1=factor(geolev1,levels = geolev1))
ggplot()+ geom_bar(data=lev1, aes(geolev1, urban), width=lev1$pop*5,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(lev1$urban*lev1$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = 0.42, color="blue"), size=1.5)+
  ggtitle("indonesia 2000, weighted")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','IPUMS'))
lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$uperc1
order(lev1$uperc1-lag(lev1$uperc1))

#indo05
indo05<-read.dta("indo05.dta")
sample<-sum(indo05$perwt)
WUP=0.459
lev1<-indo05 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-indo05 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.459/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(geolev1=factor(geolev1 ,levels = geolev1))
#repeat the following line
lev1<-lev1 %>%
  mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
         urban=urban*(1+weight),
         uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
         popa=ifelse(urban>1, pop, 0), 
         popa=sum(popa), 
         urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
         urban=ifelse(urban>1, 1, urban))
sum(lev1$urban*lev1$pop)
ggplot()+ geom_bar(data=lev1, aes(geolev1, urban), width=lev1$pop*5,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(lev1$urban*lev1$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = 0.459, color="blue"), size=1.5)+
  ggtitle("indonesia 2005, weighted")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','adjusted IPUMS'))
lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$urban05
order(lev1$urban05-lag(lev1$urban05))

#indo10, not necessary to adjust
indo10<-read.dta("indo10.dta")
WUP=0.499
sample<-sum(indo10$perwt)
lev1<-indo10 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-indo10 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.499/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(geolev1=factor(geolev1 ,levels = geolev1))
#repeat the following line
lev1<-lev1 %>%
  mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
         urban=urban*(1+weight),
         uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
         popa=ifelse(urban>1, pop, 0), 
         popa=sum(popa), 
         urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
         urban=ifelse(urban>1, 1, urban))
sum(lev1$urban*lev1$pop)
ggplot()+ geom_bar(data=lev1, aes(geolev1, urban), width=lev1$pop*5,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(lev1$urban*lev1$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = 0.499, color="blue"), size=1.5)+
  ggtitle("indonesia 2010, weighted")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','IPUMS'))
lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$uperc1
order(lev1$uperc1-lag(lev1$uperc1))

#iran11, not necessary to adjust
iran11<-read.dta("iran11.dta")
sample<-sum(iran11$perwt)
total<-iran11 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.712/upert)
lev1<-iran11 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"])) %>%
  ungroup() %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(geolev1=factor(geolev1,levels = geolev1))
ggplot()+ geom_bar(data=lev1, aes(geolev1, urban), width=lev1$pop*5,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(lev1$urban*lev1$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = 0.712, color="blue"), size=1.5)+
  ggtitle("iran 2011, weighted")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','IPUMS'))
lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$uperc1
order(lev1$uperc1-lag(lev1$uperc1))

#iraq97
iraq97<-read.dta("iraq97.dta")
WUP=0.684
sample<-sum(iraq97$perwt)
lev1<-iraq97 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-iraq97 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.684/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(geolev1=factor(geolev1 ,levels = geolev1))
#repeat the following line
lev1<-lev1 %>%
  mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
         urban=urban*(1+weight),
         uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
         popa=ifelse(urban>1, pop, 0), 
         popa=sum(popa), 
         urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
         urban=ifelse(urban>1, 1, urban))
sum(lev1$urban*lev1$pop)
ggplot()+ geom_bar(data=lev1, aes(geolev1, urban), width=lev1$pop*5,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(lev1$urban*lev1$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = 0.684, color="blue"), size=1.5)+
  ggtitle("iraq 1997, weighted")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','adjusted IPUMS'))
lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$urban97
order(lev1$urban97-lag(lev1$urban97))

#israel83 on geolev2, not necessary to adjust
isra83<-read.dta("israel83.dta")
sample<-sum(isra83$perwt)
total<-isra83 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.896/upert)
lev1<-isra83 %>%
  group_by(geolev2) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"])) %>%
  ungroup() %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(geolev2=factor(geolev2,levels = geolev2))
ggplot()+ geom_bar(data=lev1, aes(geolev2, urban), width=lev1$pop*5,stat="identity") +
  xlab("geolev2") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(lev1$urban*lev1$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = 0.896, color="blue"), size=1.5)+
  ggtitle("israel 1983, weighted")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','IPUMS'))
lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$uperc2
order(lev1$uperc2-lag(lev1$uperc2))

#israel95 on geolev2, not necessary to adjust
isra95<-read.dta("israel95.dta")
sample<-sum(isra95$perwt)
total<-isra95 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.909/upert)
lev1<-isra95 %>%
  group_by(geolev2) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"])) %>%
  ungroup() %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(geolev2=factor(geolev2,levels = geolev2))
ggplot()+ geom_bar(data=lev1, aes(geolev2, urban), width=lev1$pop*5,stat="identity") +
  xlab("geolev2") + ylab("% urban")+
  geom_hline(aes(yintercept = total$upert, color="red"), size=1.5)+
  geom_hline(aes(yintercept = 0.909, color="blue"), size=1.5)+
  ggtitle("israel 1995")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','IPUMS'))
lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$uperc2
order(lev1$uperc2-lag(lev1$uperc2))

#kyrgz99 on geolev2
kyr99<-read.dta("kyrgz99.dta")
WUP=0.353
sample<-sum(kyr99$perwt)
lev1<-kyr99 %>%
  group_by(geolev2) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-kyr99 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.353/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(geolev2=factor(geolev2,levels = geolev2))
#repeat the following line
lev1<-lev1 %>%
  mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
         urban=urban*(1+weight),
         uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
         popa=ifelse(urban>1, pop, 0), 
         popa=sum(popa), 
         urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
         urban=ifelse(urban>1, 1, urban))
sum(lev1$urban*lev1$pop)
ggplot()+ geom_bar(data=lev1, aes(geolev2, urban), width=lev1$pop*10,stat="identity") +
  xlab("geolev2") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(lev1$urban*lev1$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = 0.353, color="blue"), size=1.5)+
  ggtitle("kyrgz 1999, weighted")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','adjusted IPUMS'))
lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$urban99
order(lev1$urban99-lag(lev1$urban99))

#malaysia 1991
malay91<-read.dta("malay91.dta")
sample<-sum(malay91$perwt)
lev1<-malay91 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-malay91 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.506/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(geolev1=factor(geolev1,levels = geolev1))
ggplot()+ geom_bar(data=lev1, aes(geolev1, urban), width=lev1$pop*5,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(lev1$urban*lev1$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = 0.506, color="blue"), size=1.5)+
  ggtitle("malaysia 1991, weighted")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','adjusted IPUMS'))
lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$uperc1
order(lev1$uperc1-lag(lev1$uperc1))

#malaysia 2000
malay00<-read.dta("malay00.dta")
sample<-sum(malay00$perwt)
lev1<-malay00 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-malay00 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.62/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(geolev1=factor(geolev1,levels = geolev1))
ggplot()+ geom_bar(data=lev1, aes(geolev1, urban), width=lev1$pop*5,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(lev1$urban*lev1$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = 0.62, color="blue"), size=1.5)+
  ggtitle("malaysia 2000, weighted")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','adjusted IPUMS'))
lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$uperc1
order(lev1$uperc1-lag(lev1$uperc1))

#mongolia90. IPUMS have microdata in 1989, but Natinoal Statistics Bureau of Mongolia provides urban population only since 1990.
mon90<-read.dta13("mongolia.dta") %>%
  rename(province=aimag) %>%
  select(province, urban90, pop90) %>%
  filter(!is.na(urban90)) %>%
  rename(urban=urban90, pop=pop90)
WUP=0.57
lev1<-mon90 %>%
  slice(-1) %>%
  filter(!is.na(urban)) %>%
  arrange(-urban) %>%
  mutate(urban=as.numeric(urban),
         pop=as.numeric(pop),
         urban=urban/pop, 
         pop=pop/sum(pop),
         province=factor(province,levels = province)) 
#repeat the following command
lev1<-lev1 %>%
  mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
         urban=urban*(1+weight),
         uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
         popa=ifelse(urban>1, pop, 0), 
         popa=sum(popa), 
         urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
         urban=ifelse(urban>1, 1, urban))
sum(lev1$urban*lev1$pop)
ggplot()+ geom_bar(data=lev1, aes(province, urban), width=lev1$pop*5,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(lev1$urban*lev1$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = WUP, color="blue"), size=1.5)+
  ggtitle("Mongolia 1990")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','adjusted IPUMS'))
lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$urban90
order(lev1$urban90-lag(lev1$urban90))

#mongolia2000
mon00<-read.dta13("mongolia.dta") %>%
  rename(province=aimag) %>%
  select(province, urban00, pop00) %>%
  filter(!is.na(urban00)) %>%
  rename(urban=urban00, pop=pop00)
WUP=0.571
lev1<-mon00 %>%
  slice(-1) %>%
  filter(!is.na(urban)) %>%
  arrange(-urban) %>%
  mutate(urban=as.numeric(urban),
         pop=as.numeric(pop),
         urban=urban/pop, 
         pop=pop/sum(pop),
         province=factor(province,levels = province)) 
#repeat the following command
lev1<-lev1 %>%
  mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
         urban=urban*(1+weight),
         uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
         popa=ifelse(urban>1, pop, 0), 
         popa=sum(popa), 
         urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
         urban=ifelse(urban>1, 1, urban))
sum(lev1$urban*lev1$pop)
ggplot()+ geom_bar(data=lev1, aes(province, urban), width=lev1$pop*5,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(lev1$urban*lev1$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = WUP, color="blue"), size=1.5)+
  ggtitle("Mongolia 2000")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','adjusted IPUMS'))
lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$urban00
order(lev1$urban00-lag(lev1$urban00))

#nepal 2001 on geolev2
nepal01<-read.dta("nepal01.dta")
WUP=0.139
sample<-sum(nepal01$perwt)
lev1<-nepal01 %>%
  group_by(geolev2) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-nepal01 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.139/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(geolev2=factor(geolev2,levels = geolev2))
#repeat the following line
lev1<-lev1 %>%
  mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
         urban=urban*(1+weight),
         uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
         popa=ifelse(urban>1, pop, 0), 
         popa=sum(popa), 
         urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
         urban=ifelse(urban>1, 1, urban))
sum(lev1$urban*lev1$pop)
ggplot()+ geom_bar(data=lev1, aes(geolev2, urban), width=lev1$pop*5,stat="identity") +
  xlab("geolev2") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(lev1$urban*lev1$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = 0.139, color="blue"), size=1.5)+
  ggtitle("nepal 2001, weighted")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','adjusted IPUMS'))
lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$uperc1
order(lev1$uperc1-lag(lev1$uperc1))

#nepal 2011 on geolev2
nepal11<-read.dta("nepal11.dta")
sample<-sum(nepal11$perwt)
lev1<-nepal11 %>%
  group_by(geolev2) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-nepal11 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.171/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(geolev2=factor(geolev2,levels = geolev2))
ggplot()+ geom_bar(data=lev1, aes(geolev2, urban), width=lev1$pop*5,stat="identity") +
  xlab("geolev2") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(lev1$urban*lev1$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = 0.171, color="blue"), size=1.5)+
  ggtitle("nepal 2011, weighted")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','adjusted IPUMS'))
lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$urban11
order(lev1$urban11-lag(lev1$urban11))

#philippine 90
phili90<-read.dta("philippine90.dta")
sample<-sum(phili90$perwt)
lev1<-phili90 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-phili90 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.47/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(geolev1=factor(geolev1,levels = geolev1))
ggplot()+ geom_bar(data=lev1, aes(geolev1, urban), width=lev1$pop*5,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(lev1$urban*lev1$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = 0.47, color="blue"), size=1.5)+
  ggtitle("philippine 1990, weighted")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','adjusted IPUMS'))
lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$uperc1
order(lev1$uperc1-lag(lev1$uperc1))

#philippines 2000
phili00<-read.dta13("philippines00.dta") %>%
  select(province, urban00, pop00) %>%
  mutate(urban00=as.numeric(as.character(urban00)),
         pop00=as.numeric(as.character(pop00)), 
         province=tolower(province)) %>%
  rename(urban=urban00, pop=pop00)
phili1<-geomig5 %>%
  filter(grepl("Philippines", geomig1_5, fixed=TRUE)) %>%
  mutate(geomig1_5=tolower(str_sub(geomig1_5, end=-25)))
dif<-as.character(setdiff(phili1$geomig1_5,phili00$province))[1:16]
lev1<-phili00 %>%
  slice(-1) %>%
  filter(!is.na(urban)) %>%
  mutate(province=tolower(province), 
         urban=urban/100,
         pop=pop/sum(pop))
popdif<-c(lev1$pop[lev1$province=="basilan"], 
          lev1$pop[lev1$province=="cagayan"]+lev1$pop[lev1$province=="batanes"], 
          lev1$pop[lev1$province=="davao"], lev1$pop[lev1$province=="iloilo"]+lev1$pop[lev1$province=="guimaras"],
          lev1$pop[lev1$province=="kalinga"]+lev1$pop[lev1$province=="apayao"], 
          lev1$pop[lev1$province=="leyte"]+lev1$pop[lev1$province=="biliran"], 
          lev1$pop[lev1$province=="maguindanao"]+lev1$pop[lev1$province=="cotabato city"],
          lev1$pop[lev1$province=="north cotabato"], lev1$pop[lev1$province=="samar (w samar)"], 
          lev1$pop[lev1$province=="sarangani"], lev1$pop[lev1$province=="surigao del norte"],
          lev1$pop[lev1$province=="zamboanga del norte"], lev1$pop[lev1$province=="zamboanga de sur"],
          lev1$pop[lev1$province=="city of mandaluyong"]+lev1$pop[lev1$province=="city of manikina"]+
            lev1$pop[lev1$province=="city of pasig"]+lev1$pop[lev1$province=="quezon ciy"]+lev1$pop[lev1$province=="san juan"],
          lev1$pop[lev1$province=="kalooan city"]+lev1$pop[lev1$province=="malabon"]+lev1$pop[lev1$province=="navotas"]+lev1$pop[lev1$province=="city of valenzuela"],
          lev1$pop[lev1$province=="city of las piñas"]+lev1$pop[lev1$province=="city of makati"]+
            lev1$pop[lev1$province=="city of muntinlupa"]+lev1$pop[lev1$province=="city of parañaque"]+
            lev1$pop[lev1$province=="pasay city"]+lev1$pop[lev1$province=="pateros"]+lev1$pop[lev1$province=="taguig"])
urbandif<-c(lev1$urban[lev1$province=="basilan"], 
            (lev1$pop[lev1$province=="cagayan"]*lev1$urban[lev1$province=="cagayan"]+lev1$pop[lev1$province=="batanes"]*lev1$urban[lev1$province=="batanes"])/popdif[2], 
            lev1$urban[lev1$province=="davao"], (lev1$pop[lev1$province=="iloilo"]*lev1$urban[lev1$province=="iloilo"]+lev1$pop[lev1$province=="guimaras"]*lev1$urban[lev1$province=="guimaras"])/popdif[4],
            (lev1$pop[lev1$province=="kalinga"]*lev1$urban[lev1$province=="kalinga"]+lev1$pop[lev1$province=="apayao"]*lev1$urban[lev1$province=="apayao"])/popdif[5], 
            (lev1$pop[lev1$province=="leyte"]*lev1$urban[lev1$province=="leyte"]+lev1$pop[lev1$province=="biliran"]*lev1$urban[lev1$province=="biliran"])/popdif[6], 
            (lev1$pop[lev1$province=="maguindanao"]*lev1$urban[lev1$province=="maguindanao"]+lev1$pop[lev1$province=="cotabato city"]*lev1$urban[lev1$province=="cotabato city"])/popdif[7],
            lev1$urban[lev1$province=="north cotabato"], lev1$urban[lev1$province=="samar (w samar)"], 
            lev1$urban[lev1$province=="sarangani"], lev1$urban[lev1$province=="surigao del norte"],
            lev1$urban[lev1$province=="zamboanga del norte"], lev1$urban[lev1$province=="zamboanga de sur"],
            (lev1$pop[lev1$province=="city of mandaluyong"]*lev1$urban[lev1$province=="city of mandaluyong"]+lev1$pop[lev1$province=="city of manikina"]*lev1$urban[lev1$province=="city of manikina"]+
               lev1$pop[lev1$province=="city of pasig"]*lev1$urban[lev1$province=="city of pasig"]+lev1$pop[lev1$province=="quezon ciy"]*lev1$urban[lev1$province=="quezon ciy"]+lev1$pop[lev1$province=="san juan"]*lev1$urban[lev1$province=="san juan"])/popdif[14],
            (lev1$pop[lev1$province=="kalooan city"]+lev1$pop[lev1$province=="malabon"]+lev1$pop[lev1$province=="navotas"]+lev1$pop[lev1$province=="city of valenzuela"])/popdif[15],
            lev1$pop[lev1$province=="city of las piñas"]*lev1$urban[lev1$province=="city of las piñas"]+lev1$pop[lev1$province=="city of makati"]*lev1$urban[lev1$province=="city of makati"]+
              (lev1$pop[lev1$province=="city of muntinlupa"]*lev1$urban[lev1$province=="city of muntinlupa"]+lev1$pop[lev1$province=="city of parañaque"]*lev1$urban[lev1$province=="city of parañaque"]+
                 lev1$pop[lev1$province=="pasay city"]*lev1$urban[lev1$province=="pasay city"]+lev1$pop[lev1$province=="pateros"]*lev1$urban[lev1$province=="pateros"]+lev1$pop[lev1$province=="taguig"]*lev1$urban[lev1$province=="taguig"])/popdif[16])
data<-as.data.frame(cbind(dif, urbandif, popdif)) %>%
  rename(province=dif, urban=urbandif, pop=popdif) %>%
  mutate(urban=as.numeric(levels(urban))[urban], 
         pop=as.numeric(levels(pop))[pop], 
         province=as.character(as.factor(province)))
lev1<-lev1 %>%
  filter(province %notin% c("basilan", "cagayan", "batanes", "davao", "iloilo", "guimaras", 
                            "kalinga", "apayao", "leyte", "biliran", "maguindanao", "cotabato city", "north cotabato", "samar (w samar)", "sarangani", 
                            "surigao del norte", "zamboanga del norte", "zamboanga de sur", "city of mandaluyong", 
                            "city of manikina", "city of pasig", "quezon ciy", "san juan", "kalooan city", "malabon", 
                            "navotas", "city of valenzuela", "city of las pi??as", "city of makati", "city of muntinlupa", 
                            "city of para??aque", "pasay city", "pateros", "taguig")) %>%
  bind_rows(data) %>%
  filter(province %notin% c("marawi city", "south cotabato", "compostela valley")) #these regions are from the external source not in ipums
WUP=0.461
lev1<-lev1 %>%
  mutate(weight=WUP/sum(lev1$urban*lev1$pop), 
         urban=urban*weight) %>%
  arrange(-urban) %>%
  mutate(province=factor(province,levels = province))
ggplot()+ geom_bar(data=lev1, aes(province, urban), width=lev1$pop*5,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(lev1$urban*lev1$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = WUP, color="blue"), size=1.5)+
  ggtitle("Philippines 2000")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','adjusted IPUMS'))
lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$urban00
order(lev1$urban00-lag(lev1$urban00))

#philippines 2010
phili10<-read_excel("phili10adjusted.xlsx", sheet=3)
WUP=0.453
lev1<-phili10 %>%
  filter(!is.na(urban10)) %>%
  arrange(-urban10) %>%
  mutate(province=factor(province,levels = province)) %>%
  rename(urban=urban10, pop=pop10)
lev1<-lev1 %>%
  mutate(weight=WUP/sum(lev1$urban*lev1$pop), 
         urban=urban*weight)
sum(lev1$urban*lev1$pop)
ggplot()+ geom_bar(data=lev1, aes(province, urban), width=lev1$pop*5,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(lev1$urban*lev1$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = WUP, color="blue"), size=1.5)+
  ggtitle("Philippines 2010")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','adjusted IPUMS'))
lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$urban10
order(lev1$urban10-lag(lev1$urban10))

#thailand70
thai70<-read.dta("thai70.dta")
sample<-sum(thai70$perwt)
lev1<-thai70 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-thai70 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.209/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(geolev1=factor(geolev1,levels = geolev1))

ggplot()+ geom_bar(data=lev1, aes(geolev1, urban), width=lev1$pop*14,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(lev1$urban*lev1$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = 0.209, color="blue"), size=1.5)+
  ggtitle("thailand 1970, weighted")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','adjusted IPUMS'))
lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$uperc1
order(lev1$uperc1-lag(lev1$uperc1))

#thailand80
thai80<-read.dta("thai80.dta")
WUP=0.268
sample<-sum(thai80$perwt)
lev1<-thai80 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-thai80 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.268/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(geolev1=factor(geolev1,levels = geolev1))
#repeat the following line
lev1<-lev1 %>%
  mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
         urban=urban*(1+weight),
         uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
         popa=ifelse(urban>1, pop, 0), 
         popa=sum(popa), 
         urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
         urban=ifelse(urban>1, 1, urban))
sum(lev1$urban*lev1$pop)
ggplot()+ geom_bar(data=lev1, aes(geolev1, urban), width=lev1$pop*14,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(lev1$urban*lev1$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = 0.268, color="blue"), size=1.5)+
  ggtitle("thailand 1980, weighted")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','adjusted IPUMS'))
lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$urban80
order(lev1$urban80-lag(lev1$urban80))

#thailand90
thai90<-read.dta("thai90.dta")
sample<-sum(thai90$perwt)
lev1<-thai90 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-thai90 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.294/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(geolev1=factor(geolev1,levels = geolev1))
ggplot()+ geom_bar(data=lev1, aes(geolev1, urban), width=lev1$pop*14,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(lev1$urban*lev1$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = 0.294, color="blue"), size=1.5)+
  ggtitle("thailand 1990, weighted")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','adjusted IPUMS'))
lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$uperc1
order(lev1$uperc1-lag(lev1$uperc1))

#thailand00, not necessary to adjust
thai00<-read.dta("thai00.dta")
sample<-sum(thai00$perwt)
total<-thai00 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.314/upert)
lev1<-thai00 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"])) %>%
  ungroup() %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(geolev1=factor(geolev1,levels = geolev1))
ggplot()+ geom_bar(data=lev1, aes(geolev1, urban), width=lev1$pop*14,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(lev1$urban*lev1$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = 0.314, color="blue"), size=1.5)+
  ggtitle("thailand 2000, weighted")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','IPUMS'))
lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$uperc1
order(lev1$uperc1-lag(lev1$uperc1))

#vietnam89
viet89<-read.dta("vietnam89.dta")
sample<-sum(viet89$perwt)
total<-viet89 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.199/upert)
lev1<-viet89 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"])) %>%
  ungroup() %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(geolev1=factor(geolev1,levels = geolev1))
ggplot()+ geom_bar(data=lev1, aes(geolev1, urban), width=lev1$pop*5,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(lev1$urban*lev1$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = 0.199, color="blue"), size=1.5)+
  ggtitle("vietnam 1989, weighted")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','adjusted IPUMS'))
lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$uperc1
order(lev1$uperc1-lag(lev1$uperc1))

#vietnam99
viet99<-read.dta("vietnam99.dta")
sample<-sum(viet99$perwt)
total<-viet99 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.238/upert)
lev1<-viet99 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"])) %>%
  ungroup() %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(geolev1=factor(geolev1,levels = geolev1))
ggplot()+ geom_bar(data=lev1, aes(geolev1, urban), width=lev1$pop*5,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(lev1$urban*lev1$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = 0.238, color="blue"), size=1.5)+
  ggtitle("vietnam 1999, weighted")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','adjusted IPUMS'))
lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$uperc1
order(lev1$uperc1-lag(lev1$uperc1))

#vietnam09
viet09<-read.dta("vietnam09.dta")
WUP=0.298
sample<-sum(viet09$perwt)
lev1<-viet09 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-viet09 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.298/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(geolev1=factor(geolev1,levels = geolev1))
#repeat the following line
lev1<-lev1 %>%
  mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
         urban=urban*(1+weight),
         uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
         popa=ifelse(urban>1, pop, 0), 
         popa=sum(popa), 
         urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
         urban=ifelse(urban>1, 1, urban))
sum(lev1$urban*lev1$pop)
ggplot()+ geom_bar(data=lev1, aes(geolev1, urban), width=lev1$pop*8,stat="identity") +
  xlab("geolev1") + ylab("% urban")+
  geom_hline(aes(yintercept = sum(lev1$urban*lev1$pop), color="red"), size=1.5)+
  geom_hline(aes(yintercept = 0.298, color="blue"), size=1.5)+
  ggtitle("vietnam 2009, weighted")+ylim(0,1)+
  scale_colour_manual(name = 'urbanisation rate', guide = 'legend',
                      values =c('red'='red','blue'='blue'), labels = c('WUP','adjusted IPUMS'))

lev2<-lev1 %>%
  mutate(thre1=ifelse(urban<0.5, 1, 
                      ifelse(urban>=0.5 & urban<0.85, 2, 3)), 
         thre2=ifelse(urban<0.4, 1, 
                      ifelse(urban>=0.4 & urban<0.8, 2, 3))) 
threshold1<-lev2 %>%
  group_by(thre1) %>%
  summarise(sum(pop))
threshold2<-lev2 %>%
  group_by(thre2) %>%
  summarise(sum(pop))
lev1$urban09
order(lev1$urban09-lag(lev1$urban09))