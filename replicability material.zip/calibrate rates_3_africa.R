#first setwd

`%notin%` <- Negate(`%in%`)
library(pacman)
pacman::p_load(foreign, data.table, dplyr, readstata13)
geomigp<-read.dta13("geomig1_p.dta") 
geolev1<-read_excel("geolev1.xlsx")
geolev2<-read.dta13("geolev2.dta")
geomigp_rw<-read.dta("geomigp_rw.dta") %>%
  rename(country=COUNTRY, year=YEAR, sample=SAMPLE, serial=SERIAL, pernum=PERNUM, geo1_rw=MIG1ALT_P_RW) %>%
  mutate(country="Rwanda", year=as.character(year), geo1_rw=as.character(geo1_rw)) %>%
  rename(geomig1_p=geo1_rw)

#benin 1979, external source 1977, combined ipums regions to be compatible with that of external source
external<-read.dta13("/external source/africa/benin77.dta") %>%
  mutate(urban=urbanpopulation/totalpopulation, pop=totalpopulation/sum(totalpopulation)) %>%
  bind_cols(geolev1=c(204002, 204003, 204004, 204009, 204012, 204010))
bj79<-read.dta13("Benin1979.dta", convert.factors=T, generate.factors=T, nonint.factors=T) %>%
  mutate(geolev1=ifelse(geolev1==204001, 204004, 
                        ifelse(geolev1==204005, 204012, 
                               ifelse(geolev1==204006, 204009, 
                                      ifelse(geolev1==204007, 204002, 
                                             ifelse(geolev1==204008, 204003, 
                                                    ifelse(geolev1==204011, 204010, geolev1)))))))
WUP=0.267
sum(external$urban*external$pop)
lev1<-external
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),
         usr=ifelse(urban<=0.5, 0,
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
bj79<-bj79 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode),
         geomig1_pcode=ifelse(geomig1_pcode==204001, 204004, 
                        ifelse(geomig1_pcode==204005, 204012, 
                               ifelse(geomig1_pcode==204006, 204009, 
                                      ifelse(geomig1_pcode==204007, 204002, 
                                             ifelse(geomig1_pcode==204008, 204003, 
                                                    ifelse(geomig1_pcode==204011, 204010, geomig1_pcode))))))) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 204099, #generated
                              ifelse(migratep=="Abroad", 204097, #generated
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 204098, geomig1_pcode))),
         prov_3_ur=ifelse(geomig1_pcode==204099, NA,
                          ifelse(geomig1_pcode==204097, 5,
                                 ifelse(geomig1_pcode %in% c(204098, NA), 9, prov_3_ur))),
         prov_3_usr=ifelse(geomig1_pcode==204099, NA,
                           ifelse(geomig1_pcode==204097, 5,
                                  ifelse(geomig1_pcode %in% c(204098, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==204097, 5,
                             ifelse(geolev1 %in% c(204098, 204099, NA), 9,
                                    ifelse(geolev1==204010, 2, #204010 Oueme where capital Porto novo situates, the capital
                                           ifelse(geolev1 %notin% c(204097, 204098, 204099, NA, 204010) & prov_act_ur==0, 0,
                                                  ifelse(geolev1 %notin% c(204097, 204098, 204099, NA, 204010) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==204099, NA,
                           ifelse(geomig1_pcode==204010, 2,
                                  ifelse(geomig1_pcode!=204010 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=204010 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=204010 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=204010 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA,
                     ifelse(educ==2, 0,
                            ifelse(educ==3, 1,
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA,
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1) 
#%>% sample_frac(0.2)
write.dta(bj79, "/africa calibrate rates/3-year in/BJ_1979.dta")
write.dta(bj79, "/africa calibrate rates/3-year out/BJ_1979.dta")


#benin 1992
bj92<-read.dta13("Benin1992.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.358
sample<-sum(bj92$perwt)
lev1<-bj92 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-bj92 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.358/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
bj92<-bj92 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 204099, 
                              ifelse(migratep=="Abroad", 204097, #generated
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 204098, geomig1_pcode))),
         prov_3_ur=ifelse(geomig1_pcode==204099, NA, 
                          ifelse(geomig1_pcode==204097, 5, 
                                 ifelse(geomig1_pcode %in% c(204098, NA), 9, prov_3_ur))), 
         prov_3_usr=ifelse(geomig1_pcode==204099, NA,
                           ifelse(geomig1_pcode==204097, 5,
                                  ifelse(geomig1_pcode %in% c(204098, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==204097, 5, 
                             ifelse(geolev1 %in% c(204098, 204099, NA), 9,
                                    ifelse(geolev1==204010, 2, #204010 Oueme where capital Porto novo situates, the capital 
                                           ifelse(geolev1 %notin% c(204097, 204098, 204099, NA, 204010) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(204097, 204098, 204099, NA, 204010) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==204099, NA,
                           ifelse(geomig1_pcode==204010, 2, 
                                  ifelse(geomig1_pcode!=204010 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=204010 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=204010 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=204010 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1) 
#%>% sample_frac(0.1)
write.dta(bj92, "/africa calibrate rates/3-year in/BJ_1992.dta")
write.dta(bj92, "/africa calibrate rates/3-year out/BJ_1992.dta")

#benin 2002
bj02<-read.dta13("Benin2002.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.39
sample<-sum(bj02$perwt)
lev1<-bj02 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-bj02 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.39/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
bj02<-bj02 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 204099, 
                              ifelse(migratep=="Abroad", 204097, #generated
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 204098, geomig1_pcode))),
         prov_3_ur=ifelse(geomig1_pcode==204099, NA, 
                          ifelse(geomig1_pcode==204097, 5, 
                                 ifelse(geomig1_pcode %in% c(204098, NA), 9, prov_3_ur))), 
         prov_3_usr=ifelse(geomig1_pcode==204099, NA,
                           ifelse(geomig1_pcode==204097, 5,
                                  ifelse(geomig1_pcode %in% c(204098, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==204097, 5, 
                             ifelse(geolev1 %in% c(204098, 204099, NA), 9,
                                    ifelse(geolev1==204010, 2, #204010 Oueme where capital Porto novo situates, the capital 
                                           ifelse(geolev1 %notin% c(204097, 204098, 204099, NA, 204010) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(204097, 204098, 204099, NA, 204010) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==204099, NA,
                           ifelse(geomig1_pcode==204010, 2, 
                                  ifelse(geomig1_pcode!=204010 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=204010 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=204010 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=204010 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1) 
#%>% sample_frac(0.05)
write.dta(bj02, "/africa calibrate rates/3-year in/BJ_2002.dta")
write.dta(bj02, "/africa calibrate rates/3-year out/BJ_2002.dta")

#benin 2013
bj13<-read.dta13("Benin2013.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.446
sample<-sum(bj13$perwt)
lev1<-bj13 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-bj13 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.446/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
bj13<-bj13 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 204099, 
                              ifelse(migratep=="Abroad", 204097, #generated
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 204098, geomig1_pcode))),
         prov_3_ur=ifelse(geomig1_pcode==204099, NA, 
                          ifelse(geomig1_pcode==204097, 5, 
                                 ifelse(geomig1_pcode %in% c(204098, NA), 9, prov_3_ur))), 
         prov_3_usr=ifelse(geomig1_pcode==204099, NA,
                           ifelse(geomig1_pcode==204097, 5,
                                  ifelse(geomig1_pcode %in% c(204098, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==204097, 5, 
                             ifelse(geolev1 %in% c(204098, 204099, NA), 9,
                                    ifelse(geolev1==204010, 2, #204010 Oueme where capital Porto novo situates, the capital 
                                           ifelse(geolev1 %notin% c(204097, 204098, 204099, NA, 204010) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(204097, 204098, 204099, NA, 204010) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==204099, NA,
                           ifelse(geomig1_pcode==204010, 2, 
                                  ifelse(geomig1_pcode!=204010 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=204010 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=204010 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=204010 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1) 
#%>%sample_frac(0.05)
write.dta(bj13, "/africa calibrate rates/3-year in/BJ_2013.dta")
write.dta(bj13, "/africa calibrate rates/3-year out/BJ_2013.dta")

#Cameroon 1987
cm87<-read.dta13("Cameroon1987.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.379
sample<-sum(cm87$perwt)
lev1<-cm87 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-cm87 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.379/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
cm87<-cm87 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 120099, 
                              ifelse(migratep=="Abroad", 120097, 
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 120098, geomig1_pcode))),
         prov_3_ur=ifelse(geomig1_pcode==120099, NA, 
                          ifelse(geomig1_pcode==120097, 5, 
                                 ifelse(geomig1_pcode %in% c(120098, NA), 9, prov_3_ur))), 
         prov_3_usr=ifelse(geomig1_pcode==120099, NA,
                           ifelse(geomig1_pcode==120097, 5,
                                  ifelse(geomig1_pcode %in% c(120098, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==120097, 5, 
                             ifelse(geolev1 %in% c(120098, 120099, NA), 9,
                                    ifelse(geolev1==120002, 2, #120002 region centre sud where capital Yaounde situates, the capital 
                                           ifelse(geolev1 %notin% c(120097, 120098, 120099, NA, 120002) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(120097, 120098, 120099, NA, 120002) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==120099, NA,
                           ifelse(geomig1_pcode==120002, 2, 
                                  ifelse(geomig1_pcode!=120002 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=120002 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=120002 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=120002 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1) 
#%>%sample_frac(0.1)
write.dta(cm87, "/africa calibrate rates/3-year in/CM_1987.dta")
write.dta(cm87, "/africa calibrate rates/3-year out/CM_1987.dta")

#Cameroon 2005
cm05<-read.dta13("Cameroon2005.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.485
sample<-sum(cm05$perwt)
lev1<-cm05 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-cm05 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.485/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
cm05<-cm05 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 120099, 
                              ifelse(migratep=="Abroad", 120097, 
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 120098, geomig1_pcode))),
         prov_3_ur=ifelse(geomig1_pcode==120099, NA, 
                          ifelse(geomig1_pcode==120097, 5, 
                                 ifelse(geomig1_pcode %in% c(120098, NA), 9, prov_3_ur))), 
         prov_3_usr=ifelse(geomig1_pcode==120099, NA,
                           ifelse(geomig1_pcode==120097, 5,
                                  ifelse(geomig1_pcode %in% c(120098, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==120097, 5, 
                             ifelse(geolev1 %in% c(120098, 120099, NA), 9,
                                    ifelse(geolev1==120002, 2, #120002 region centre sud where capital Yaounde situates, the capital 
                                           ifelse(geolev1 %notin% c(120097, 120098, 120099, NA, 120002) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(120097, 120098, 120099, NA, 120002) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==120099, NA,
                           ifelse(geomig1_pcode==120002, 2, 
                                  ifelse(geomig1_pcode!=120002 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=120002 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=120002 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=120002 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1) %>%
  arrange(serial, pernum) %>%
  mutate(rownum=row_number(serial))
#%>%sample_frac(0.05)
write.dta(cm05, "/africa calibrate rates/3-year in/CM_2005.dta")
write.dta(cm05, "/africa calibrate rates/3-year out/CM_2005.dta")

#Egypt 1986, no migratep - different way of checking geomig1_pcode
eg86<-read.dta13("Egypt1986.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.44
sample<-sum(eg86$perwt)
lev1<-eg86 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-eg86 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.44/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
eg86<-eg86 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         geomig1_pcode=ifelse(geomig1_pcode==geolev1, 818099, geomig1_pcode),
         prov_3_ur=ifelse(geomig1_pcode==818099, NA, 
                          ifelse(geomig1_pcode==818097, 5, 
                                 ifelse(geomig1_pcode %in% c(818098, NA), 9, prov_3_ur))), 
         prov_3_usr=ifelse(geomig1_pcode==818099, NA,
                           ifelse(geomig1_pcode==818097, 5,
                                  ifelse(geomig1_pcode %in% c(818098, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==818097, 5, 
                             ifelse(geolev1 %in% c(818098, 818099, NA), 9,
                                    ifelse(geolev1==818001, 2, #818001 cairo, the capital 
                                           ifelse(geolev1 %notin% c(818097, 818098, 818099, NA, 818001) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(818097, 818098, 818099, NA, 818001) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==818099, NA,
                           ifelse(geomig1_pcode==818001, 2, 
                                  ifelse(geomig1_pcode!=818001 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=818001 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=818001 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=818001 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1) 
#%>%sample_frac(0.025)
write.dta(eg86, "/africa calibrate rates/3-year in/EG_1986.dta")
write.dta(eg86, "/africa calibrate rates/3-year out/EG_1986.dta")

#Egypt 1996, decreased urbanization since 1986
eg96<-read.dta13("Egypt1996.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.427
sample<-sum(eg96$perwt)
lev1<-eg96 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-eg96 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.427/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
eg96<-eg96 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 818099, #generated 
                              ifelse(migratep=="Abroad", 818097, 
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 818098, geomig1_pcode))),
         prov_3_ur=ifelse(geomig1_pcode==818099, NA, 
                          ifelse(geomig1_pcode==818097, 5, 
                                 ifelse(geomig1_pcode %in% c(818098, NA), 9, prov_3_ur))), 
         prov_3_usr=ifelse(geomig1_pcode==818099, NA,
                           ifelse(geomig1_pcode==818097, 5,
                                  ifelse(geomig1_pcode %in% c(818098, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==818097, 5, 
                             ifelse(geolev1 %in% c(818098, 818099, NA), 9,
                                    ifelse(geolev1==818001, 2, #818001 cairo, the capital 
                                           ifelse(geolev1 %notin% c(818097, 818098, 818099, NA, 818001) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(818097, 818098, 818099, NA, 818001) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==818099, NA,
                           ifelse(geomig1_pcode==818001, 2, 
                                  ifelse(geomig1_pcode!=818001 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=818001 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=818001 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=818001 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1)
#%>%sample_frac(0.025)
write.dta(eg96, "/africa calibrate rates/3-year in/EG_1996.dta")
write.dta(eg96, "/africa calibrate rates/3-year out/EG_1996.dta")

#Egypt 2006
eg06<-read.dta13("Egypt2006.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.431
sample<-sum(eg06$perwt)
lev1<-eg06 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-eg06 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.431/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
eg06<-eg06 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 818099, #generated 
                              ifelse(migratep=="Abroad", 818097, 
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 818098, geomig1_pcode))), #generated
         prov_3_ur=ifelse(geomig1_pcode==818099, NA, 
                          ifelse(geomig1_pcode==818097, 5, 
                                 ifelse(geomig1_pcode %in% c(818098, NA), 9, prov_3_ur))), 
         prov_3_usr=ifelse(geomig1_pcode==818099, NA,
                           ifelse(geomig1_pcode==818097, 5,
                                  ifelse(geomig1_pcode %in% c(818098, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==818097, 5, 
                             ifelse(geolev1 %in% c(818098, 818099, NA), 9,
                                    ifelse(geolev1==818001, 2, #818001 cairo, the capital 
                                           ifelse(geolev1 %notin% c(818097, 818098, 818099, NA, 818001) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(818097, 818098, 818099, NA, 818001) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==818099, NA,
                           ifelse(geomig1_pcode==818001, 2, 
                                  ifelse(geomig1_pcode!=818001 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=818001 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=818001 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=818001 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1) 
#%>%sample_frac(0.025)
write.dta(eg06, "/africa calibrate rates/3-year in/EG_2006.dta")
write.dta(eg06, "/africa calibrate rates/3-year out/EG_2006.dta")

#Guinea 1996
gn96<-read.dta13("Guinea1996.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.298
sample<-sum(gn96$perwt)
lev1<-gn96 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-gn96 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.298/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
gn96<-gn96 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 324099,  
                              ifelse(migratep=="Abroad", 324097, 
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 324098, geomig1_pcode))), 
         prov_3_ur=ifelse(geomig1_pcode==324099, NA, 
                          ifelse(geomig1_pcode==324097, 5, 
                                 ifelse(geomig1_pcode %in% c(324098, NA), 9, prov_3_ur))), 
         prov_3_usr=ifelse(geomig1_pcode==324099, NA,
                           ifelse(geomig1_pcode==324097, 5,
                                  ifelse(geomig1_pcode %in% c(324098, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==324097, 5, 
                             ifelse(geolev1 %in% c(324098, 324099, NA), 9,
                                    ifelse(geolev1==324021, 2, #324021 conakry, the capital 
                                           ifelse(geolev1 %notin% c(324097, 324098, 324099, NA, 324021) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(324097, 324098, 324099, NA, 324021) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==324099, NA,
                           ifelse(geomig1_pcode==324021, 2, 
                                  ifelse(geomig1_pcode!=324021 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=324021 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=324021 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=324021 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1) 
#%>%sample_frac(0.1)
write.dta(gn96, "/africa calibrate rates/3-year in/GN_1996.dta")
write.dta(gn96, "/africa calibrate rates/3-year out/GN_1996.dta")

#Ghana 2014
gn14<-read.dta13("Guinea2014.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.348
sample<-sum(gn14$perwt)
lev1<-gn14 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-gn14 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.348/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
gn14<-gn14 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 324099,  #generated
                              ifelse(migratep=="Abroad", 324097, 
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 324098, geomig1_pcode))), 
         prov_3_ur=ifelse(geomig1_pcode==324099, NA, 
                          ifelse(geomig1_pcode==324097, 5, 
                                 ifelse(geomig1_pcode %in% c(324098, NA), 9, prov_3_ur))), 
         prov_3_usr=ifelse(geomig1_pcode==324099, NA,
                           ifelse(geomig1_pcode==324097, 5,
                                  ifelse(geomig1_pcode %in% c(324098, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==324097, 5, 
                             ifelse(geolev1 %in% c(324098, 324099, NA), 9,
                                    ifelse(geolev1==324021, 2, #324021 conakry, the capital 
                                           ifelse(geolev1 %notin% c(324097, 324098, 324099, NA, 324021) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(324097, 324098, 324099, NA, 324021) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==324099, NA,
                           ifelse(geomig1_pcode==324021, 2, 
                                  ifelse(geomig1_pcode!=324021 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=324021 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=324021 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=324021 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1) 
#%>%sample_frac(0.05)
write.dta(gn14, "/africa calibrate rates/3-year in/GN_2014.dta")
write.dta(gn14, "/africa calibrate rates/3-year out/GN_2014.dta")

#Malawi 2008
mw08<-read.dta13("Malawi2008.dta", convert.factors=T)
WUP=0.153
sample<-sum(mw08$perwt)
lev1<-mw08 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-mw08 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.153/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
mw08<-mw08 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migratep %in% c("NIU (Not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 454999, 
                              ifelse(migratep=="Abroad", 454997, 
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 454998, geomig1_pcode))),
         prov_3_ur=ifelse(geomig1_pcode==454999, NA, 
                          ifelse(geomig1_pcode==454997, 5, 
                                 ifelse(geomig1_pcode %in% c(454998, NA), 9, prov_3_ur))), 
         prov_3_usr=ifelse(geomig1_pcode==454999, NA,
                           ifelse(geomig1_pcode==454997, 5,
                                  ifelse(geomig1_pcode %in% c(454998, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==454997, 5, 
                             ifelse(geolev1 %in% c(454998, 454999, NA), 9,
                                    ifelse(geolev1==454206, 2, #454206 Lilongwe, the capital 
                                           ifelse(geolev1 %notin% c(454997, 454998, 454999, NA, 454206) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(454997, 454998, 454999, NA, 454206) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==454999,NA,
                           ifelse(geomig1_pcode==454206, 2,
                                  ifelse(geomig1_pcode!=454206 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=454206 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=454206 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=454206 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1) 
#%>%sample_frac(0.05)
write.dta(mw08, "/africa calibrate rates/3-year in/MW_2008.dta")
write.dta(mw08, "/africa calibrate rates/3-year out/MW_2008.dta")

#Mali 1998
ml98<-read.dta13("Mali1998.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.269
sample<-sum(ml98$perwt)
lev1<-ml98 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-ml98 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.269/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
ml98<-ml98 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 466099, 
                              ifelse(migratep=="Abroad", 466097, 
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 466098, geomig1_pcode))),
         prov_3_ur=ifelse(geomig1_pcode==466099, NA, 
                          ifelse(geomig1_pcode==466097, 5, 
                                 ifelse(geomig1_pcode %in% c(466098, NA), 9, prov_3_ur))), 
         prov_3_usr=ifelse(geomig1_pcode==466099, NA,
                           ifelse(geomig1_pcode==466097, 5,
                                  ifelse(geomig1_pcode %in% c(466098, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==466097, 5, 
                             ifelse(geolev1 %in% c(466098, 466099, NA), 9,
                                    ifelse(geolev1==466009, 2, #204010 Oueme where capital Porto novo situates, the capital 
                                           ifelse(geolev1 %notin% c(466097, 466098, 466099, NA, 466009) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(466097, 466098, 466099, NA, 466009) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==466099, NA,
                           ifelse(geomig1_pcode==466009, 2, 
                                  ifelse(geomig1_pcode!=466009 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=466009 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=466009 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=466009 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1)
#%>%sample_frac(0.05)
write.dta(ml98, "/africa calibrate rates/3-year in/ML_1998.dta")
write.dta(ml98, "/africa calibrate rates/3-year out/ML_1998.dta")

#Mali 2009
ml09<-read.dta13("Mali2009.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.352
sample<-sum(ml09$perwt)
lev1<-ml09 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-ml09 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.352/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
ml09<-ml09 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 466099, 
                              ifelse(migratep=="Abroad", 466097, #generated
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 466098, geomig1_pcode))),
         prov_3_ur=ifelse(geomig1_pcode==466099, NA, 
                          ifelse(geomig1_pcode==466097, 5, 
                                 ifelse(geomig1_pcode %in% c(466098, NA), 9, prov_3_ur))), 
         prov_3_usr=ifelse(geomig1_pcode==466099, NA,
                           ifelse(geomig1_pcode==466097, 5,
                                  ifelse(geomig1_pcode %in% c(466098, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==466097, 5, 
                             ifelse(geolev1 %in% c(466098, 466099, NA), 9,
                                    ifelse(geolev1==466009, 2, #204010 Oueme where capital Porto novo situates, the capital 
                                           ifelse(geolev1 %notin% c(466097, 466098, 466099, NA, 466009) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(466097, 466098, 466099, NA, 466009) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==466099, NA,
                           ifelse(geomig1_pcode==466009, 2, 
                                  ifelse(geomig1_pcode!=466009 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=466009 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=466009 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=466009 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1) 
#%>%sample_frac(0.05)
write.dta(ml09, "/africa calibrate rates/3-year in/ML_2009.dta")
write.dta(ml09, "/africa calibrate rates/3-year out/ML_2009.dta")

#Rwanda 1991, no education, external source, no migratep, different way of checking geomig1_pcode
#kigali ngali was known as kigali rural province, so urban rate is put as 0.
external<-read.dta13("/external source/africa/rwanda91.dta") %>%
  mutate(pop=as.numeric(ifelse(pop==".", 0, pop)), pop=pop/sum(pop), 
         urbanrate91=as.numeric(urbanrate91)/100) %>%
  bind_cols(data.table(code=c(646003, 646004, 646005, 646006, 646007, 646008, 646009, 646002))) %>%
  select(-urbanrate91, -pop91)
rw91<-read.dta13("Rwanda1991.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.055
sum(external$urban*external$pop)
lev1<-external %>%
  mutate(urban=urban*WUP/sum(external$urban*external$pop)) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2))) %>%
  rename(geolev1=code)
rw91<-rw91 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         geomig1_pcode=ifelse(geomig1_pcode==geolev1, 646099, geomig1_pcode),
         prov_3_ur=ifelse(geomig1_pcode==646099, NA, 
                          ifelse(geomig1_pcode==646097, 5, 
                                 ifelse(geomig1_pcode %in% c(646098, NA), 9, prov_3_ur))), 
         prov_3_usr=ifelse(geomig1_pcode==646099, NA,
                           ifelse(geomig1_pcode==646097, 5,
                                  ifelse(geomig1_pcode %in% c(646098, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==646097, 5, 
                             ifelse(geolev1 %in% c(646098, 646099, NA), 9,
                                    ifelse(geolev1==646002, 2, #646001 where capital Kigali situates, the capital 
                                           ifelse(geolev1 %notin% c(646097, 646098, 646099, NA, 646002) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(646097, 646098, 646099, NA, 646002) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==646099, NA,
                           ifelse(geomig1_pcode==646002, 2, 
                                  ifelse(geomig1_pcode!=646002 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=646002 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=646002 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=646002 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1) 
#%>%sample_frac(0.1)
write.dta(rw91, "/africa calibrate rates/3-year in/RW_1991.dta")
write.dta(rw91, "/africa calibrate rates/3-year out/RW_1991.dta")

#Rwanda 2002, no migratep, different way of checking geomig1_pcode
rw02<-read.dta13("Rwanda2002.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.168
sample<-sum(rw02$perwt)
lev1<-rw02 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-rw02 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.168/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
rw02<-rw02 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         geomig1_pcode=ifelse(geomig1_pcode==geolev1, 646099, geomig1_pcode),
         prov_3_ur=ifelse(geomig1_pcode==646099, NA, 
                          ifelse(geomig1_pcode==646097, 5, 
                                 ifelse(geomig1_pcode %in% c(646098, NA), 9, prov_3_ur))), 
         prov_3_usr=ifelse(geomig1_pcode==646099, NA,
                           ifelse(geomig1_pcode==646097, 5,
                                  ifelse(geomig1_pcode %in% c(646098, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==646097, 5, 
                             ifelse(geolev1 %in% c(646098, 646099, NA), 9,
                                    ifelse(geolev1==646002, 2, #646001 where capital Kigali situates, the capital 
                                           ifelse(geolev1 %notin% c(646097, 646098, 646099, NA, 646002) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(646097, 646098, 646099, NA, 646002) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==646099, NA,
                           ifelse(geomig1_pcode==646002, 2, 
                                  ifelse(geomig1_pcode!=646002 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=646002 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=646002 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=646002 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1)
#%>%sample_frac(0.1)
write.dta(rw02, "/africa calibrate rates/3-year in/RW_2002.dta")
write.dta(rw02, "/africa calibrate rates/3-year out/RW_2002.dta")

#Rwanda 2012, previous residence not harmonized thus merged with unharmonized geomigp_rw, no migyrs1 maybe skip it?
# rw12<-read.dta13("Rwanda2012.dta", convert.factors=T) %>%
#   mutate(country=as.character(country), year=as.character(year), 
#          geolev1=substr(as.character(geolev2), start = 1, stop = 6)) %>%
#   select(-geomig1_p)
# rw12<-rw12 %>%
#   left_join(geomigp_rw, by=c("country", "year", "sample", "serial", "pernum"))
# WUP=0.169
# sample<-sum(rw12$perwt)
# lev1<-rw12 %>%
#   group_by(geolev1) %>%
#   summarise(pop=sum(perwt), 
#             urban=sum(perwt[urban=="Urban"]))
# total<-rw12 %>%
#   summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
#             weight=0.169/upert)
# lev1<-lev1 %>%
#   mutate(urban=urban/pop, 
#          pop=pop/sample) %>%
#   arrange(-urban)
# repeat {
#   print(WUP-sum(lev1$urban*lev1$pop))
#   lev1=lev1 %>%
#     mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
#            urban=urban*(1+weight),
#            uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
#            popa=ifelse(urban>1, pop, 0), 
#            popa=sum(popa), 
#            urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
#            urban=ifelse(urban>1, 1, urban))
#   if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
#     break
#   }
# }
# sum(lev1$urban*lev1$pop)
# lev1<-lev1 %>%
#   mutate(ur=ifelse(urban<=0.5, 0, 1),  
#          usr=ifelse(urban<=0.5, 0, 
#                     ifelse(urban>0.5 & urban<=0.85, 1, 2)))
# rw12<-rw12 %>%
#   left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
#   rename(prov_act_ur=ur, prov_act_usr=usr, geomig1_pcode=geomig1_p) %>%
#   left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
#   rename(prov_3_ur=ur, prov_3_usr=usr) %>%
#   mutate(caseid=(serial*100) + pernum,
#          #verify that geomig1_pcode is coded consistently with migratep
#          geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 646099, #generated
#                               ifelse(migratep=="Abroad", 646097, #generated
#                                      ifelse(migratep %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 646098, geomig1_pcode))), #generated
#          prov_3_ur=ifelse(geomig1_pcode==646099, NA, 
#                           ifelse(geomig1_pcode==646097, 5, 
#                                  ifelse(geomig1_pcode %in% c(646098, NA), 9, prov_3_ur))), 
#          prov_3_usr=ifelse(geomig1_pcode==646099, NA,
#                            ifelse(geomig1_pcode==646097, 5,
#                                   ifelse(geomig1_pcode %in% c(646098, NA), 9, prov_3_usr))),
#          prov_act_cor=ifelse(geolev1==646097, 5, 
#                              ifelse(geolev1 %in% c(646098, 646099, NA), 9,
#                                     ifelse(geolev1==646001, 2, #646001 where capital Kigali situates, the capital 
#                                            ifelse(geolev1 %notin% c(646097, 646098, 646099, NA, 646001) & prov_act_ur==0, 0, 
#                                                   ifelse(geolev1 %notin% c(646097, 646098, 646099, NA, 646001) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
#          prov_3_cor=ifelse(geomig1_pcode==646099, NA,
#                            ifelse(geomig1_pcode==646001, 2, 
#                                   ifelse(geomig1_pcode!=646001 & prov_3_usr==5, 5,
#                                          ifelse(geomig1_pcode!=646001 & prov_3_usr==9, 9,
#                                                 ifelse(geomig1_pcode!=646001 & prov_3_usr==0, 0,
#                                                        ifelse(geomig1_pcode!=646001 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
#          educ=as.integer(edattain),
#          educ=ifelse(educ==1, NA, 
#                      ifelse(educ==2, 0, 
#                             ifelse(educ==3, 1, 
#                                    ifelse(educ>=4 & educ<=5, 2, NA)))),
#          age=as.integer(age)-1,
#          age=ifelse(age>100, NA, age),
#          age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
#                          60:64=16;65:69=17;70:74=18;75:79=19;else=20")) %>%
#   sample_frac(0.05)
# write.dta(rw12, "/africa/data/3-year/RW_12.dta")

#SierraLeone 2004, no migratep, different way of checkgin geomig1_pcode, no migyrs1, skip it?
# sl04<-read.dta13("Sierraleone2004.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
# WUP=0.366
# sample<-sum(sl04$perwt)
# lev1<-sl04 %>%
#   group_by(geolev1) %>%
#   summarise(pop=sum(perwt), 
#             urban=sum(perwt[urban=="Urban"]))
# total<-sl04 %>%
#   summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
#             weight=0.366/upert)
# lev1<-lev1 %>%
#   mutate(urban=urban/pop*total$weight, 
#          pop=pop/sample) %>%
#   arrange(-urban) %>%
#   mutate(ur=ifelse(urban<=0.5, 0, 1),  
#          usr=ifelse(urban<=0.5, 0, 
#                     ifelse(urban>0.5 & urban<=0.85, 1, 2)))
# sl04<-sl04 %>%
#   left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
#   rename(prov_act_ur=ur, prov_act_usr=usr) %>%
#   dplyr::left_join(geomigp, by="geomig1_p") %>%  
#   rename(geomig1_pcode=code) %>%
#   mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
#   left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
#   rename(prov_3_ur=ur, prov_3_usr=usr) %>%
#   mutate(caseid=(serial*100) + pernum,
#          geomig1_pcode=ifelse(geomig1_pcode==geolev1, 694099, geomig1_pcode),
#          prov_3_ur=ifelse(geomig1_pcode==694099, NA, 
#                           ifelse(geomig1_pcode==694097, 5, 
#                                  ifelse(geomig1_pcode %in% c(694098, NA), 9, prov_3_ur))), 
#          prov_3_usr=ifelse(geomig1_pcode==694099, NA,
#                            ifelse(geomig1_pcode==694097, 5,
#                                   ifelse(geomig1_pcode %in% c(694098, NA), 9, prov_3_usr))),
#          prov_act_cor=ifelse(geolev1==694097, 5, 
#                              ifelse(geolev1 %in% c(694098, 694099, NA), 9,
#                                     ifelse(geolev1==694042, 2, #694042 western urban where capital freetown situates, the capital 
#                                            ifelse(geolev1 %notin% c(694097, 694098, 694099, NA, 694042) & prov_act_ur==0, 0, 
#                                                   ifelse(geolev1 %notin% c(694097, 694098, 694099, NA, 694042) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
#          prov_3_cor=ifelse(geomig1_pcode==694099, NA,
#                            ifelse(geomig1_pcode==694042, 2, 
#                                   ifelse(geomig1_pcode!=694042 & prov_3_usr==5, 5,
#                                          ifelse(geomig1_pcode!=694042 & prov_3_usr==9, 9,
#                                                 ifelse(geomig1_pcode!=694042 & prov_3_usr==0, 0,
#                                                        ifelse(geomig1_pcode!=694042 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
#          educ=as.integer(edattain),
#          educ=ifelse(educ==1, NA, 
#                      ifelse(educ==2, 0, 
#                             ifelse(educ==3, 1, 
#                                    ifelse(educ>=4 & educ<=5, 2, NA)))),
#          age=as.integer(age)-1,
#          age=ifelse(age>100, NA, age),
#          age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
#                          60:64=16;65:69=17;70:74=18;75:79=19;else=20")) %>%
#   sample_frac(0.1)
# write.dta(sl04, "/africa/data/3-year/SL_04.dta")

#south africa 2007, years in current residence migyrs2
if (!require("ipumsr")) stop("Reading IPUMS data into R requires the ipumsr package. It can be installed using the following command: install.packages('ipumsr')")
ddi <- read_ipums_ddi("migyrs1_za.xml")
data <- read_ipums_micro(ddi) %>%
  rename(country=COUNTRY, year=YEAR, sample=SAMPLE, serial=SERIAL, pernum=PERNUM) %>%
  mutate(country="South Africa", year=as.character(as.factor(year)), sample=as.character(as.factor(sample))) %>%
  select(country, year, serial, pernum, MIGYRS2)
za07<-read.dta13("Southafrica2007.dta", convert.factors=T, generate.factors=T, nonint.factors=T) %>%
  left_join(data, by=c("country", "year", "serial", "pernum"))
WUP=0.606
sample<-sum(za07$perwt)
lev1<-za07 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt),
            urban=sum(perwt[urban=="Urban"]))
total<-za07 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt),
            weight=0.606/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop,
         pop=pop/sample) %>%
  arrange(-urban)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop),
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0),
           popa=ifelse(urban>1, pop, 0),
           popa=sum(popa),
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1),
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),
         usr=ifelse(urban<=0.5, 0,
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
za07<-za07 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 710099,
                              ifelse(migratep=="Abroad", 710097, 
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 710098, geomig1_pcode))),
         prov_3_ur=ifelse(geomig1_pcode==710099, NA,
                          ifelse(geomig1_pcode==710097, 5,
                                 ifelse(geomig1_pcode %in% c(710098, NA), 9, prov_3_ur))),
         prov_3_usr=ifelse(geomig1_pcode==710099, NA,
                           ifelse(geomig1_pcode==710097, 5,
                                  ifelse(geomig1_pcode %in% c(710098, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==710097, 5,
                             ifelse(geolev1 %in% c(710098, 710099, NA), 9,
                                    ifelse(geolev1==710001, 2, #710001 western cape where capital cape town situates, the capital
                                           ifelse(geolev1 %notin% c(710097, 710098, 710099, NA, 710001) & prov_act_ur==0, 0,
                                                  ifelse(geolev1 %notin% c(710097, 710098, 710099, NA, 710001) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==710099, NA,
                           ifelse(geomig1_pcode==710001, 2,
                                  ifelse(geomig1_pcode!=710001 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=710001 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=710001 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=710001 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA,
                     ifelse(educ==2, 0,
                            ifelse(educ==3, 1,
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) %>%
  select(-migyrs1) %>%
  rename(migyrs1=MIGYRS2) 
#%>%sample_frac(0.1)
write.dta(za07, "/africa calibrate rates/3-year in/ZA_2007.dta")
write.dta(za07, "/africa calibrate rates/3-year out/ZA_2007.dta")

#south africa 2011
if (!require("ipumsr")) stop("Reading IPUMS data into R requires the ipumsr package. It can be installed using the following command: install.packages('ipumsr')")
ddi <- read_ipums_ddi("migyrs1_za.xml")
data <- read_ipums_micro(ddi) %>%
  rename(country=COUNTRY, year=YEAR, sample=SAMPLE, serial=SERIAL, pernum=PERNUM) %>%
  mutate(country="South Africa", year=as.character(as.factor(year)), sample=as.character(as.factor(sample))) %>%
  select(country, year, serial, pernum, MIGYRS2)
za11<-read.dta13("Southafrica2011.dta", convert.factors=T, generate.factors=T, nonint.factors=T) %>%
  left_join(data, by=c("country", "year", "serial", "pernum"))
WUP=0.627
sample<-sum(za11$perwt)
lev1<-za11 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt),
            urban=sum(perwt[urban=="Urban"]))
total<-za11 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt),
            weight=0.627/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop,
         pop=pop/sample) %>%
  arrange(-urban)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop),
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0),
           popa=ifelse(urban>1, pop, 0),
           popa=sum(popa),
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1),
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),
         usr=ifelse(urban<=0.5, 0,
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
za11<-za11 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 710099,
                              ifelse(migratep=="Abroad", 710097, #generated
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 710098, geomig1_pcode))),
         prov_3_ur=ifelse(geomig1_pcode==710099, NA,
                          ifelse(geomig1_pcode==710097, 5,
                                 ifelse(geomig1_pcode %in% c(710098, NA), 9, prov_3_ur))),
         prov_3_usr=ifelse(geomig1_pcode==710099, NA,
                           ifelse(geomig1_pcode==710097, 5,
                                  ifelse(geomig1_pcode %in% c(710098, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==710097, 5,
                             ifelse(geolev1 %in% c(710098, 710099, NA), 9,
                                    ifelse(geolev1==710001, 2, #710001 western cape where capital cape town situates, the capital
                                           ifelse(geolev1 %notin% c(710097, 710098, 710099, NA, 710001) & prov_act_ur==0, 0,
                                                  ifelse(geolev1 %notin% c(710097, 710098, 710099, NA, 710001) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==710099, NA,
                           ifelse(geomig1_pcode==710001, 2,
                                  ifelse(geomig1_pcode!=710001 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=710001 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=710001 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=710001 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA,
                     ifelse(educ==2, 0,
                            ifelse(educ==3, 1,
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) %>%
  select(-migyrs1) %>%
  rename(migyrs1=MIGYRS2) 
#%>%sample_frac(0.025)
write.dta(za11, "/africa calibrate rates/3-year in/ZA_2011.dta")
write.dta(za11, "/africa calibrate rates/3-year out/ZA_2011.dta")

#Togo 2010
tg10<-read.dta13("Togo2010.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.375
sample<-sum(tg10$perwt)
lev1<-tg10 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-tg10 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.375/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
tg10<-tg10 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 768099, 
                              ifelse(migratep=="Abroad", 768097, 
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 768098, geomig1_pcode))),
         prov_3_ur=ifelse(geomig1_pcode==768099, NA, 
                          ifelse(geomig1_pcode==768097, 5, 
                                 ifelse(geomig1_pcode %in% c(768098, NA), 9, prov_3_ur))), 
         prov_3_usr=ifelse(geomig1_pcode==768099, NA,
                           ifelse(geomig1_pcode==768097, 5,
                                  ifelse(geomig1_pcode %in% c(768098, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==768097, 5, 
                             ifelse(geolev1 %in% c(768098, 768099, NA), 9,
                                    ifelse(geolev1==768001, 2, #768001 leome, the capital 
                                           ifelse(geolev1 %notin% c(768097, 768098, 768099, NA, 768001) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(768097, 768098, 768099, NA, 768001) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==768099, NA,
                           ifelse(geomig1_pcode==768001, 2, 
                                  ifelse(geomig1_pcode!=768001 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=768001 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=768001 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=768001 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1)
#%>%sample_frac(0.1)
write.dta(tg10, "/africa calibrate rates/3-year in/TG_2010.dta")
write.dta(tg10, "/africa calibrate rates/3-year out/TG_2010.dta")

#uganda 1991, no migratep
ug91<-read.dta13("Uganda1991.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.115
sample<-sum(ug91$perwt)
lev1<-ug91 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-ug91 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.115/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
ug91<-ug91 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         geomig1_pcode=ifelse(geomig1_pcode==geolev1, 800099, geomig1_pcode), #generaged
         prov_3_ur=ifelse(geomig1_pcode==800099, NA, 
                          ifelse(geomig1_pcode==800097, 5, 
                                 ifelse(geomig1_pcode %in% c(800098, NA), 9, prov_3_ur))), 
         prov_3_usr=ifelse(geomig1_pcode==800099, NA,
                           ifelse(geomig1_pcode==800097, 5,
                                  ifelse(geomig1_pcode %in% c(800098, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==800097, 5, 
                             ifelse(geolev1 %in% c(800098, 800099, NA), 9,
                                    ifelse(geolev1==800102, 2, #800102 kampala, the capital 
                                           ifelse(geolev1 %notin% c(800097, 800098, 800099, NA, 800102) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(800097, 800098, 800099, NA, 800102) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==800099, NA,
                           ifelse(geomig1_pcode==800102, 2, 
                                  ifelse(geomig1_pcode!=800102 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=800102 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=800102 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=800102 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1) 
#%>%sample_frac(0.05)
write.dta(ug91, "/africa calibrate rates/3-year in/UG_1991.dta")
write.dta(ug91, "/africa calibrate rates/3-year out/UG_1991.dta")

#uganda 2002, no migratep
ug02<-read.dta13("Uganda2002.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.156
sample<-sum(ug02$perwt)
lev1<-ug02 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-ug02 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.156/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
ug02<-ug02 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         geomig1_pcode=ifelse(geomig1_pcode==geolev1, 800099, geomig1_pcode), #generaged
         prov_3_ur=ifelse(geomig1_pcode==800099, NA, 
                          ifelse(geomig1_pcode==800097, 5, 
                                 ifelse(geomig1_pcode %in% c(800098, NA), 9, prov_3_ur))), 
         prov_3_usr=ifelse(geomig1_pcode==800099, NA,
                           ifelse(geomig1_pcode==800097, 5,
                                  ifelse(geomig1_pcode %in% c(800098, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==800097, 5, 
                             ifelse(geolev1 %in% c(800098, 800099, NA), 9,
                                    ifelse(geolev1==800102, 2, #800102 kampala, the capital 
                                           ifelse(geolev1 %notin% c(800097, 800098, 800099, NA, 800102) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(800097, 800098, 800099, NA, 800102) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==800099, NA,
                           ifelse(geomig1_pcode==800102, 2, 
                                  ifelse(geomig1_pcode!=800102 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=800102 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=800102 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=800102 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1) 
#%>%sample_frac(0.05)
write.dta(ug02, "/africa calibrate rates/3-year in/UG_2002.dta")
write.dta(ug02, "/africa calibrate rates/3-year out/UG_2002.dta")
