# first setwd

`%notin%` <- Negate(`%in%`)
library(pacman)
pacman::p_load(foreign, data.table, car, stringi, readxl, gdata, labelled, ipumsr, readstata13, dplyr, tidyr, tidyverse, gmodels)
corin<-read.dta13("All-COR-In.dta") 
corout<-read.dta13("All-COR-Out.dta") 
urin<-read.dta13("All-UR-In.dta") 
urout<-read.dta13("All-UR-Out.dta")

#1.	Five-year migration rates should be lower than 3-year rates, which should also be lower than 1-year rates (which are most accurate).
#Take CM2007 in migration as an example for 3-year ad 5-year
check1corin5<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/5-year in/Census-COR-In_5_cm.dta") %>%
  rename(rate5='_Rate') %>%
  filter(country=="CM" & year==2005) %>%
  mutate(age2=as.integer(as.character(age2)), 
         educ=as.integer(as.character(educ)), 
         sex=as.integer(as.character(sex)))
check1corin3<-read.dta13("All-COR-In.dta") %>%
  filter(country=="CM" & period==3 & year==2005) %>%
  rename(rate3='_Rate', migrations3=migrations) %>%
  full_join(check1corin5, by=c("orig", "dest", "age2", "educ", "sex")) %>%
  select(orig, dest, age2, educ, sex, rate3, rate5) %>%
  mutate(check=(rate3>rate5)) %>%
  filter(age2==100 & educ==100 & sex==100) %>%
  mutate(inout="in", type="cor")
check1corout5<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/5-year out/Census-COR-Out_5_cm.dta") %>%
  rename(rate5='_Rate') %>%
  filter(country=="CM" & year==2005) %>%
  mutate(age2=as.integer(as.character(age2)), 
         educ=as.integer(as.character(educ)), 
         sex=as.integer(as.character(sex)))
check1corout3<-read.dta13("All-COR-Out.dta") %>%
  filter(country=="CM" & period==3 & year==2005) %>%
  rename(rate3='_Rate') %>%
  full_join(check1corout5, by=c("orig", "dest", "age2", "educ", "sex")) %>%
  select(orig, dest, age2, educ, sex, rate3, rate5) %>%
  mutate(check=(rate3>rate5)) %>%
  filter(age2==100 & educ==100 & sex==100) %>%
  mutate(inout="out", type="cor")
check1urin5<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/5-year in/Census-UR-In_5_cm.dta") %>%
  rename(rate5='_Rate') %>%
  filter(country=="CM" & year==2005) %>%
  mutate(age2=as.integer(as.character(age2)), 
         educ=as.integer(as.character(educ)), 
         sex=as.integer(as.character(sex)))
check1urin3<-read.dta13("All-UR-In.dta") %>%
  filter(country=="CM" & period==3 & year==2005) %>%
  rename(rate3='_Rate') %>%
  full_join(check1urin5, by=c("orig", "dest", "age2", "educ", "sex")) %>%
  select(orig, dest, age2, educ, sex, rate3, rate5) %>%
  mutate(check=(rate3>rate5)) %>%
  filter(age2==100 & educ==100 & sex==100) %>%
  mutate(inout="in", type="ur")
check1urout5<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/5-year out/Census-UR-Out_5_cm.dta") %>%
  rename(rate5='_Rate') %>%
  filter(country=="CM" & year==2005) %>%
  mutate(age2=as.integer(as.character(age2)), 
         educ=as.integer(as.character(educ)), 
         sex=as.integer(as.character(sex)))
check1urout3<-read.dta13("All-UR-Out.dta") %>%
  filter(country=="CM" & period==3 & year==2005) %>%
  rename(rate3='_Rate') %>%
  full_join(check1urout5, by=c("orig", "dest", "age2", "educ", "sex")) %>%
  select(orig, dest, age2, educ, sex, rate3, rate5) %>%
  mutate(check=(rate3>rate5)) %>%
  filter(age2==100 & educ==100 & sex==100) %>%
  mutate(inout="out", type="ur")
check1<-bind_rows(check1urin3, check1urout3, check1corin3, check1corout3) %>%
  mutate(ratio35=rate3/rate5, 
         country="CM", year="2005") 
write.dta(check1, "check1.dta")

#2. The number of migrants should be the same for the same flows, eg. rural-urban out-migration (rural denominator) and rural-urban in-migration (urban denominator)
check2corin<-corin %>%
  select(country, year, period, orig, dest, age2, educ, sex, migrations) %>%
  rename(migrationsin=migrations)
check2corout<-corout %>%
  select(country, year, period, orig, dest, age2, educ, sex, migrations) %>%
  rename(migrationsout=migrations) %>%
  full_join(check2corin, by=c("country","year", "period", "orig", "dest", "age2", "educ", "sex")) %>%
  mutate(check=(round(migrationsin, 2)==round(migrationsout, 2)))
table(check2corout$check)
check2urin<-urin %>%
  select(country, year, period, orig, dest, age2, educ, sex, migrations) %>%
  rename(migrationsin=migrations)
check2urout<-urout %>%
  select(country, year, period, orig, dest, age2, educ, sex, migrations) %>%
  rename(migrationsout=migrations) %>%
  full_join(check2urin, by=c("country","year", "period", "orig", "dest", "age2", "educ", "sex")) %>%
  mutate(check=(round(migrationsin, 2)==round(migrationsout, 2)))
table(check2urout$check)

#3. The person-years at risk (PYARS, denominator) should be the same when same origin and flows are out-migration, or when same destination and flows are in-migration.
check3corin<-corin %>%
  select(country, year, period, dest, age2, educ, sex, PYAR)
check3corout<-corout %>%
  dplyr::select(country, year, period, orig, age2, educ, sex, PYAR) %>%
  rename(dest=orig) %>%
  left_join(check3corin, by=c("country", "year", "age2", "educ", "sex", "dest")) %>%
  distinct_all() %>%
  mutate(check=(round(PYAR.x,3)==round(PYAR.y, 3)))
table(check3corout$check)
check3urin<-urin %>%
  select(country, year, period, dest, age2, educ, sex, PYAR)
check3urout<-urout %>%
  dplyr::select(country, year, period, orig, age2, educ, sex, PYAR) %>%
  rename(dest=orig) %>%
  left_join(check3urin, by=c("country", "year", "age2", "educ", "sex", "dest")) %>%
  distinct_all() %>%
  mutate(check=(round(PYAR.x, 3)==round(PYAR.y, 3)))
table(check3urout$check)

#4.	The migration rates for in- and out-migration should be the same when within the same sector eg. urban-urban.
check4corin<-corin %>%
  select(country, year, period, orig, dest, age2, educ, sex, `_Rate`) %>%
  rename(ratein=`_Rate`) 
check4corout<-corout %>%
  select(country, year, period, orig, dest, age2, educ, sex, `_Rate`) %>%
  rename(rateout=`_Rate`) %>%
  full_join(check4corin, by=c("country","year", "period", "orig", "dest", "age2", "educ", "sex")) %>%
  filter(orig==dest) %>%
  mutate(check=(round(ratein, 3)==round(rateout, 3)))
table(check4corout$check)
check4urin<-urin %>%
  select(country, year, period, orig, dest, age2, educ, sex, `_Rate`) %>%
  rename(ratein=`_Rate`) 
check4urout<-urout %>%
  select(country, year, period, orig, dest, age2, educ, sex, `_Rate`) %>%
  rename(rateout=`_Rate`) %>%
  full_join(check4urin, by=c("country","year", "period", "orig", "dest", "age2", "educ", "sex")) %>%
  filter(orig==dest) %>%
  mutate(check=(ratein==rateout))
table(check4urout$check)

#5. For 5-year migration, children under-five should not have any rates. Also, children under ten should not have educational categories, only be included in the ???100”s (totals).
check5in<-corin %>%
  filter(period==5 & age2==1)
check5out<-corout %>%
  filter(period==5 & age2==1)
table(check5in$'_Rate')
table(check5out$'_Rate')
#deleted educ<100 when age2<=2
urin<-urin %>%
  filter(!(age2<=2 & (educ<100)) & !(period==5 & age2==1))
write.dta(urin, "All-UR-In.dta")
urout<-urout %>%
  filter(!(age2<=2 & (educ<100)) & !(period==5 & age2==1))
write.dta(urout, "All-UR-Out.dta")
corin<-corin %>%
  filter(!(age2<=2 & (educ<100)) & !(period==5 & age2==1))
write.dta(corin, "All-COR-In.dta")
corout<-corout %>%
  filter(!(age2<=2 & (educ<100)) & !(period==5 & age2==1))
write.dta(corout, "All-COR-Out.dta")

#6. The PYARS by rural/urban should reflect the proportion urban in a given country at the time of census. Note, the PYARS needs to be divided by the period (3 or 5 years) to get the population estimates.
#7. The sum of the rural and urban PYARS should sum up to the total population size of the country (total PYARS multiplied by the period).
check6in<-urin %>%
  filter(age2==100 & educ==100 & sex==100)
gh00<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/5-year in/GH_2000.dta")
gh00<-gh00 %>%
  mutate(prov_5_ur=ifelse(is.na(prov_5_ur), prov_act_ur, prov_5_ur))
data<-data.table(country="GH", year=2000, pop=sum(gh00$perwt), urban_act=sum(gh00$perwt[gh00$urban=="Urban"])/sum(gh00$perwt),
                 urban5=sum(gh00$perwt[gh00$prov_5_ur==1])/sum(gh00$perwt), pyarurban=324775.0, pyarrural=621450.0)
mu90<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/5-year in/MU_1990.dta")
mu90<-mu90 %>%
  mutate(prov_5_ur=ifelse(is.na(prov_5_ur), prov_act_ur, prov_5_ur))
data<-bind_rows(data, 
                data.table(country="MU", year=1990, pop=sum(mu90$perwt), urban_act=sum(mu90$perwt[mu90$urban=="Urban"])/sum(mu90$perwt),
                           urban5=sum(mu90$perwt[mu90$prov_5_ur==1])/sum(mu90$perwt), pyarurban=230075.0, pyarrural=302325.0))
mu00<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/5-year in/MU_2000.dta")
mu00<-mu00 %>%
  mutate(prov_5_ur=ifelse(is.na(prov_5_ur), prov_act_ur, prov_5_ur))
data<-bind_rows(data, 
                data.table(country="MU", year=2000, pop=sum(mu00$perwt), urban_act=sum(mu00$perwt[mu00$urban=="Urban"])/sum(mu00$perwt),
                           urban5=sum(mu00$perwt[mu00$prov_5_ur==1])/sum(mu00$perwt), pyarurban=250000.0, pyarrural=345175.0))
mu11<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/5-year in/MU_2011.dta")
mu11<-mu11 %>%
  mutate(prov_5_ur=ifelse(is.na(prov_5_ur), prov_act_ur, prov_5_ur))
data<-bind_rows(data, 
                data.table(country="MU", year=2011, pop=sum(mu11$perwt), urban_act=sum(mu11$perwt[mu11$urban=="Urban"])/sum(mu11$perwt),
                           urban5=sum(mu11$perwt[mu11$prov_5_ur==1])/sum(mu11$perwt), pyarurban=250425.0, pyarrural=381225.0))
sn02<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/5-year in/SN_2002.dta")
sn02<-sn02 %>%
  mutate(prov_5_ur=ifelse(is.na(prov_5_ur), prov_act_ur, prov_5_ur))
data<-bind_rows(data, 
                data.table(country="SN", year=2002, pop=sum(sn02$perwt), urban_act=sum(sn02$perwt[sn02$urban=="Urban"])/sum(sn02$perwt),
                           urban5=sum(sn02$perwt[sn02$prov_5_ur==1])/sum(sn02$perwt), pyarurban=546275.0, pyarrural=1930100.0))
za01<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/5-year in/ZA_2001.dta")
za01<-za01 %>%
  mutate(prov_5_ur=ifelse(is.na(prov_5_ur), prov_act_ur, prov_5_ur))
data<-bind_rows(data, 
                data.table(country="ZA", year=2001, pop=sum(za01$perwt), urban_act=sum(za01$perwt[za01$urban=="Urban"])/sum(za01$perwt),
                           urban5=sum(za01$perwt[za01$prov_5_ur==1])/sum(za01$perwt), pyarurban=1430693.8, pyarrural=805773.0))
bj92<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/3-year in/BJ_1992.dta")
bj92<-bj92 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="BJ", year=1992, pop=sum(bj92$perwt), urban_act=sum(bj92$perwt[bj92$urban=="Urban"])/sum(bj92$perwt),
                           urban3=sum(bj92$perwt[bj92$prov_3_ur==1])/sum(bj92$perwt), pyarurban=134962.5, pyarrural=1111087.5))
bj02<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/3-year in/BJ_2002.dta")
bj02<-bj02 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="BJ", year=2002, pop=sum(bj02$perwt), urban_act=sum(bj02$perwt[bj02$urban=="Urban"])/sum(bj02$perwt),
                           urban3=sum(bj02$perwt[bj02$prov_3_ur==1])/sum(bj02$perwt), pyarurban=16750.0, pyarrural=153962.5))
bj13<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/3-year in/BJ_2013.dta")
bj13<-bj13 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="BJ", year=2013, pop=sum(bj13$perwt), urban_act=sum(bj13$perwt[bj13$urban=="Urban"])/sum(bj13$perwt),
                           urban3=sum(bj13$perwt[bj13$prov_3_ur==1])/sum(bj13$perwt), pyarurban=43225.0, pyarrural=208462.5))
cm87<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/3-year in/CM_1987.dta")
cm87<-cm87 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="CM", year=1987, pop=sum(cm87$perwt), urban_act=sum(cm87$perwt[cm87$urban=="Urban"])/sum(cm87$perwt),
                           urban3=sum(cm87$perwt[cm87$prov_3_ur==1])/sum(cm87$perwt), pyarurban=153675.0, pyarrural=963425.0))
cm05<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/3-year in/CM_2005.dta")
cm05<-cm05 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="CM", year=2005, pop=sum(cm05$perwt), urban_act=sum(cm05$perwt[cm05$urban=="Urban"])/sum(cm05$perwt),
                           urban3=sum(cm05$perwt[cm05$prov_3_ur==1])/sum(cm05$perwt), pyarurban=786137.5, pyarrural=1425687.5))
eg86<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/3-year in/EG_1986.dta")
eg86<-eg86 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="EG", year=1986, pop=sum(eg86$perwt), urban_act=sum(eg86$perwt[eg86$urban=="Urban"])/sum(eg86$perwt),
                           urban3=sum(eg86$perwt[eg86$prov_3_ur==1])/sum(eg86$perwt), pyarurban=320377.9, pyarrural=540968.2))
eg96<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/3-year in/EG_1996.dta")
eg96<-eg96 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="EG", year=1996, pop=sum(eg96$perwt), urban_act=sum(eg96$perwt[eg96$urban=="Urban"])/sum(eg96$perwt),
                           urban3=sum(eg96$perwt[eg96$prov_3_ur==1])/sum(eg96$perwt), pyarurban=421808.3, pyarrural=1060630.8))
eg06<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/3-year in/EG_2006.dta")
eg06<-eg06 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="EG", year=2006, pop=sum(eg06$perwt), urban_act=sum(eg06$perwt[eg06$urban=="Urban"])/sum(eg06$perwt),
                           urban3=sum(eg06$perwt[eg06$prov_3_ur==1])/sum(eg06$perwt), pyarurban=509475.0, pyarrural=1310800.0))
gn96<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/3-year in/GN_1996.dta")
gn96<-gn96 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="GN", year=1996, pop=sum(gn96$perwt), urban_act=sum(gn96$perwt[gn96$urban=="Urban"])/sum(gn96$perwt),
                           urban3=sum(gn96$perwt[gn96$prov_3_ur==1])/sum(gn96$perwt), pyarurban=288412.5, pyarrural=1504537.5))
gn14<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/3-year in/GN_2014.dta")
gn14<-gn14 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="GN", year=2014, pop=sum(gn14$perwt), urban_act=sum(gn14$perwt[gn14$urban=="Urban"])/sum(gn14$perwt),
                           urban3=sum(gn14$perwt[gn14$prov_3_ur==1])/sum(gn14$perwt), pyarurban=56200.0, pyarrural=205712.5))
ml98<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/3-year in/ML_1998.dta")
ml98<-ml98 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="ML", year=1998, pop=sum(ml98$perwt), urban_act=sum(ml98$perwt[ml98$urban=="Urban"])/sum(ml98$perwt),
                           urban3=sum(ml98$perwt[ml98$prov_3_ur==1])/sum(ml98$perwt), pyarurban=25250.0, pyarrural=222150.0))
ml09<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/3-year in/ML_2009.dta")
ml09<-ml09 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="ML", year=2009, pop=sum(ml09$perwt), urban_act=sum(ml09$perwt[ml09$urban=="Urban"])/sum(ml09$perwt),
                           urban3=sum(ml09$perwt[ml09$prov_3_ur==1])/sum(ml09$perwt), pyarurban=59487.5, pyarrural=301637.5))
mw08<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/3-year in/MW_2008.dta")
mw08<-mw08 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="MW", year=2008, pop=sum(mw08$perwt), urban_act=sum(mw08$perwt[mw08$urban=="Urban"])/sum(mw08$perwt),
                           urban3=sum(mw08$perwt[mw08$prov_3_ur==1])/sum(mw08$perwt), pyarurban=25725.0, pyarrural=309337.5))
rw02<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/3-year in/RW_2002.dta")
rw02<-rw02 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="RW", year=2002, pop=sum(rw02$perwt), urban_act=sum(rw02$perwt[rw02$urban=="Urban"])/sum(rw02$perwt),
                           urban3=sum(rw02$perwt[rw02$prov_3_ur==1])/sum(rw02$perwt), pyarurban=0, pyarrural=1052650.0))
rw12<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/3-year in/no migyrs1/RW_2012.dta")
rw12<-rw12 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data,
                data.table(country="RW", year=2012, pop=sum(rw12$perwt), urban_act=sum(rw12$perwt[rw12$urban=="Urban"])/sum(rw12$perwt),
                           urban3=sum(rw12$perwt[rw12$prov_3_ur==1])/sum(rw12$perwt), pyarurban=141225.0, pyarrural=1156725.0))
sl04<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/3-year in/no migyrs1/SL_2004.dta")
sl04<-sl04 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data,
                data.table(country="SL", year=2004, pop=sum(sl04$perwt), urban_act=sum(sl04$perwt[sl04$urban=="Urban"])/sum(sl04$perwt),
                           urban3=sum(sl04$perwt[sl04$prov_3_ur==1])/sum(sl04$perwt), pyarurban=231550.0, pyarrural=1004200.0))
tg10<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/3-year in/TG_2010.dta")
tg10<-tg10 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="TG", year=2010, pop=sum(tg10$perwt), urban_act=sum(tg10$perwt[tg10$urban=="Urban"])/sum(tg10$perwt),
                           urban3=sum(tg10$perwt[tg10$prov_3_ur==1])/sum(tg10$perwt), pyarurban=644660.4, pyarrural=920845.5))
ug91<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/3-year in/UG_1991.dta")
ug91<-ug91 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="UG", year=1991, pop=sum(ug91$perwt), urban_act=sum(ug91$perwt[ug91$urban=="Urban"])/sum(ug91$perwt),
                           urban3=sum(ug91$perwt[ug91$prov_3_ur==1])/sum(ug91$perwt), pyarurban=17652.5, pyarrural=398553.7))
ug02<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/3-year in/UG_2002.dta")
ug02<-ug02 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="UG", year=2002, pop=sum(ug02$perwt), urban_act=sum(ug02$perwt[ug02$urban=="Urban"])/sum(ug02$perwt),
                           urban3=sum(ug02$perwt[ug02$prov_3_ur==1])/sum(ug02$perwt), pyarurban=29475.0, pyarrural=594050.0))
za07<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/3-year in/no migyrs1/ZA_2007.dta")
za07<-za07 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data,
                data.table(country="ZA", year=2007, pop=sum(za07$perwt), urban_act=sum(za07$perwt[za07$urban=="Urban"])/sum(za07$perwt),
                           urban3=sum(za07$perwt[za07$prov_3_ur==1])/sum(za07$perwt), pyarurban=774815.8, pyarrural=405262.0))
za11<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/3-year in/no migyrs1/ZA_2011.dta")
za11<-za11 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data,
                data.table(country="ZA", year=2011, pop=sum(za11$perwt), urban_act=sum(za11$perwt[za11$urban=="Urban"])/sum(za11$perwt),
                           urban3=sum(za11$perwt[za11$prov_3_ur==1])/sum(za11$perwt), pyarurban=874916.0, pyarrural=419113.3))
bf06<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/1-year in/BF_2006.dta")
bf06<-bf06 %>%
  mutate(prov_1_ur=ifelse(is.na(prov_1_ur), prov_act_ur, prov_1_ur))
data<-bind_rows(data, 
                data.table(country="BF", year=2006, pop=sum(bf06$perwt), urban_act=sum(bf06$perwt[bf06$urban=="Urban"])/sum(bf06$perwt),
                           urban1=sum(bf06$perwt[bf06$prov_1_ur==1])/sum(bf06$perwt), pyarurban=136325.00, pyarrural=571120.00))
bw91<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/1-year in/BW_1991.dta")
bw91<-bw91 %>%
  mutate(prov_1_ur=ifelse(is.na(prov_1_ur), prov_act_ur, prov_1_ur))
data<-bind_rows(data, 
                data.table(country="BW", year=1991, pop=sum(bw91$perwt), urban_act=sum(bw91$perwt[bw91$urban=="Urban"])/sum(bw91$perwt),
                           urban1=sum(bw91$perwt[bw91$prov_1_ur==1])/sum(bw91$perwt), pyarurban=91795.00, pyarrural=303805.00))
ke79<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/1-year in/KE_1979.dta")
ke79<-ke79 %>%
  mutate(prov_1_ur=ifelse(is.na(prov_1_ur), prov_act_ur, prov_1_ur))
data<-bind_rows(data, 
                data.table(country="KE", year=1979, pop=sum(ke79$perwt), urban_act=sum(ke79$perwt[ke79$urban=="Urban"])/sum(ke79$perwt),
                           urban1=sum(ke79$perwt[ke79$prov_1_ur==1])/sum(ke79$perwt), pyarurban=21240.63, pyarrural=743951.38))
ke89<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/1-year in/KE_1989.dta")
ke89<-ke89 %>%
  mutate(prov_1_ur=ifelse(is.na(prov_1_ur), prov_act_ur, prov_1_ur))
data<-bind_rows(data, 
                data.table(country="KE", year=1989, pop=sum(ke89$perwt), urban_act=sum(ke89$perwt[ke89$urban=="Urban"])/sum(ke89$perwt),
                           urban1=sum(ke89$perwt[ke89$prov_1_ur==1])/sum(ke89$perwt), pyarurban=64280.00, pyarrural=1008880.00))
ke99<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/1-year in/KE_1999.dta")
ke99<-ke99 %>%
  mutate(prov_1_ur=ifelse(is.na(prov_1_ur), prov_act_ur, prov_1_ur))
data<-bind_rows(data, 
                data.table(country="KE", year=1999, pop=sum(ke99$perwt), urban_act=sum(ke99$perwt[ke99$urban=="Urban"])/sum(ke99$perwt),
                           urban1=sum(ke99$perwt[ke99$prov_1_ur==1])/sum(ke99$perwt), pyarurban=98240.00, pyarrural=1299760.00))
ke09<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/1-year in/KE_2009.dta")
ke09<-ke09 %>%
  mutate(prov_1_ur=ifelse(is.na(prov_1_ur), prov_act_ur, prov_1_ur))
data<-bind_rows(data, 
                data.table(country="KE", year=2009, pop=sum(ke09$perwt), urban_act=sum(ke09$perwt[ke09$urban=="Urban"])/sum(ke09$perwt),
                           urban1=sum(ke09$perwt[ke09$prov_1_ur==1])/sum(ke09$perwt), pyarurban=29915.00, pyarrural=354045.00))
mw87<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/1-year in/MW_1987.dta")
mw87<-mw87 %>%
  mutate(prov_1_ur=ifelse(is.na(prov_1_ur), prov_act_ur, prov_1_ur))
data<-bind_rows(data, 
                data.table(country="MW", year=1987, pop=sum(mw87$perwt), urban_act=sum(mw87$perwt[mw87$urban=="Urban"])/sum(mw87$perwt),
                           urban1=sum(mw87$perwt[mw87$prov_1_ur==1])/sum(mw87$perwt), pyarurban=29920.00, pyarrural=366255.00))
mz97<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/1-year in/MZ_1997.dta")
mz97<-mz97 %>%
  mutate(prov_1_ur=ifelse(is.na(prov_1_ur), prov_act_ur, prov_1_ur))
data<-bind_rows(data, 
                data.table(country="MZ", year=1997, pop=sum(mz97$perwt), urban_act=sum(mz97$perwt[mz97$urban=="Urban"])/sum(mz97$perwt),
                           urban1=sum(mz97$perwt[mz97$prov_1_ur==1])/sum(mz97$perwt), pyarurban=90515.00, pyarrural=683095.00))
mz07<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/1-year in/MZ_2007.dta")
mz07<-mz07 %>%
  mutate(prov_1_ur=ifelse(is.na(prov_1_ur), prov_act_ur, prov_1_ur))
data<-bind_rows(data, 
                data.table(country="MZ", year=2007, pop=sum(mz07$perwt), urban_act=sum(mz07$perwt[mz07$urban=="Urban"])/sum(mz07$perwt),
                           urban1=sum(mz07$perwt[mz07$prov_1_ur==1])/sum(mz07$perwt), pyarurban=23475.00, pyarrural=180900.00))
sd08<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/1-year in/SD_2008.dta")
sd08<-sd08 %>%
  mutate(prov_1_ur=ifelse(is.na(prov_1_ur), prov_act_ur, prov_1_ur))
data<-bind_rows(data, 
                data.table(country="SD", year=2008, pop=sum(sd08$perwt), urban_act=sum(sd08$perwt[sd08$urban=="Urban"])/sum(sd08$perwt),
                           urban1=sum(sd08$perwt[sd08$prov_1_ur==1])/sum(sd08$perwt), pyarurban=51460.40, pyarrural=250713.91))
ss08<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/1-year in/SS_2008.dta")
ss08<-ss08 %>%
  mutate(prov_1_ur=ifelse(is.na(prov_1_ur), prov_act_ur, prov_1_ur))
data<-bind_rows(data, 
                data.table(country="SS", year=2008, pop=sum(ss08$perwt), urban_act=sum(ss08$perwt[ss08$urban=="Urban"])/sum(ss08$perwt),
                           urban1=sum(ss08$perwt[ss08$prov_1_ur==1])/sum(ss08$perwt), pyarurban=0, pyarrural=767636.42))
tz02<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/1-year in/TZ_2002.dta")
tz02<-tz02 %>%
  mutate(prov_1_ur=ifelse(is.na(prov_1_ur), prov_act_ur, prov_1_ur))
data<-bind_rows(data, 
                data.table(country="TZ", year=2002, pop=sum(tz02$perwt), urban_act=sum(tz02$perwt[tz02$urban=="Urban"])/sum(tz02$perwt),
                           urban1=sum(tz02$perwt[tz02$prov_1_ur==1])/sum(tz02$perwt), pyarurban=26352.03, pyarrural=308521.01))
tz12<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/1-year in/TZ_2012.dta")
tz12<-tz12 %>%
  mutate(prov_1_ur=ifelse(is.na(prov_1_ur), prov_act_ur, prov_1_ur))
data<-bind_rows(data, 
                data.table(country="TZ", year=2012, pop=sum(tz12$perwt), urban_act=sum(tz12$perwt[tz12$urban=="Urban"])/sum(tz12$perwt),
                           urban1=sum(tz12$perwt[tz12$prov_1_ur==1])/sum(tz12$perwt), pyarurban=47294.63, pyarrural=392223.92))
zm90<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/1-year in/ZM_1990.dta")
zm90<-zm90 %>%
  mutate(prov_1_ur=ifelse(is.na(prov_1_ur), prov_act_ur, prov_1_ur))
data<-bind_rows(data, 
                data.table(country="ZM", year=1990, pop=sum(zm90$perwt), urban_act=sum(zm90$perwt[zm90$urban=="Urban"])/sum(zm90$perwt),
                           urban1=sum(zm90$perwt[zm90$prov_1_ur==1])/sum(zm90$perwt), pyarurban=257635.00, pyarrural=529405.00))
zm00<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/africa calibrate rates/1-year in/ZM_2000.dta")
zm00<-zm00 %>%
  mutate(prov_1_ur=ifelse(is.na(prov_1_ur), prov_act_ur, prov_1_ur))
data<-bind_rows(data, 
                data.table(country="ZM", year=2000, pop=sum(zm00$perwt), urban_act=sum(zm00$perwt[zm00$urban=="Urban"])/sum(zm00$perwt),
                           urban1=sum(zm00$perwt[zm00$prov_1_ur==1])/sum(zm00$perwt), pyarurban=151170.00, pyarrural=345775.00))
data<-data %>%
  mutate(pyarur=pyarurban/(pyarurban+pyarrural)) %>%
  bind_cols(data.table(period=c(rep(5, 6), rep(2.5, 21), rep(1, 15)))) %>%
  mutate(pyarpop=(pyarurban+pyarrural)/period)
data<-data %>%
  mutate(check1=(pyarur>=urban5 & pyarur<=urban_act), 
         check1=ifelse(is.na(urban5), NA, check1),
         check2=(pyarur>=urban3 & pyarur<=urban_act),
         check2=ifelse(is.na(urban3), NA, check2), 
         check3=(pyarur>=urban1 & pyarur<=urban_act),
         check3=ifelse(is.na(urban1), NA, check3))
write.dta(data, "PYARcheck.dta")

#8.	Proportions of urban PYARS increase over time in countries with multiple census. 
