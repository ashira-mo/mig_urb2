#first setwd

`%notin%` <- Negate(`%in%`)
library(pacman)
pacman::p_load(foreign, readxl, data.table, readstata13, car, stringi, readxl, gdata, labelled, ipumsr, readstata13, dplyr, tidyr, tidyverse, gmodels)
geomig1<-read.dta13("geomig1_1.dta") %>%
  rename(code=var1, geomig1_1=var2) %>%
  mutate(code=as.integer(code)) %>%
  filter(!is.na(code))
geolev1<-read_excel("geolev1.xlsx")
geolev2<-read.dta13("geolev2.dta")
geolev1_mw<-read.dta("geolev1_mw.dta") %>%
  rename(country=COUNTRY, year=YEAR, sample=SAMPLE, serial=SERIAL, pernum=PERNUM, geo1_mw=GEO1_MW) %>%
  mutate(country="Malawi", year=as.character(year))

#boswana91, geolev1
bw91<-read.dta13("Botswana1991.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.453
sample<-sum(bw91$perwt)
lev1<-bw91 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-bw91 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.453/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
bw91<-bw91 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig1, by="geomig1_1") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_1_ur=ur, prov_1_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate1 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 72099, 
                              ifelse(migrate1=="Abroad", 72097,
                                     ifelse(migrate1 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 72098, geomig1_pcode))),
         prov_1_ur=ifelse(geomig1_pcode==72099, NA, 
                          ifelse(geomig1_pcode==72097, 5, 
                                 ifelse(geomig1_pcode %in% c(72098, NA), 9, prov_1_ur))), 
         prov_1_usr=ifelse(geomig1_pcode==72099, NA,
                           ifelse(geomig1_pcode==72097, 5,
                                  ifelse(geomig1_pcode %in% c(72098, NA), 9, prov_1_usr))),
         prov_act_cor=ifelse(geolev1==72097, 5, 
                             ifelse(geolev1 %in% c(72098, 72099, NA), 9,
                                    ifelse(geolev1==72001, 2, #72001 Gaborone, the capital 
                                           ifelse(geolev1 %notin% c(72097, 72098, 72099, NA, 72001) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(72097, 72098, 72099, NA, 72001) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_1_cor=ifelse(geomig1_pcode==72099, NA,
                           ifelse(geomig1_pcode==72001, 2, 
                                  ifelse(geomig1_pcode!=72001 & prov_1_usr==5, 5,
                                         ifelse(geomig1_pcode!=72001 & prov_1_usr==9, 9,
                                                ifelse(geomig1_pcode!=72001 & prov_1_usr==0, 0,
                                                       ifelse(geomig1_pcode!=72001 & (prov_1_usr==1 | prov_1_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) %>% sample_frac(0.2)
write.dta(bw91, "/africa calibrate rates/1-year in/BW_1991.dta")
write.dta(bw91, "/africa calibrate rates/1-year out/BW_1991.dta")

#BurkinaFaso 1996, external source, migbf and geolev2
external<-read.dta13("/external source/africa/bf96.dta") %>%
  mutate(urban=as.numeric(gsub(",", ".", gsub("\\.", "", urban)))/100, 
         popurban=ifelse(is.na(as.numeric(popurban)), 0, as.numeric(popurban)), 
         urban=ifelse(is.na(urban), 0, urban))  %>%
  mutate(pop=popurban+poprural, pop=pop/sum(pop)) %>%
  rename(geolev2=code)
bf96<-read.dta13("BurkinaFaso1996.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.154
sum(external$urban*external$pop)
lev1<-external %>%
  mutate(urban=urban*WUP/sum(external$urban*external$pop)) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
bf96<-bf96 %>%
  left_join(lev1[,c("geolev2", "usr", "ur")], by="geolev2") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  mutate(migbf=paste0(migbf, " [Province: Burkina Faso]")) %>%
  left_join(geolev2, by=c("migbf"="var2")) %>%
  rename(geomig1_pcode=var1) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev2", "usr", "ur")], by=c("geomig1_pcode"="geolev2")) %>%
  rename(prov_1_ur=ur, prov_1_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         migbf=stri_sub(migbf, 1, -26),
         #verify that geomig1_pcode is coded consistently with migrate1
         geomig1_pcode=ifelse(migrate1 %in% c("NIU (Not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 854099, #generated
                              ifelse(migbf=="Abroad", 854097, #generated
                                     ifelse(migbf %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), NA, geomig1_pcode))),
         prov_1_ur=ifelse(geomig1_pcode==854099, NA, 
                          ifelse(geomig1_pcode==854097, 5, #360097 abroad
                                 ifelse(is.na(geomig1_pcode), 9, prov_1_ur))), #360098 unknown
         prov_1_usr=ifelse(geomig1_pcode==854099, NA,
                           ifelse(geomig1_pcode==854097, 5,
                                  ifelse(is.na(geomig1_pcode), 9, prov_1_usr))),
         prov_act_cor=ifelse(geolev2==854097, 5, 
                             ifelse(geolev2 %in% c(854099, NA), 9,
                                    ifelse(geolev2==854003011, 2, #854003011 Kadiogo, the capital 
                                           ifelse(geolev2 %notin% c(854097, 854099, NA, 854003011) & prov_act_usr==0, 0, 
                                                  ifelse(geolev2 %notin% c(854097, 854099, NA, 854003011) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_1_cor=ifelse(geomig1_pcode==854099, NA,
                           ifelse(geomig1_pcode==854003011, 2, 
                                  ifelse(geomig1_pcode!=854003011 & prov_1_usr==5, 5,
                                         ifelse(geomig1_pcode!=854003011 & prov_1_usr==9, 9,
                                                ifelse(geomig1_pcode!=854003011 & prov_1_usr==0, 0,
                                                       ifelse(geomig1_pcode!=854003011 & (prov_1_usr==1 | prov_1_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
# %>% sample_frac(0.1)
write.dta(bf96, "/africa calibrate rates/1-year in/BF_1996.dta")
write.dta(bf96, "/africa calibrate rates/1-year out/BF_1996.dta")

#BurkinaFaso 2006, migbf and geolev2
bf06<-read.dta13("BurkinaFaso2006.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.223
sample<-sum(bf06$perwt)
lev1<-bf06 %>%
  group_by(geolev2) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-bf06 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.223/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
bf06<-bf06 %>%
  left_join(lev1[,c("geolev2", "usr", "ur")], by="geolev2") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  mutate(migbf=paste0(migbf, " [Province: Burkina Faso]")) %>%
  left_join(geolev2, by=c("migbf"="var2")) %>%
  rename(geomig1_pcode=var1) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev2", "usr", "ur")], by=c("geomig1_pcode"="geolev2")) %>%
  rename(prov_1_ur=ur, prov_1_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         migbf=stri_sub(migbf, 1, -26),
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate1 %in% c("NIU (Not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 854099, #generated
                              ifelse(migbf=="Abroad", 854097, #generated
                                     ifelse(migbf %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), NA, geomig1_pcode))),
         prov_1_ur=ifelse(geomig1_pcode==854099, NA, 
                          ifelse(geomig1_pcode==854097, 5, #360097 abroad
                                 ifelse(is.na(geomig1_pcode), 9, prov_1_ur))), #360098 unknown
         prov_1_usr=ifelse(geomig1_pcode==854099, NA,
                           ifelse(geomig1_pcode==854097, 5,
                                  ifelse(is.na(geomig1_pcode), 9, prov_1_usr))),
         prov_act_cor=ifelse(geolev2==854097, 5, 
                             ifelse(geolev2 %in% c(854099, NA), 9,
                                    ifelse(geolev2==854003011, 2, #854003011 Kadiogo, the capital 
                                           ifelse(geolev2 %notin% c(854097, 854099, NA, 854003011) & prov_act_usr==0, 0, 
                                                  ifelse(geolev2 %notin% c(854097, 854099, NA, 854003011) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_1_cor=ifelse(geomig1_pcode==854099, NA,
                           ifelse(geomig1_pcode==854003011, 2, 
                                  ifelse(geomig1_pcode!=854003011 & prov_1_usr==5, 5,
                                         ifelse(geomig1_pcode!=854003011 & prov_1_usr==9, 9,
                                                ifelse(geomig1_pcode!=854003011 & prov_1_usr==0, 0,
                                                       ifelse(geomig1_pcode!=854003011 & (prov_1_usr==1 | prov_1_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
#%>% sample_frac(0.1)
write.dta(bf06, "/africa calibrate rates/1-year in/BF_2006.dta")
write.dta(bf06, "/africa calibrate rates/1-year out/BF_2006.dta")

#Kenya 1979
ke79<-read.dta13("Kenya1979.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.154
sample<-sum(ke79$perwt)
lev1<-ke79 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-ke79 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.154/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
ke79<-ke79 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig1, by="geomig1_1") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_1_ur=ur, prov_1_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate1 %in% c("NIU (Not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 404099, 
                              ifelse(migrate1=="Abroad", 404097, 
                                     ifelse(migrate1 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 404098, geomig1_pcode))),
         prov_1_ur=ifelse(geomig1_pcode==404099, NA, 
                          ifelse(geomig1_pcode==404097, 5, #360097 abroad
                                 ifelse(geomig1_pcode %in% c(404098, NA), 9, prov_1_ur))), #360098 unknown
         prov_1_usr=ifelse(geomig1_pcode==404099, NA,
                           ifelse(geomig1_pcode==404097, 5,
                                  ifelse(geomig1_pcode %in% c(404098, NA), 9, prov_1_usr))),
         prov_act_cor=ifelse(geolev1==404097, 5, 
                             ifelse(geolev1 %in% c(404098, 404099, NA), 9,
                                    ifelse(geolev1==404001, 2, #404001 Nairobi, the capital 
                                           ifelse(geolev1 %notin% c(404097, 404098, 404099, NA, 404001) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(404097, 404098, 404099, NA, 404001) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_1_cor=ifelse(geomig1_pcode==404099,NA,
                           ifelse(geomig1_pcode==404001, 2,
                                  ifelse(geomig1_pcode!=404001 & prov_1_usr==5, 5,
                                         ifelse(geomig1_pcode!=404001 & prov_1_usr==9, 9,
                                                ifelse(geomig1_pcode!=404001 & prov_1_usr==0, 0,
                                                       ifelse(geomig1_pcode!=404001 & (prov_1_usr==1 | prov_1_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
#%>% sample_frac(0.1)
write.dta(ke79, "/africa calibrate rates/1-year in/KE_1979.dta")
write.dta(ke79, "/africa calibrate rates/1-year out/KE_1979.dta")

#Kenya 1989
ke89<-read.dta13("Kenya1989.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.165
sample<-sum(ke89$perwt)
lev1<-ke89 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-ke89 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.165/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
ke89<-ke89 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig1, by="geomig1_1") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_1_ur=ur, prov_1_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate1 %in% c("NIU (Not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 404099, 
                              ifelse(migrate1=="Abroad", 404097, 
                                     ifelse(migrate1 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 404098, geomig1_pcode))),
         prov_1_ur=ifelse(geomig1_pcode==404099, NA, 
                          ifelse(geomig1_pcode==404097, 5, 
                                 ifelse(geomig1_pcode %in% c(404098, NA), 9, prov_1_ur))), 
         prov_1_usr=ifelse(geomig1_pcode==404099, NA,
                           ifelse(geomig1_pcode==404097, 5,
                                  ifelse(geomig1_pcode %in% c(404098, NA), 9, prov_1_usr))),
         prov_act_cor=ifelse(geolev1==404097, 5, 
                             ifelse(geolev1 %in% c(404098, 404099, NA), 9,
                                    ifelse(geolev1==404001, 2, #404001 Nairobi, the capital 
                                           ifelse(geolev1 %notin% c(404097, 404098, 404099, NA, 404001) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(404097, 404098, 404099, NA, 404001) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_1_cor=ifelse(geomig1_pcode==404099,NA,
                           ifelse(geomig1_pcode==404001, 2,
                                  ifelse(geomig1_pcode!=404001 & prov_1_usr==5, 5,
                                         ifelse(geomig1_pcode!=404001 & prov_1_usr==9, 9,
                                                ifelse(geomig1_pcode!=404001 & prov_1_usr==0, 0,
                                                       ifelse(geomig1_pcode!=404001 & (prov_1_usr==1 | prov_1_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
#%>% sample_frac(0.1)
write.dta(ke89, "/africa calibrate rates/1-year in/KE_1989.dta")
write.dta(ke89, "/africa calibrate rates/1-year out/KE_1989.dta")

#Kenya 1999
ke99<-read.dta13("Kenya1999.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.196
sample<-sum(ke99$perwt)
lev1<-ke99 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-ke99 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.196/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
ke99<-ke99 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig1, by="geomig1_1") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_1_ur=ur, prov_1_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate1 %in% c("NIU (Not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 404099, 
                              ifelse(migrate1=="Abroad", 404097, 
                                     ifelse(migrate1 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 404098, geomig1_pcode))),
         prov_1_ur=ifelse(geomig1_pcode==404099, NA, 
                          ifelse(geomig1_pcode==404097, 5, 
                                 ifelse(geomig1_pcode %in% c(404098, NA), 9, prov_1_ur))), 
         prov_1_usr=ifelse(geomig1_pcode==404099, NA,
                           ifelse(geomig1_pcode==404097, 5,
                                  ifelse(geomig1_pcode %in% c(404098, NA), 9, prov_1_usr))),
         prov_act_cor=ifelse(geolev1==404097, 5, 
                             ifelse(geolev1 %in% c(404098, 404099, NA), 9,
                                    ifelse(geolev1==404001, 2, #404001 Nairobi, the capital 
                                           ifelse(geolev1 %notin% c(404097, 404098, 404099, NA, 404001) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(404097, 404098, 404099, NA, 404001) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_1_cor=ifelse(geomig1_pcode==404099,NA,
                           ifelse(geomig1_pcode==404001, 2,
                                  ifelse(geomig1_pcode!=404001 & prov_1_usr==5, 5,
                                         ifelse(geomig1_pcode!=404001 & prov_1_usr==9, 9,
                                                ifelse(geomig1_pcode!=404001 & prov_1_usr==0, 0,
                                                       ifelse(geomig1_pcode!=404001 & (prov_1_usr==1 | prov_1_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
#%>% sample_frac(0.1)
write.dta(ke99, "/africa calibrate rates/1-year in/KE_1999.dta")
write.dta(ke99, "/africa calibrate rates/1-year out/KE_1999.dta")

#Kenya 2009
ke09<-read.dta13("Kenya2009.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.232
sample<-sum(ke09$perwt)
lev1<-ke09 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-ke09 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.232/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
ke09<-ke09 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig1, by="geomig1_1") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_1_ur=ur, prov_1_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate1 %in% c("NIU (Not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 404099, 
                              ifelse(migrate1=="Abroad", 404097, 
                                     ifelse(migrate1 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 404098, geomig1_pcode))),
         prov_1_ur=ifelse(geomig1_pcode==404099, NA, 
                          ifelse(geomig1_pcode==404097, 5, 
                                 ifelse(geomig1_pcode %in% c(404098, NA), 9, prov_1_ur))), 
         prov_1_usr=ifelse(geomig1_pcode==404099, NA,
                           ifelse(geomig1_pcode==404097, 5,
                                  ifelse(geomig1_pcode %in% c(404098, NA), 9, prov_1_usr))),
         prov_act_cor=ifelse(geolev1==404097, 5, 
                             ifelse(geolev1 %in% c(404098, 404099, NA), 9,
                                    ifelse(geolev1==404001, 2, #404001 Nairobi, the capital 
                                           ifelse(geolev1 %notin% c(404097, 404098, 404099, NA, 404001) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(404097, 404098, 404099, NA, 404001) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_1_cor=ifelse(geomig1_pcode==404099,NA,
                           ifelse(geomig1_pcode==404001, 2,
                                  ifelse(geomig1_pcode!=404001 & prov_1_usr==5, 5,
                                         ifelse(geomig1_pcode!=404001 & prov_1_usr==9, 9,
                                                ifelse(geomig1_pcode!=404001 & prov_1_usr==0, 0,
                                                       ifelse(geomig1_pcode!=404001 & (prov_1_usr==1 | prov_1_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
#%>% sample_frac(0.05)
write.dta(ke09, "/africa calibrate rates/1-year in/KE_2009.dta")
write.dta(ke09, "/africa calibrate rates/1-year out/KE_2009.dta")

#Malawi 1987, geolev1 not harmonized thus merged with unharmonized geolev1_mw
mw87<-read.dta13("Malawi1987.dta", convert.factors=T) %>%
  mutate(country=as.character(country), year=as.character(year))
mw87<-mw87 %>%
  left_join(geolev1_mw, by=c("country", "year", "sample", "serial", "pernum"))
WUP=0.106
sample<-sum(mw87$perwt)
lev1<-mw87 %>%
  group_by(geo1_mw) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-mw87 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.106/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
mw87<-mw87 %>%
  left_join(lev1[,c("geo1_mw", "usr", "ur")], by="geo1_mw") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig1, by="geomig1_1") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geo1_mw", "usr", "ur")], by=c("geomig1_pcode"="geo1_mw")) %>%
  rename(prov_1_ur=ur, prov_1_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate1 %in% c("NIU (Not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 454999, 
                              ifelse(migrate1=="Abroad", 454997, 
                                     ifelse(migrate1 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 454998, geomig1_pcode))),
         prov_1_ur=ifelse(geomig1_pcode==454999, NA, 
                          ifelse(geomig1_pcode==454997, 5, 
                                 ifelse(geomig1_pcode %in% c(454998, NA), 9, prov_1_ur))), 
         prov_1_usr=ifelse(geomig1_pcode==454999, NA,
                           ifelse(geomig1_pcode==454997, 5,
                                  ifelse(geomig1_pcode %in% c(454998, NA), 9, prov_1_usr))),
         prov_act_cor=ifelse(geo1_mw==454997, 5, 
                             ifelse(geo1_mw %in% c(454998, 454999, NA), 9,
                                    ifelse(geo1_mw==454206, 2, #454206 Lilongwe, the capital 
                                           ifelse(geo1_mw %notin% c(454997, 454998, 454999, NA, 454206) & prov_act_usr==0, 0, 
                                                  ifelse(geo1_mw %notin% c(454997, 454998, 454999, NA, 454206) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_1_cor=ifelse(geomig1_pcode==454999,NA,
                           ifelse(geomig1_pcode==454206, 2,
                                  ifelse(geomig1_pcode!=454206 & prov_1_usr==5, 5,
                                         ifelse(geomig1_pcode!=454206 & prov_1_usr==9, 9,
                                                ifelse(geomig1_pcode!=454206 & prov_1_usr==0, 0,
                                                       ifelse(geomig1_pcode!=454206 & (prov_1_usr==1 | prov_1_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
#%>% sample_frac(0.1)
write.dta(mw87, "/africa calibrate rates/1-year in/MW_1987.dta")
write.dta(mw87, "/africa calibrate rates/1-year out/MW_1987.dta")

#Mozambique 1997
mz97<-read.dta13("Mozambique1997.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.285
sample<-sum(mz97$perwt)
lev1<-mz97 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-mz97 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.285/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
mz97<-mz97 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig1, by="geomig1_1") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_1_ur=ur, prov_1_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate1 %in% c("NIU (Not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 508099, 
                              ifelse(migrate1=="Abroad", 508097, 
                                     ifelse(migrate1 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 508098, geomig1_pcode))),
         prov_1_ur=ifelse(geomig1_pcode==508099, NA, 
                          ifelse(geomig1_pcode==508097, 5, 
                                 ifelse(geomig1_pcode %in% c(508098, NA), 9, prov_1_ur))), 
         prov_1_usr=ifelse(geomig1_pcode==508099, NA,
                           ifelse(geomig1_pcode==508097, 5,
                                  ifelse(geomig1_pcode %in% c(508098, NA), 9, prov_1_usr))),
         prov_act_cor=ifelse(geolev1==508097, 5, 
                             ifelse(geolev1 %in% c(508098, 508099, NA), 9,
                                    ifelse(geolev1==508011, 2, #508011 maputo city, the capital 
                                           ifelse(geolev1 %notin% c(508097, 508098, 508099, NA, 508011) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(508097, 508098, 508099, NA, 508011) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_1_cor=ifelse(geomig1_pcode==508099,NA,
                           ifelse(geomig1_pcode==508011, 2,
                                  ifelse(geomig1_pcode!=508011 & prov_1_usr==5, 5,
                                         ifelse(geomig1_pcode!=508011 & prov_1_usr==9, 9,
                                                ifelse(geomig1_pcode!=508011 & prov_1_usr==0, 0,
                                                       ifelse(geomig1_pcode!=508011 & (prov_1_usr==1 | prov_1_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
#%>% sample_frac(0.1)
write.dta(mz97, "/africa calibrate rates/1-year in/MZ_1997.dta")
write.dta(mz97, "/africa calibrate rates/1-year out/MZ_1997.dta")

#Mozambique 2007
mz07<-read.dta13("Mozambique2007.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.304
sample<-sum(mz07$perwt)
lev1<-mz07 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-mz07 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.304/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
mz07<-mz07 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig1, by="geomig1_1") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_1_ur=ur, prov_1_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate1 %in% c("NIU (Not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 508099, 
                              ifelse(migrate1=="Abroad", 508097, 
                                     ifelse(migrate1 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 508098, geomig1_pcode))),
         prov_1_ur=ifelse(geomig1_pcode==508099, NA, 
                          ifelse(geomig1_pcode==508097, 5, 
                                 ifelse(geomig1_pcode %in% c(508098, NA), 9, prov_1_ur))), 
         prov_1_usr=ifelse(geomig1_pcode==508099, NA,
                           ifelse(geomig1_pcode==508097, 5,
                                  ifelse(geomig1_pcode %in% c(508098, NA), 9, prov_1_usr))),
         prov_act_cor=ifelse(geolev1==508097, 5, 
                             ifelse(geolev1 %in% c(508098, 508099, NA), 9,
                                    ifelse(geolev1==508011, 2, #508011 maputo city, the capital 
                                           ifelse(geolev1 %notin% c(508097, 508098, 508099, NA, 508011) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(508097, 508098, 508099, NA, 508011) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_1_cor=ifelse(geomig1_pcode==508099,NA,
                           ifelse(geomig1_pcode==508011, 2,
                                  ifelse(geomig1_pcode!=508011 & prov_1_usr==5, 5,
                                         ifelse(geomig1_pcode!=508011 & prov_1_usr==9, 9,
                                                ifelse(geomig1_pcode!=508011 & prov_1_usr==0, 0,
                                                       ifelse(geomig1_pcode!=508011 & (prov_1_usr==1 | prov_1_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
#%>%sample_frac(0.1)
write.dta(mz07, "/africa calibrate rates/1-year in/MZ_2007.dta")
write.dta(mz07, "/africa calibrate rates/1-year out/MZ_2007.dta")

#south sudan 2008 and south sudan 2008 combined, skipped
ss08<-read.dta13("Southsudan2008.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.176
sample<-sum(ss08$perwt)
lev1<-ss08 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-ss08 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.176/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
geomig1ss<-geomig1 %>%
  filter(code %in% lev1$geolev1)
#filter(geomig1_1 %in% geomig1_1[grep("\\[State: South Sudan]$", geomig1$geomig1_1, ignore.case = T)])
ss08<-ss08 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  mutate(geomig1_1=stri_sub(geomig1_1, 1, -10)) %>%
  dplyr::left_join(geomig1ss, by="geomig1_1") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_1_ur=ur, prov_1_usr=usr) %>%
  mutate(caseid=paste0("728", as.character((serial*100) + pernum)),
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate1 %in% c("NIU (Not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 728099, #generated 
                              ifelse(migrate1=="Abroad", 728098, 
                                     ifelse(migrate1 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), NA, geomig1_pcode))),
         prov_1_ur=ifelse(geomig1_pcode==728099, NA, 
                          ifelse(geomig1_pcode==728098, 5, 
                                 ifelse(is.na(geomig1_pcode), 9, prov_1_ur))), 
         prov_1_usr=ifelse(geomig1_pcode==728099, NA,
                           ifelse(geomig1_pcode==728098, 5,
                                  ifelse(is.na(geomig1_pcode), 9, prov_1_usr))),
         prov_act_cor=ifelse(geolev1==728098, 5, 
                             ifelse(geolev1 %in% c(728099, NA), 9,
                                    ifelse(geolev1==728092, 2, #729092 Central Equatoria State, the capital 
                                           ifelse(geolev1 %notin% c(728098, 728099, NA, 728092) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(728098, 728099, NA, 728092) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_1_cor=ifelse(geomig1_pcode==728099,NA,
                           ifelse(geomig1_pcode==728092, 2,
                                  ifelse(geomig1_pcode!=728092 & prov_1_usr==5, 5,
                                         ifelse(geomig1_pcode!=728092 & prov_1_usr==9, 9,
                                                ifelse(geomig1_pcode!=728092 & prov_1_usr==0, 0,
                                                       ifelse(geomig1_pcode!=728092 & (prov_1_usr==1 | prov_1_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
#%>% sample_frac(0.1)
sd08<-read.dta13("Sudan2008.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.329
sample<-sum(sd08$perwt)
lev1<-sd08 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-sd08 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.329/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
geomig1sd<-geomig1 %>%
  filter(code %in% lev1$geolev1)
sd08<-sd08 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  mutate(geomig1_1=stri_sub(geomig1_1, 1, -10)) %>%
  dplyr::left_join(geomig1sd, by="geomig1_1") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_1_ur=ur, prov_1_usr=usr) %>%
  mutate(caseid=paste0("729", as.character((serial*100) + pernum)),
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate1 %in% c("NIU (Not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 729099, #generated 
                              ifelse(migrate1=="Abroad", 729098, 
                                     ifelse(migrate1 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), NA, geomig1_pcode))),
         prov_1_ur=ifelse(geomig1_pcode==729099, NA, 
                          ifelse(geomig1_pcode==729098, 5, 
                                 ifelse(is.na(geomig1_pcode), 9, prov_1_ur))), 
         prov_1_usr=ifelse(geomig1_pcode==729099, NA,
                           ifelse(geomig1_pcode==729098, 5,
                                  ifelse(is.na(geomig1_pcode), 9, prov_1_usr))),
         prov_act_cor=ifelse(geolev1==729098, 5, 
                             ifelse(geolev1 %in% c(729099, NA), 9,
                                    ifelse(geolev1==729031, 2, #729031 Khartoum, the capital 
                                           ifelse(geolev1 %notin% c(729098, 729099, NA, 729031) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(729098, 729099, NA, 729031) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_1_cor=ifelse(geomig1_pcode==729099,NA,
                           ifelse(geomig1_pcode==729031, 2,
                                  ifelse(geomig1_pcode!=729031 & prov_1_usr==5, 5,
                                         ifelse(geomig1_pcode!=729031 & prov_1_usr==9, 9,
                                                ifelse(geomig1_pcode!=729031 & prov_1_usr==0, 0,
                                                       ifelse(geomig1_pcode!=729031 & (prov_1_usr==1 | prov_1_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) %>%
#  sample_frac(0.05) %>%
  bind_rows(ss08)
write.dta(sd08, "/africa calibrate rates/1-year in/SD_2008.dta")
write.dta(sd08, "/africa calibrate rates/1-year out/SD_2008.dta")

#Tanzania 2002
tz02<-read.dta13("Tanzania2002.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.23
sample<-sum(tz02$perwt)
lev1<-tz02 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-tz02 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.23/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
tz02<-tz02 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig1, by="geomig1_1") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_1_ur=ur, prov_1_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate1 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 834099, 
                              ifelse(migrate1=="Abroad", 834097,
                                     ifelse(migrate1 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 834098, geomig1_pcode))),
         prov_1_ur=ifelse(geomig1_pcode==834099, NA, 
                          ifelse(geomig1_pcode==834097, 5, 
                                 ifelse(geomig1_pcode %in% c(834098, NA), 9, prov_1_ur))), 
         prov_1_usr=ifelse(geomig1_pcode==834099, NA,
                           ifelse(geomig1_pcode==834097, 5,
                                  ifelse(geomig1_pcode %in% c(834098, NA), 9, prov_1_usr))),
         prov_act_cor=ifelse(geolev1==834097, 5, 
                             ifelse(geolev1 %in% c(834098, 834099, NA), 9,
                                    ifelse(geolev1==834001, 2, #834001 Dodoma, the capital 
                                           ifelse(geolev1 %notin% c(834097, 834098, 834099, NA, 834001) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(834097, 834098, 834099, NA, 834001) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_1_cor=ifelse(geomig1_pcode==834099, NA,
                           ifelse(geomig1_pcode==834001, 2, 
                                  ifelse(geomig1_pcode!=834001 & prov_1_usr==5, 5,
                                         ifelse(geomig1_pcode!=834001 & prov_1_usr==9, 9,
                                                ifelse(geomig1_pcode!=834001 & prov_1_usr==0, 0,
                                                       ifelse(geomig1_pcode!=834001 & (prov_1_usr==1 | prov_1_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
#%>%sample_frac(0.05)
write.dta(tz02, "/africa calibrate rates/1-year in/TZ_2002.dta")
write.dta(tz02, "/africa calibrate rates/1-year out/TZ_2002.dta")

#Tanzania 2012, no migrate1 - different way of checking geomig1_pcode
tz12<-read.dta13("Tanzania2012.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.295
sample<-sum(tz12$perwt)
lev1<-tz12 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-tz12 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.295/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
tz12<-tz12 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig1, by="geomig1_1") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_1_ur=ur, prov_1_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         geomig1_pcode=ifelse(geomig1_pcode==geolev1, 834099, geomig1_pcode),
         prov_1_ur=ifelse(geomig1_pcode==834099, NA,
                          ifelse(geomig1_pcode==834097, 5, 
                                 ifelse(geomig1_pcode %in% c(834098, NA), 9, prov_1_ur))), 
         prov_1_usr=ifelse(geomig1_pcode==834099, NA,
                           ifelse(geomig1_pcode==834097, 5,
                                  ifelse(geomig1_pcode %in% c(834098, NA), 9, prov_1_usr))),
         prov_act_cor=ifelse(geolev1==834097, 5, 
                             ifelse(geolev1 %in% c(834098, 834099, NA), 9,
                                    ifelse(geolev1==834001, 2, #834001 Dodoma, the capital 
                                           ifelse(geolev1 %notin% c(834097, 834098, 834099, NA, 834001) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(834097, 834098, 834099, NA, 834001) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_1_cor=ifelse(geomig1_pcode==834099, NA,
                           ifelse(geomig1_pcode==834001, 2, 
                                  ifelse(geomig1_pcode!=834001 & prov_1_usr==5, 5,
                                         ifelse(geomig1_pcode!=834001 & prov_1_usr==9, 9,
                                                ifelse(geomig1_pcode!=834001 & prov_1_usr==0, 0,
                                                       ifelse(geomig1_pcode!=834001 & (prov_1_usr==1 | prov_1_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
#%>% sample_frac(0.05)
write.dta(tz12, "/africa calibrate rates/1-year in/TZ_2012.dta")
write.dta(tz12, "/africa calibrate rates/1-year out/TZ_2012.dta")

#zambia 1990
zm90<-read.dta13("Zambia1990.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.394
sample<-sum(zm90$perwt)
lev1<-zm90 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-zm90 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.394/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
zm90<-zm90 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig1, by="geomig1_1") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_1_ur=ur, prov_1_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate1 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 894099, 
                              ifelse(migrate1=="Abroad", 894097,
                                     ifelse(migrate1 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), NA, geomig1_pcode))),
         prov_1_ur=ifelse(geomig1_pcode==894099, NA, 
                          ifelse(geomig1_pcode==894097, 5, 
                                 ifelse(is.na(geomig1_pcode), 9, prov_1_ur))), 
         prov_1_usr=ifelse(geomig1_pcode==894099, NA,
                           ifelse(geomig1_pcode==894097, 5,
                                  ifelse(is.na(geomig1_pcode), 9, prov_1_usr))),
         prov_act_cor=ifelse(geolev1==894097, 5, 
                             ifelse(geolev1 %in% c(894099, NA), 9,
                                    ifelse(geolev1==894005, 2, #894005 Lusaka, the capital 
                                           ifelse(geolev1 %notin% c(894097, 894099, NA, 894005) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(894097, 894099, NA, 894005) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_1_cor=ifelse(geomig1_pcode==894099, NA,
                           ifelse(geomig1_pcode==894005, 2, 
                                  ifelse(geomig1_pcode!=894005 & prov_1_usr==5, 5,
                                         ifelse(geomig1_pcode!=894005 & prov_1_usr==9, 9,
                                                ifelse(geomig1_pcode!=894005 & prov_1_usr==0, 0,
                                                       ifelse(geomig1_pcode!=894005 & (prov_1_usr==1 | prov_1_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
#%>% sample_frac(0.2)
write.dta(zm90, "/africa calibrate rates/1-year in/ZM_1990.dta")
write.dta(zm90, "/africa calibrate rates/1-year out/ZM_1990.dta")

#zambia 2000
zm00<-read.dta13("Zambia2000.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.348
sample<-sum(zm00$perwt)
lev1<-zm00 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-zm00 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.348/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
zm00<-zm00 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig1, by="geomig1_1") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_1_ur=ur, prov_1_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate1 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 894099, 
                              ifelse(migrate1=="Abroad", 894097,
                                     ifelse(migrate1 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), NA, geomig1_pcode))),
         prov_1_ur=ifelse(geomig1_pcode==894099, NA, 
                          ifelse(geomig1_pcode==894097, 5, 
                                 ifelse(is.na(geomig1_pcode), 9, prov_1_ur))), 
         prov_1_usr=ifelse(geomig1_pcode==894099, NA,
                           ifelse(geomig1_pcode==894097, 5,
                                  ifelse(is.na(geomig1_pcode), 9, prov_1_usr))),
         prov_act_cor=ifelse(geolev1==894097, 5, 
                             ifelse(geolev1 %in% c(894099, NA), 9,
                                    ifelse(geolev1==894005, 2, #894005 Lusaka, the capital 
                                           ifelse(geolev1 %notin% c(894097, 894099, NA, 894005) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(894097, 894099, NA, 894005) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_1_cor=ifelse(geomig1_pcode==894099, NA,
                           ifelse(geomig1_pcode==894005, 2, 
                                  ifelse(geomig1_pcode!=894005 & prov_1_usr==5, 5,
                                         ifelse(geomig1_pcode!=894005 & prov_1_usr==9, 9,
                                                ifelse(geomig1_pcode!=894005 & prov_1_usr==0, 0,
                                                       ifelse(geomig1_pcode!=894005 & (prov_1_usr==1 | prov_1_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
#%>% sample_frac(0.1)
write.dta(zm00, "/africa calibrate rates/1-year in/ZM_2000.dta")
write.dta(zm00, "/africa calibrate rates/1-year out/ZM_2000.dta")

#zambia 2010, external source
external<-read.dta13("/external source/africa/zambia10.dta") %>%
  slice(-1) %>%
  select(province, total, urbantotal, ruraltotal) %>%
  mutate(total=as.numeric(gsub(",", "", gsub("\\.", "", total))), 
         urbantotal=as.numeric(gsub(",", "", gsub("\\.", "", urbantotal))), 
         ruraltotal=as.numeric(gsub(",", "", gsub("\\.", "", ruraltotal)))) %>%
  bind_rows(data.table(province="Eastern, Muchinga, Northern", 
                       total=1592661+711657+1105824, urbantotal=200323+121082+202616, ruraltotal=1392338+590575+903208)) %>%
  filter(province %notin% c("Eastern", "Muchinga", "Northern")) %>%
  mutate(urban=urbantotal/total, pop=total/sum(total)) %>%
  bind_cols(data.table(geolev1=c(894001, 894002, 894004, 894005, 894008, 894009, 894010, 894003)))
zm10<-read.dta13("Zambia2010.dta", convert.factors=T, generate.factors=T, nonint.factors=T)
WUP=0.394
sum(external$urban*external$pop)
lev1<-external %>%
  mutate(urban=urban*WUP/sum(lev1$urban*lev1$pop)) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
zm10<-zm10 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig1, by="geomig1_1") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_1_ur=ur, prov_1_usr=usr) %>%
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate1 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 894099, 
                              ifelse(migrate1=="Abroad", 894097,
                                     ifelse(migrate1 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), NA, geomig1_pcode))),
         prov_1_ur=ifelse(geomig1_pcode==894099, NA, 
                          ifelse(geomig1_pcode==894097, 5, 
                                 ifelse(is.na(geomig1_pcode), 9, prov_1_ur))), 
         prov_1_usr=ifelse(geomig1_pcode==894099, NA,
                           ifelse(geomig1_pcode==894097, 5,
                                  ifelse(is.na(geomig1_pcode), 9, prov_1_usr))),
         prov_act_cor=ifelse(geolev1==894097, 5, 
                             ifelse(geolev1 %in% c(894099, NA), 9,
                                    ifelse(geolev1==894005, 2, #894005 Lusaka, the capital 
                                           ifelse(geolev1 %notin% c(894097, 894099, NA, 894005) & prov_act_ur==0, 0, 
                                                  ifelse(geolev1 %notin% c(894097, 894099, NA, 894005) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_1_cor=ifelse(geomig1_pcode==894099, NA,
                           ifelse(geomig1_pcode==894005, 2, 
                                  ifelse(geomig1_pcode!=894005 & prov_1_usr==5, 5,
                                         ifelse(geomig1_pcode!=894005 & prov_1_usr==9, 9,
                                                ifelse(geomig1_pcode!=894005 & prov_1_usr==0, 0,
                                                       ifelse(geomig1_pcode!=894005 & (prov_1_usr==1 | prov_1_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
#%>% sample_frac(0.1)
write.dta(zm10, "/africa calibrate rates/1-year in/ZM_2010.dta")
write.dta(zm10, "/africa calibrate rates/1-year out/ZM_2010.dta")
