# first setwd

`%notin%` <- Negate(`%in%`)
library(pacman)
pacman::p_load(foreign, car, stringi, readxl, gdata, labelled, ipumsr, readstata13, dplyr, tidyr, tidyverse, gmodels)
corin<-read.dta13("All-COR-In.dta") 
corout<-read.dta13("All-COR-Out.dta") 
urin<-read.dta13("All-UR-In.dta") 
urout<-read.dta13("All-UR-Out.dta")

#1.	Five-year migration rates should be lower than 3-year rates, which should also be lower than 1-year rates (which are most accurate).
#Take Indo80 in migration as an example. However, id80 does not fulfil this rule maybe due to "unknown" in migyrs1
check1corin5<-read.dta13("All-COR-In.dta") %>%
  rename(rate5='_Rate', migrations5=migrations) %>%
  filter(country=="ID" & year==1980 & period==5) %>%
  mutate(age2=as.character(age2), educ=as.character(educ), 
         sex=as.character(sex))
check1corin3<-read.dta13("Census-COR-In_3_id.dta") %>%
# check1corin3<-read.dta13("All-COR-In.dta") %>%
#   filter(country=="ID" & year==1980 & period==3) %>%
  rename(rate3='_Rate') %>%
  full_join(check1corin5, by=c("orig", "dest", "age2", "educ", "sex")) %>%
  select(orig, dest, age2, educ, sex, rate3, rate5) %>%
  mutate(check=(rate3>=rate5)) %>%
  filter(age2==100 & educ==100 & sex==100) %>%
  mutate(inout="in", type="cor")
check1corout5<-read.dta13("All-COR-Out.dta") %>%
  rename(rate5='_Rate') %>%
  filter(country=="ID" & year==1980 & period==5)
check1corout3<-read.dta13("All-COR-Out.dta") %>%
  filter(country=="ID" & year==1980 & period==3) %>%
  rename(rate3='_Rate') %>%
  full_join(check1corout5, by=c("orig", "dest", "age2", "educ", "sex")) %>%
  select(orig, dest, age2, educ, sex, rate3, rate5) %>%
  mutate(check=(rate3>=rate5)) %>%
  filter(age2==100 & educ==100 & sex==100)  %>%
  mutate(inout="out", type="cor")
check1urin5<-read.dta13("All-UR-In.dta") %>%
  rename(rate5='_Rate') %>%
  filter(country=="ID" & year==1980 & period==5)
check1urin3<-read.dta13("All-UR-In.dta") %>%
  filter(country=="ID" & year==1980 & period==3) %>%
  rename(rate3='_Rate') %>%
  full_join(check1urin5, by=c("orig", "dest", "age2", "educ", "sex")) %>%
  select(orig, dest, age2, educ, sex, rate3, rate5) %>%
  mutate(check=(rate3>=rate5)) %>%
  filter(age2==100 & educ==100 & sex==100) %>%
  mutate(inout="in", type="ur")
check1urout5<-read.dta13("All-UR-Out.dta") %>%
  rename(rate5='_Rate', migrations5=migrations) %>%
  filter(country=="ID" & year==1980 & period==5) %>%
  mutate(age2=as.character(age2), educ=as.character(educ), 
         sex=as.character(sex))
check1urout3<-read.dta13("Census-UR-Out_3_id.dta") %>%
# check1urout3<-read.dta13("All-UR-Out.dta") %>%
  # filter(country=="ID" & year==1980 & period==3) %>%
  rename(rate3='_Rate', migrations3=migrations) %>%
  full_join(check1urout5, by=c("orig", "dest", "age2", "educ", "sex")) %>%
  select(orig, dest, age2, educ, sex, rate3, rate5, migrations3, migrations5) %>%
  mutate(check=(rate3>=rate5)) %>%
  filter(age2==100 & educ==100 & sex==100) %>%
  mutate(inout="out", type="ur")
check1<-bind_rows(check1urin3, check1urout3, check1corin3, check1corout3)
write.dta(check1, "check1.dta")

#2. The number of migrants should be the same for the same flows, eg. rural-urban out-migration (rural denominator) and rural-urban in-migration (urban denominator)
check2corin<-corin %>%
  select(country, year, period, orig, dest, age2, educ, sex, migrations) %>%
  rename(migrationsin=migrations)
check2corout<-corout %>%
  select(country, year, period, orig, dest, age2, educ, sex, migrations) %>%
  rename(migrationsout=migrations) %>%
  full_join(check2corin, by=c("country","year", "period", "orig", "dest", "age2", "educ", "sex")) %>%
  mutate(check=(round(migrationsin, 2)==round(migrationsout, 2)))
table(check2corout$check)
check2urin<-urin %>%
  select(country, year, period, orig, dest, age2, educ, sex, migrations) %>%
  rename(migrationsin=migrations)
check2urout<-urout %>%
  select(country, year, period, orig, dest, age2, educ, sex, migrations) %>%
  rename(migrationsout=migrations) %>%
  full_join(check2urin, by=c("country","year", "period", "orig", "dest", "age2", "educ", "sex")) %>%
  mutate(check=(round(migrationsin, 2)==round(migrationsout, 2)))
table(check2urout$check)

#3. The person-years at risk (PYARS, denominator) should be the same when same origin and flows are out-migration, or when same destination and flows are in-migration.
#5-year estimate is fine, but 3-year does not match, take 3-year id80 as an example. 
check3corin<-corin %>%
  select(country, year, period, dest, age2, educ, sex, PYAR)
check3corout<-corout %>%
  dplyr::select(country, year, period, orig, age2, educ, sex, PYAR) %>%
  rename(dest=orig) %>%
  left_join(check3corin, by=c("country", "year", "age2", "educ", "sex", "dest")) %>%
  distinct_all() %>%
  mutate(check=(round(PYAR.x,3)==round(PYAR.y, 3)))
table(check3corout$check)
check3urin<-urin %>%
  select(country, year, period, dest, age2, educ, sex, PYAR)
check3urout<-urout %>%
  dplyr::select(country, year, period, orig, age2, educ, sex, PYAR) %>%
  rename(dest=orig) %>%
  left_join(check3urin, by=c("country", "year", "age2", "educ", "sex", "dest")) %>%
  distinct_all() %>%
  mutate(check=(round(PYAR.x, 3)==round(PYAR.y, 3)))
table(check3urout$check)

#4.	The migration rates for in- and out-migration should be the same when within the same sector eg. urban-urban.
check4corin<-corin %>%
  select(country, year, period, orig, dest, age2, educ, sex, `_Rate`) %>%
  rename(ratein=`_Rate`) 
check4corout<-corout %>%
  select(country, year, period, orig, dest, age2, educ, sex, `_Rate`) %>%
  rename(rateout=`_Rate`) %>%
  full_join(check4corin, by=c("country","year", "period", "orig", "dest", "age2", "educ", "sex")) %>%
  filter(orig==dest) %>%
  mutate(check=(round(ratein, 3)==round(rateout, 3)))
table(check4corout$check)
check4urin<-urin %>%
  select(country, year, period, orig, dest, age2, educ, sex, `_Rate`) %>%
  rename(ratein=`_Rate`) 
check4urout<-urout %>%
  select(country, year, period, orig, dest, age2, educ, sex, `_Rate`) %>%
  rename(rateout=`_Rate`) %>%
  full_join(check4urin, by=c("country","year", "period", "orig", "dest", "age2", "educ", "sex")) %>%
  filter(orig==dest) %>%
  mutate(check=(ratein==rateout))
table(check4urout$check)

#5. For 5-year migration, children under-five should not have any rates. Also, children under ten should not have educational categories, only be included in the ???100”s (totals).
check5in<-corin %>%
  filter(period==5 & age2==1)
check5out<-corout %>%
  filter(period==5 & age2==1)
table(check5in$'_Rate')
table(check5out$'_Rate')
#take china00 as an example
cn00<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/5-year in/COR/CN_2000.dta") %>%
  filter(age2<=2)
table(cn00$educ)
#deleted educ<100 when age2<=2
urin<-urin %>%
  filter(!(age2<=2 & (educ<100)) & !(period==5 & age2==1))
write.dta(urin, "All-UR-In.dta")
urout<-urout %>%
  filter(!(age2<=2 & (educ<100)) & !(period==5 & age2==1))
write.dta(urout, "All-UR-Out.dta")
corin<-corin %>%
  filter(!(age2<=2 & (educ<100)) & !(period==5 & age2==1))
write.dta(corin, "All-COR-In.dta")
corout<-corout %>%
  filter(!(age2<=2 & (educ<100)) & !(period==5 & age2==1))
write.dta(corout, "All-COR-Out.dta")

#6. The PYARS by rural/urban should reflect the proportion urban in a given country at the time of census. Note, the PYARS needs to be divided by the period (3 or 5 years) to get the population estimates.
#take china00 as an example
check6in<-urin %>%
  filter(age2==100 & educ==100 & sex==100)
cn00<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/5-year in/COR/CN_2000.dta")
cn00<-cn00 %>%
  mutate(prov_5_ur=ifelse(is.na(prov_5_ur), prov_act_ur, prov_5_ur))
data<-data.table(country="CN", year=2000, pop=sum(cn00$perwt), urban_act=sum(cn00$perwt[cn00$urban=="Urban"])/sum(cn00$perwt),
                 urban5=sum(cn00$perwt[cn00$prov_5_ur==1])/sum(cn00$perwt), pyarurban=10940250.0, pyarrural=48080750.0)
id76<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/5-year in/COR/ID_1976.dta")
id76<-id76 %>%
  mutate(prov_5_ur=ifelse(is.na(prov_5_ur), prov_act_ur, prov_5_ur))
data<-bind_rows(data, 
                data.table(country="ID", year=1976, pop=sum(id76$perwt), urban_act=sum(id76$perwt[id76$urban=="Urban"])/sum(id76$perwt),
                           urban5=sum(id76$perwt[id76$prov_5_ur==1])/sum(id76$perwt), pyarurban=3100022.5, pyarrural=59835460.0))
id80<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/5-year in/COR/ID_1980.dta")
id80<-id80 %>%
  mutate(prov_5_ur=ifelse(is.na(prov_5_ur), prov_act_ur, prov_5_ur))
data<-bind_rows(data, 
                data.table(country="ID", year=1980, pop=sum(id80$perwt), urban_act=sum(id80$perwt[id80$urban=="Urban"])/sum(id80$perwt),
                           urban5=sum(id80$perwt[id80$prov_5_ur==1])/sum(id80$perwt), pyarurban=158142.5, pyarrural=3515887.5))

id00<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/5-year in/COR/ID_2000.dta")
id00<-id00 %>%
  mutate(prov_5_ur=ifelse(is.na(prov_5_ur), prov_act_ur, prov_5_ur))
data<-bind_rows(data, 
                data.table(country="ID", year=2000, pop=sum(id00$perwt), urban_act=sum(id00$perwt[id00$urban=="Urban"])/sum(id00$perwt),
                           urban5=sum(id00$perwt[id00$prov_5_ur==1])/sum(id00$perwt), pyarurban=2854750.0, pyarrural=7201100.0))

id10<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/5-year in/COR/ID_2010.dta")
id10<-id10 %>%
  mutate(prov_5_ur=ifelse(is.na(prov_5_ur), prov_act_ur, prov_5_ur))
data<-bind_rows(data, 
                data.table(country="ID", year=2010, pop=sum(id10$perwt), urban_act=sum(id10$perwt[id00$urban=="Urban"])/sum(id10$perwt),
                           urban5=sum(id10$perwt[id10$prov_5_ur==1])/sum(id10$perwt), pyarurban=3660925.0, pyarrural=8136350.0)) 
il83<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/5-year in/COR/IL_1983.dta")
il83<-il83 %>%
  mutate(prov_5_ur=ifelse(is.na(prov_5_ur), prov_act_ur, prov_5_ur))
data<-bind_rows(data, 
                data.table(country="IL", year=1983, pop=sum(il83$perwt), urban_act=sum(il83$perwt[il83$urban=="Urban"])/sum(il83$perwt),
                           urban5=sum(il83$perwt[il83$prov_5_ur==1])/sum(il83$perwt), pyarurban=197300.0, pyarrural=3300.0))
np01<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/5-year in/COR/NP_2001.dta")
np01<-np01 %>%
  mutate(prov_5_ur=ifelse(is.na(prov_5_ur), prov_act_ur, prov_5_ur))
data<-bind_rows(data, 
                data.table(country="NP", year=2001, pop=sum(np01$perwt), urban_act=sum(np01$perwt[np01$urban=="Urban"])/sum(np01$perwt),
                           urban5=sum(np01$perwt[np01$prov_5_ur==1])/sum(np01$perwt), pyarurban=0, pyarrural=1136922.8))  
np11<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/5-year in/COR/NP_2011.dta")
np11<-np11 %>%
  mutate(prov_5_ur=ifelse(is.na(prov_5_ur), prov_act_ur, prov_5_ur))
data<-bind_rows(data, 
                data.table(country="NP", year=2011, pop=sum(np11$perwt), urban_act=sum(np11$perwt[np11$urban=="Urban"])/sum(np11$perwt),
                           urban5=sum(np11$perwt[np11$prov_5_ur==1])/sum(np11$perwt), pyarurban=0, pyarrural=1309425.8))  
ph00<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/5-year in/COR/PH_2000.dta")
ph00<-ph00 %>%
  mutate(prov_5_ur=ifelse(is.na(prov_5_ur), prov_act_ur, prov_5_ur))
data<-bind_rows(data, 
                data.table(country="PH", year=2000, pop=sum(ph00$perwt), urban_act=NA,
                           urban5=sum(ph00$perwt[ph00$prov_5_ur==1])/sum(ph00$perwt), pyarurban=1417615.0, pyarrural=2393035.0)) 
ph10<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/5-year in/COR/PH_2010.dta")
ph10<-ph10 %>%
  mutate(prov_5_ur=ifelse(is.na(prov_5_ur), prov_act_ur, prov_5_ur))
data<-bind_rows(data, 
                data.table(country="PH", year=2010, pop=sum(ph10$perwt), urban_act=NA,
                           urban5=sum(ph10$perwt[ph00$prov_5_ur==1])/sum(ph10$perwt), pyarurban=2017089.8, pyarrural=2587718.7)) 
vt89<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/5-year in/COR/VT_1989.dta")
vt89<-vt89 %>%
  mutate(prov_5_ur=ifelse(is.na(prov_5_ur), prov_act_ur, prov_5_ur))
data<-bind_rows(data, 
                data.table(country="VT", year=1989, pop=sum(vt89$perwt), urban_act=sum(vt89$perwt[vt89$urban=="Urban"])/sum(vt89$perwt),
                           urban5=sum(vt89$perwt[vt89$prov_5_ur==1])/sum(vt89$perwt), pyarurban=192334.9, pyarrural=2986881.6)) 
vt99<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/5-year in/COR/VT_1999.dta")
vt99<-vt99 %>%
  mutate(prov_5_ur=ifelse(is.na(prov_5_ur), prov_act_ur, prov_5_ur))
data<-bind_rows(data, 
                data.table(country="VT", year=1999, pop=sum(vt99$perwt), urban_act=sum(vt99$perwt[vt99$urban=="Urban"])/sum(vt99$perwt),
                           urban5=sum(vt99$perwt[vt99$prov_5_ur==1])/sum(vt99$perwt), pyarurban=248916.5, pyarrural=3558647.7))  
vt09<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/5-year in/COR/VT_2009.dta")
vt09<-vt09 %>%
  mutate(prov_5_ur=ifelse(is.na(prov_5_ur), prov_act_ur, prov_5_ur))
data<-bind_rows(data, 
                data.table(country="VT", year=2009, pop=sum(vt09$perwt), urban_act=sum(vt09$perwt[vt09$urban=="Urban"])/sum(vt09$perwt),
                           urban5=sum(vt09$perwt[vt09$prov_5_ur==1])/sum(vt09$perwt), pyarurban=393287.2, pyarrural=3901849.8))  

id71<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/3-year in/COR/ID_1971.dta")
id71<-id71 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="ID", year=1971, pop=sum(id71$perwt), urban_act=sum(id71$perwt[id71$urban=="Urban"])/sum(id71$perwt),
                           urban3=sum(id71$perwt[id71$prov_3_ur==1])/sum(id71$perwt), pyarurban=561813.8, pyarrural=14295121.2)) 
id80<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/3-year in/COR/ID_1980.dta")
id80<-id80 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="ID", year=1980, pop=sum(id80$perwt), urban_act=sum(id80$perwt[id80$urban=="Urban"])/sum(id80$perwt),
                           urban3=sum(id80$perwt[id80$prov_3_ur==1])/sum(id80$perwt), pyarurban=80312.5, pyarrural=1756732.5))
id85<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/3-year in/COR/ID_1985.dta")
id85<-id85 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="ID", year=1985, pop=sum(id85$perwt), urban_act=sum(id85$perwt[id85$urban=="Urban"])/sum(id85$perwt),
                           urban3=sum(id85$perwt[id85$prov_3_ur==1])/sum(id85$perwt), pyarurban=1986080.0, pyarrural=39140555.0))
id90<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/3-year in/COR/ID_1990.dta")
id90<-id90 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="ID", year=1990, pop=sum(id90$perwt), urban_act=sum(id90$perwt[id90$urban=="Urban"])/sum(id90$perwt),
                           urban3=sum(id90$perwt[id90$prov_3_ur==1])/sum(id90$perwt), pyarurban=1000988.7, pyarrural=21415687.5))  
id95<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/3-year in/COR/ID_1995.dta")
id95<-id95 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="ID", year=1995, pop=sum(id95$perwt), urban_act=sum(id95$perwt[prov_act_ur==1])/sum(id95$perwt),
                           urban3=sum(id95$perwt[id95$prov_3_ur==1])/sum(id95$perwt), pyarurban=1483308.7, pyarrural=19371323.7)) 
id05<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/3-year in/COR/ID_2005.dta")
id05<-id05 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="ID", year=2005, pop=sum(id05$perwt), urban_act=sum(id05$perwt[id05$urban=="Urban"])/sum(id05$perwt),
                           urban3=sum(id05$perwt[id05$prov_3_ur==1])/sum(id05$perwt), pyarurban=8322035.0, pyarrural=18431502.5)) 
iq97<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/3-year in/COR/IQ_1997.dta")
iq97<-iq97 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="IQ", year=1997, pop=sum(iq97$perwt), urban_act=sum(iq97$perwt[iq97$urban=="Urban"])/sum(iq97$perwt),
                           urban3=sum(iq97$perwt[iq97$prov_3_ur==1])/sum(iq97$perwt), pyarurban=392412.5, pyarrural=93612.5))
kg90<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/asia calibrate rates/sample_april2021/3-year in/COR/KG_1990.dta")
kg90<-kg90 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="KG", year=1990, pop=sum(kg90$perwt), urban_act=sum(kg90$perwt[kg90$prov_act_ur==1])/sum(kg90$perwt),
                           urban3=sum(kg90$perwt[kg90$prov_3_ur==1])/sum(kg90$perwt), pyarurban=175912.5, pyarrural=1011450.0))  
mn00<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/3-year in/COR/MN_2000.dta")
mn00<-mn00 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="MN", year=2000, pop=sum(mn00$perwt), urban_act=NA,
                           urban3=sum(mn00$perwt[mn00$prov_3_ur==1])/sum(mn00$perwt), pyarurban=270237.5, pyarrural=338687.5))
ph90<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/3-year in/COR/PH_1990.dta")
ph90<-ph90 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="PH", year=1990, pop=sum(ph90$perwt), urban_act=sum(ph90$perwt[ph90$urban=="Urban"])/sum(ph90$perwt),
                           urban3=sum(ph90$perwt[ph90$prov_3_ur==1])/sum(ph90$perwt), pyarurban=272508.8, pyarrural=483445.0))  
th70<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/3-year in/COR/TH_1970.dta")
th70<-th70 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="TH", year=1970, pop=sum(th70$perwt), urban_act=sum(th70$perwt[th70$urban=="Urban"])/sum(th70$perwt),
                           urban3=sum(th70$perwt[th70$prov_3_ur==1])/sum(th70$perwt), pyarurban=0, pyarrural=4266262.5))  
th80<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/3-year in/COR/TH_1980.dta")
th80<-th80 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="TH", year=1980, pop=sum(th80$perwt), urban_act=sum(th80$perwt[th80$urban=="Urban"])/sum(th80$perwt),
                           urban3=sum(th80$perwt[th80$prov_3_ur==1])/sum(th80$perwt), pyarurban=1724729.1, pyarrural=9343900.7)) 
th90<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/3-year in/COR/TH_1990.dta")
th90<-th90 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="TH", year=1990, pop=sum(th90$perwt), urban_act=sum(th90$perwt[th90$urban=="Urban"])/sum(th90$perwt),
                           urban3=sum(th90$perwt[th90$prov_3_ur==1])/sum(th90$perwt), pyarurban=1569777.7, pyarrural=12068106.8))  
th00<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/3-year in/COR/TH_2000.dta")
th00<-th00 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-bind_rows(data, 
                data.table(country="TH", year=2000, pop=sum(th00$perwt), urban_act=sum(th00$perwt[th00$urban=="Urban"])/sum(th00$perwt),
                           urban3=sum(th00$perwt[th00$prov_3_ur==1])/sum(th00$perwt), pyarurban=1123352.9, pyarrural=6451418.1)) 
data<-data %>%
  mutate(pyarur=pyarurban/(pyarurban+pyarrural)) %>%
  bind_cols(data.table(period=c(rep(5, 13), rep(2.5, 14)))) %>%
  mutate(pyarpop=(pyarurban+pyarrural)/period)
data<-data %>%
  mutate(check1=(pyarur>=urban5 & pyarur<=urban_act), 
         check1=ifelse(is.na(urban5), NA, check1),
         check2=(pyarur>=urban3 & pyarur<=urban_act),
         check2=ifelse(is.na(urban3), NA, check2))
write.dta(data, "PYARcheck.dta")

#7. The sum of the rural and urban PYARS should sum up to the total population size of the country (total PYARS multiplied by the period).

#10.“dest??? should have not have less categories than “orig???, to this regard, check kyr and Nepal regarding “urban??? and “otherurban???.
check10inkg<-corin %>%
  filter(country=="KG")
table(check10inkg$orig)
table(check10inkg$dest)
kg<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/3-year out/COR/KG_1990.dta")
table(kg$prov_3_cor)
table(kg$prov_act_cor)
orig<-check10inkg %>%
  filter(orig=="otherurban")
table(orig$migrations)
check10innp<-corin %>%
  filter(country=="NP")
table(check10innp$orig)
table(check10innp$dest)
np01<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/5-year out/COR/NP_2001.dta")
table(np01$prov_5_cor)
table(np01$prov_act_cor)
orig<-check10innp %>%
  filter(orig=="otherurban")
table(orig$migrations)
np11<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/calibrate rates/sample_april2021/5-year out/COR/NP_2011.dta")
table(np11$prov_5_cor)
table(np11$prov_act_cor)
orig<-check10innp %>%
  filter(orig=="otherurban")
table(orig$migrations)
#there is no otherurban in kg and np and no migrations from otherurban because there is no other urban.
#we should simply delete those orig=="otherurban". In the stata program, it seems to me that, by default, all values of "orig" enter into calculation of PYAR regardless of whether it exist or not.

#check KG total
pyar<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/asia calibrate rates/sample_april2021/3-year in/Census-UR-In_3_kg.dta") %>%
  filter(age2==100 & educ==100 & sex==100)
kg90<-read.dta13("C:/Users/wnie/OneDrive - UCL/global south/asia calibrate rates/sample_april2021/3-year in/COR/KG_1990total.dta")
kg90<-kg90 %>%
  mutate(prov_3_ur=ifelse(is.na(prov_3_ur), prov_act_ur, prov_3_ur))
data<-data.table(country="KG", year=1990, pop=sum(kg90$perwt), urban_act=sum(kg90$perwt[kg90$urban=="Urban"])/sum(kg90$perwt),
                           urban3=sum(kg90$perwt[kg90$prov_3_ur==1])/sum(kg90$perwt), pyarurban=1743975, pyarrural=10130762) %>%
  mutate(pyarur=pyarurban/(pyarurban+pyarrural))
