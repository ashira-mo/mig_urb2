# first setwd

`%notin%` <- Negate(`%in%`)
library(pacman)
pacman::p_load(foreign, qdap, data.table, car, readxl, gdata, labelled, ipumsr, readstata13, dplyr, tidyr, tidyverse, gmodels)
geomig5<-read.dta13("geomig1_5.dta") %>%
  rename(code=var1, geomig1_5=var3) %>%
  mutate(code=as.integer(code))

#china90, external source
externalcn90<-read.dta13("china82-10.dta") %>%
  select(province, urban90, pop90) %>%
  rename(urban=urban90, pop=pop90)
WUP=0.264
ipums<-externalcn90$urban[1]
lev1<-externalcn90 %>%
  slice(-1) %>%
  filter(!is.na(urban)) %>%
  arrange(-urban) %>%
  mutate(province=factor(province,levels = province))
lev1$province<-c("Shanghai", "Beijing", "Tianjin", "Liaoning", "Heilongjiang", "Jilin", "Inner Mongolia", "Xinjiang", "Qinghai", "Ningxia", "Guangdong", 
                 "Shanxi", "Hainan", "Hubei", "Jiangsu", "Shaanxi", "Jiangxi", "Fujian", "Gansu", "Zhejiang", "Hunan", "Sichuan", "Hebei", "Anhui", "Shandong", 
                 "Guangxi", "Tibet", "Yunnan", "Henan", "Guizhou")
guangdonghainan<-data.table(province="Guangdong, Hainan", urban=(0.2156476*0.055576425+0.1903702*0.005800986)/(0.055576425+0.005800986), pop=0.055576425+0.005800986)
lev1<-lev1 %>%
  bind_rows(guangdonghainan) %>%
  filter(province %notin% c("Guangdong", "Hainan"))
sum(lev1$urban*lev1$pop)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  #ur 0 rural 1 urban, usr 0 rural, 1 semi-urban, 2 urban
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2))) %>%
  mutate(province=paste0(province, " [Province: China]")) %>%
  left_join(geomig5, by=c("province"="geomig1_5")) %>%
  rename(geolev1=code) %>%
  mutate(geolev1=ifelse(province=="Shandong [Province: China]", 156037, 
                        ifelse(province=="Sichuan [Province: China]", 156051, geolev1)))
cn90<-read.dta13("china90.dta")
geomig_5cn<-grep("Province: China", geomig5$geomig1_5, value=TRUE)
geomig_5cn[geomig_5cn %notin% unique(cn90$geomig1_5)]
unique(cn90$geomig1_5)[unique(cn90$geomig1_5) %notin% geomig_5cn] #HK, Taiwan and Macao not included in the codebook. Here we consider Hongkong, Taiwana and Macao together with foreign.
cn90<-cn90 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig5, by="geomig1_5") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_5_ur=ur, prov_5_usr=usr) %>%
  #prov_act_cor, prov_5_cor 0 rural, 2 capital, 3 urban, 5 abroad 9 dk-missing 
  #prov_5_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_5_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate5 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 156099, 
                              ifelse(migrate5=="Abroad", 156097,
                                     ifelse(migrate5 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), NA, geomig1_pcode))),
         prov_5_ur=ifelse(geomig1_pcode==156099, NA, #if geomig1_5code is NIU, prov_5_ur equals to NA
                          ifelse(geomig1_pcode==156097, 5, #if geomig1_5code is other countries, equals to "foreign"
                                 ifelse(is.na(geomig1_pcode), 9, prov_5_ur))),
         prov_5_usr=ifelse(geomig1_pcode==156099, NA,
                           ifelse(geomig1_pcode==156097, 5,
                                  ifelse(is.na(geomig1_pcode), 9, prov_5_usr))),
         prov_act_cor=ifelse(geolev1==156097, 5, 
                             ifelse(geolev1 %in% c(156099, NA), 9,
                                    ifelse(geolev1==156011, 2, 
                                           ifelse(geolev1 %notin% c(156097, 156099, NA, 156011) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(156097, 156099, NA, 156011) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         
         prov_5_cor=ifelse(geomig1_pcode==156099, NA,
                           ifelse(geomig1_pcode==156011, 2, 
                                  ifelse(geomig1_pcode!=156011 & prov_5_usr==5, 5,
                                         ifelse(geomig1_pcode!=156011 & prov_5_usr==9, 9,
                                                ifelse(geomig1_pcode!=156011 & prov_5_usr==0, 0,
                                                       ifelse(geomig1_pcode!=156011 & (prov_5_usr==1 | prov_5_usr==2), 3, NA)))))),
         #less than primary completed 0, primary completed 1, above primary 2
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) %>%
  select(-edattaind) 
#%>%sample_frac(0.05)
write.dta(cn90, "asia calibrate rates/5-year in/CN_1990.dta")
write.dta(cn90, "asia calibrate rates/5-year out/CN_1990.dta")

#china00
cn00<-read.dta("china00.dta")
geomig_5cn<-grep("Province: China", geomig5$geomig1_5, value=TRUE)
geomig_5cn[geomig_5cn %notin% unique(cn00$geomig1_5)]
cn00$geomig1_5[cn00$geomig1_5 %notin% geomig_5cn]
total<-cn00 %>%
  summarise(upert=sum(urban=="Urban")/length(urban), 
            weight=0.359/upert)
WUP=0.359
lev1<-cn00 %>%
  group_by(geolev1) %>%
  summarise(urban=sum(urban=="Urban")/length(urban), 
            pop=length(pernum)/length(cn00$year)) %>%
  arrange(-urban)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  #ur 0 rural 1 urban, usr 0 rural, 1 semi-urban, 2 urban
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
cn00<-cn00 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig5, by="geomig1_5") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_5_ur=ur, prov_5_usr=usr) %>%
  #prov_act_cor, prov_5_cor 0 rural, 2 capital, 3 urban, 5 abroad 9 dk-missing 
  #prov_5_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_5_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate5 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 156099, 
                              ifelse(migrate5=="Abroad", 156097,
                                     ifelse(migrate5 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), NA, geomig1_pcode))),
         prov_5_ur=ifelse(geomig1_pcode==156099, NA, #if geomig1_5code is NIU, prov_5_ur equals to NA
                          ifelse(geomig1_pcode==156097, 5, #if geomig1_5code is other countries, equals to "foreign"
                                 ifelse(is.na(geomig1_pcode), 9, prov_5_ur))),
         prov_5_usr=ifelse(geomig1_pcode==156099, NA,
                           ifelse(geomig1_pcode==156097, 5,
                                  ifelse(is.na(geomig1_pcode), 9, prov_5_usr))),
         prov_act_cor=ifelse(geolev1==156097, 5, 
                             ifelse(geolev1 %in% c(156099, NA), 9,
                                    ifelse(geolev1==156011, 2, 
                                           ifelse(geolev1 %notin% c(156097, 156099, NA, 156011) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(156097, 156099, NA, 156011) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_5_cor=ifelse(geomig1_pcode==156099, NA,
                           ifelse(geomig1_pcode==156011, 2, 
                                  ifelse(geomig1_pcode!=156011 & prov_5_usr==5, 5,
                                         ifelse(geomig1_pcode!=156011 & prov_5_usr==9, 9,
                                                ifelse(geomig1_pcode!=156011 & prov_5_usr==0, 0,
                                                       ifelse(geomig1_pcode!=156011 & (prov_5_usr==1 | prov_5_usr==2), 3, NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) %>%
  select(-edattaind) 
#%>% sample_frac(0.05)
write.dta(cn00, "asia calibrate rates/5-year in/CN_2000.dta")
write.dta(cn00, "asia calibrate rates/5-year out/CN_2000.dta")

#indonesia 1976
id76<-read.dta("indo76.dta")
geomig5id<-grep("Province: Indonesia", geomig5$geomig1_5, value=TRUE)
geomig5id[geomig5id %notin% unique(as.character(id76$geomig1_5))] #east timor is not in indonesia76, doesn't matter
unique(as.character(id76$geomig1_5))[unique(as.character(id76$geomig1_5)) %notin% geomig5id]
WUP=0.199
sample<-sum(id76$perwt)
lev1<-id76 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-id76 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.199/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
id76<-id76 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig5, by="geomig1_5") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_5_ur=ur, prov_5_usr=usr) %>%
  #prov_act_cor, prov_5_cor 0 rural, 2 capital, 3 urban, 5 abroad 9 dk-missing 
  #prov_5_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_5_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate5 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 360099, 
                              ifelse(migrate5=="Abroad", 360097,
                                     ifelse(migrate5 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 360098, geomig1_pcode))),
         prov_5_ur=ifelse(geomig1_pcode==360099, NA, #360099 NIU
                          ifelse(geomig1_pcode==360097, 5, #360097 abroad
                                 ifelse(geomig1_pcode %in% c(360098, NA), 9, prov_5_ur))), #360098 unknown
         prov_5_usr=ifelse(geomig1_pcode==360099, NA,
                           ifelse(geomig1_pcode==360097, 5,
                                  ifelse(geomig1_pcode %in% c(360098, NA), 9, prov_5_usr))),
         prov_act_cor=ifelse(geolev1==360097, 5, 
                             ifelse(geolev1 %in% c(360098, 360099, NA), 9,
                                    ifelse(geolev1==360031, 2, #360031 DKI Jakarta, the capital 
                                           ifelse(geolev1 %notin% c(360097, 360098, 360099, NA, 360031) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(360097, 360098, 360099, NA, 360031) & (prov_act_usr==1 | prov_act_usr==2),3,NA))))),
         prov_5_cor=ifelse(geomig1_pcode==360099, NA,
                           ifelse(geomig1_pcode==360031, 2, 
                                  ifelse(geomig1_pcode!=360031 & prov_5_usr==5, 5,
                                         ifelse(geomig1_pcode!=360031 & prov_5_usr==9, 9,
                                                ifelse(geomig1_pcode!=360031 & prov_5_usr==0, 0,
                                                       ifelse(geomig1_pcode!=360031 & (prov_5_usr==1 | prov_5_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
#%>%sample_frac(0.1)
write.dta(id76, "asia calibrate rates/5-year in/ID_1976.dta")
write.dta(id76, "asia calibrate rates/5-year out/ID_1976.dta")


#indo80, not necessary to adjust, it has both 3-year estimate and 5-year estimate, keep 5-year estimate because migyrs1 has unknown
id80<-read.dta("indo80.dta")
geomig5id<-grep("Province: Indonesia", geomig5$geomig1_5, value=TRUE)
geomig5id[geomig5id %notin% id80$geomig1_5] 
unique(id80$geomig1_5)[unique(id80$geomig1_5) %notin% geomig5id]
sample<-sum(id80$perwt)
lev1<-id80 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-id80 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.221/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
id80<-id80 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig5, by="geomig1_5") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_5_ur=ur, prov_5_usr=usr) %>%
  #prov_act_cor, prov_5_cor 0 rural, 2 capital, 3 urban, 5 abroad 9 dk-missing 
  #prov_5_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_5_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate5 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 360099, 
                              ifelse(migrate5=="Abroad", 360097,
                                     ifelse(migrate5 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 360098, geomig1_pcode))),
         prov_5_ur=ifelse(geomig1_pcode==360099, NA, #360099 NIU
                          ifelse(geomig1_pcode==360097, 5, #360097 abroad
                                 ifelse(geomig1_pcode %in% c(360098, NA), 9, prov_5_ur))), #360098 unknown
         prov_5_usr=ifelse(geomig1_pcode==360099, NA,
                           ifelse(geomig1_pcode==360097, 5,
                                  ifelse(geomig1_pcode %in% c(360098, NA), 9, prov_5_usr))),
         prov_act_cor=ifelse(geolev1==360097, 5, 
                             ifelse(geolev1 %in% c(360098, 360099, NA), 9,
                                    ifelse(geolev1==360031, 2, #360031 DKI Jakarta, the capital 
                                           ifelse(geolev1 %notin% c(360097, 360098, 360099, NA, 360031) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(360097, 360098, 360099, NA, 360031) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_5_cor=ifelse(geomig1_pcode==360099, NA,
                           ifelse(geomig1_pcode==360031, 2, 
                                  ifelse(geomig1_pcode!=360031 & prov_5_usr==5, 5,
                                         ifelse(geomig1_pcode!=360031 & prov_5_usr==9, 9,
                                                ifelse(geomig1_pcode!=360031 & prov_5_usr==0, 0,
                                                       ifelse(geomig1_pcode!=360031 & (prov_5_usr==1 | prov_5_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"))
# %>%
#   arrange(serial, pernum) %>%
#   mutate(rownum=row_number(serial)) %>%
#   filter(rownum %in% id)
write.dta(id80, "asia calibrate rates/5-year in/ID_1980.dta")
write.dta(id80, "asia calibrate rates/5-year out/ID_1980.dta")

#indo00
id00<-read.dta("indo00.dta")
geomig5id<-grep("Province: Indonesia", geomig5$geomig1_5, value=TRUE)
geomig5id[geomig5id %notin% id00$geomig1_5] #east timor not included in indo00, doesn't matter
id00$geomig1_5[id00$geomig1_5 %notin% geomig5id]
sample<-sum(id00$perwt)
total<-id00 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.42/upert)
lev1<-id00 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"])) %>%
  ungroup() %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
id00<-id00 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig5, by="geomig1_5") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_5_ur=ur, prov_5_usr=usr) %>%
  #prov_act_cor, prov_5_cor 0 rural, 2 capital, 3 urban, 5 abroad 9 dk-missing 
  #prov_5_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_5_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate5 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 360099, 
                              ifelse(migrate5=="Abroad", 360097,
                                     ifelse(migrate5 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 360098, geomig1_pcode))),
         prov_5_ur=ifelse(geomig1_pcode==360099, NA, #360099 NIU
                          ifelse(geomig1_pcode==360097, 5, #360097 abroad
                                 ifelse(geomig1_pcode %in% c(360098, NA), 9, prov_5_ur))), #360098 unknown
         prov_5_usr=ifelse(geomig1_pcode==360099, NA,
                           ifelse(geomig1_pcode==360097, 5,
                                  ifelse(geomig1_pcode %in% c(360098, NA), 9, prov_5_usr))),
         prov_act_cor=ifelse(geolev1==360097, 5, 
                             ifelse(geolev1 %in% c(360098, 360099, NA), 9,
                                    ifelse(geolev1==360031, 2, #360031 DKI Jakarta, the capital 
                                           ifelse(geolev1 %notin% c(360097, 360098, 360099, NA, 360031) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(360097, 360098, 360099, NA, 360031) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_5_cor=ifelse(geomig1_pcode==360099, NA,
                           ifelse(geomig1_pcode==360031, 2, 
                                  ifelse(geomig1_pcode!=360031 & prov_5_usr==5, 5,
                                         ifelse(geomig1_pcode!=360031 & prov_5_usr==9, 9,
                                                ifelse(geomig1_pcode!=360031 & prov_5_usr==0, 0,
                                                       ifelse(geomig1_pcode!=360031 & (prov_5_usr==1 | prov_5_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
#%>%sample_frac(0.05)
write.dta(id00, "asia calibrate rates/5-year in/ID_2000.dta")
write.dta(id00, "asia calibrate rates/5-year out/ID_2000.dta")

#indo10, not necessary to adjust
id10<-read.dta("indo10.dta")
geomig5id<-grep("Province: Indonesia", geomig5$geomig1_5, value=TRUE)
geomig5id[geomig5id %notin% id10$geomig1_5] #unknown and east timor not included in indo2010, doesn't matter
id10$geomig1_5[id10$geomig1_5 %notin% geomig5id]
WUP=0.499
sample<-sum(id10$perwt)
lev1<-id10 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-id10 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.499/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
id10<-id10 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig5, by="geomig1_5") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_5_ur=ur, prov_5_usr=usr) %>%
  #prov_act_cor, prov_5_cor 0 rural, 2 capital, 3 urban, 5 abroad 9 dk-missing 
  #prov_5_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_5_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate5 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 360099, 
                              ifelse(migrate5=="Abroad", 360097,
                                     ifelse(migrate5 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), NA, geomig1_pcode))),
         prov_5_ur=ifelse(geomig1_pcode==360099, NA, #360099 NIU
                          ifelse(geomig1_pcode==360097, 5, #360097 abroad
                                 ifelse(geomig1_pcode %in% c(360098, NA), 9, prov_5_ur))), #360098 unknown
         prov_5_usr=ifelse(geomig1_pcode==360099, NA,
                           ifelse(geomig1_pcode==360097, 5,
                                  ifelse(geomig1_pcode %in% c(360098, NA), 9, prov_5_usr))),
         prov_act_cor=ifelse(geolev1==360097, 5, 
                             ifelse(geolev1 %in% c(360098, 360099, NA), 9,
                                    ifelse(geolev1==360031, 2, #360031 DKI Jakarta, the capital 
                                           ifelse(geolev1 %notin% c(360097, 360098, 360099, NA, 360031) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(360097, 360098, 360099, NA, 360031) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_5_cor=ifelse(geomig1_pcode==360099, NA,
                           ifelse(geomig1_pcode==360031, 2, 
                                  ifelse(geomig1_pcode!=360031 & prov_5_usr==5, 5,
                                         ifelse(geomig1_pcode!=360031 & prov_5_usr==9, 9,
                                                ifelse(geomig1_pcode!=360031 & prov_5_usr==0, 0,
                                                       ifelse(geomig1_pcode!=360031 & (prov_5_usr==1 | prov_5_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
#%>%sample_frac(0.05)
write.dta(id10, "asia calibrate rates/5-year in/ID_2010.dta")
write.dta(id10, "asia calibrate rates/5-year out/ID_2010.dta")

#israel83 on geolev2, not necessary to adjust, it differs from other census in geolev1 (it has 376097 unknown which needs to be dropped) and geomig1_5 is numeric
# il83<-read.dta("israel83.dta") %>%
#   mutate(geomig1_5=as.character(geomig1_5)) #isra83 geomig1_5 in coding not in string, does not need to change
# sample<-sum(il83$perwt)
# total<-il83 %>%
#   summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
#             weight=0.896/upert)
# lev1<-il83 %>%
#   group_by(geolev1) %>%
#   summarise(pop=sum(perwt), 
#             urban=sum(perwt[urban=="Urban"])) %>%
#   filter(geolev1!=376097) %>% #geolev1==376097 are those whose actual residence is unknown
#   ungroup() %>%
#   mutate(urban=urban/pop, 
#          pop=pop/sample) %>%
#   arrange(-urban) %>% 
#   mutate(ur=ifelse(urban<=0.5, 0, 1),  
#        usr=ifelse(urban<=0.5, 0, 
#                   ifelse(urban>0.5 & urban<=0.85, 1, 2)))
# il83<-il83 %>%
#   left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
#   mutate(ur=ifelse(is.na(ur), 9, ur), 
#          usr=ifelse(is.na(usr), 9, usr)) %>%
#   rename(prov_act_ur=ur, prov_act_usr=usr) %>%
#   rename(geomig1_pcode=geomig1_5) %>%
#   mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
#   left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
#   rename(prov_5_ur=ur, prov_5_usr=usr) %>%
#   #prov_act_cor, prov_5_cor 0 rural, 2 capital, 3 urban, 5 abroad 9 dk-missing 
#   #prov_5_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
#   #prov_5_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
#   mutate(caseid=(serial*100) + pernum,
#          #verify that geomig1_pcode is coded consistently with migratep
#          geomig1_pcode=ifelse(migrate5 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 376099, 
#                                      ifelse(migrate5 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), NA, geomig1_pcode)),
#          prov_5_ur=ifelse(geomig1_pcode==376099, NA, #376099 NIU
#                                  ifelse(geomig1_pcode %in% c(376097, NA), 9, prov_5_ur)), #376097 unknown
#          prov_5_usr=ifelse(geomig1_pcode==376099, NA,
#                                   ifelse(geomig1_pcode %in% c(376097, NA), 9, prov_5_usr)),
#          prov_act_cor=ifelse(geolev1 %in% c(376097, NA), 9,
#                                     ifelse(geolev1==376001, 2, #376001 Jarusalem, the capital 
#                                            ifelse(geolev1 %notin% c(376097, 376099, NA, 376001) & prov_act_usr==0, 0, 
#                                                   ifelse(geolev1 %notin% c(376097, 376099, NA, 376001) & (prov_act_usr==1 | prov_act_usr==2), 3,NA)))),
#          prov_5_cor=ifelse(geomig1_pcode==376099, NA,
#                            ifelse(geomig1_pcode==376001, 2, 
#                                          ifelse(geomig1_pcode!=376001 & prov_5_usr==9, 9,
#                                                 ifelse(geomig1_pcode!=376001 & prov_5_usr==0, 0,
#                                                        ifelse(geomig1_pcode!=376001 & (prov_5_usr==1 | prov_5_usr==2), 3,NA))))),
#          educ=as.integer(edattain),
#          educ=ifelse(educ==1, NA, 
#                      ifelse(educ==2, 0, 
#                             ifelse(educ==3, 1, 
#                                    ifelse(educ>=4 & educ<=5, 2, NA)))),
#          age=as.integer(age)-1,
#          age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
#                          60:64=16;65:69=17;70:74=18;75:79=19;else=20")) %>%
#   sample_frac(0.05)
# write.dta(il83, "asia calibrate rates/sample_april2021/5-year in/IL_1983.dta")
# write.dta(il83, "asia calibrate rates/sample_april2021/5-year out/IL_1983.dta")

#malaysia 1991
my91<-read.dta("malay91.dta")
geomig5my<-grep("State: Malaysia", geomig5$geomig1_5, value=TRUE)
geomig5my[geomig5id %notin% my91$geomig1_5] #15 states not in malay91, doesn't matter
unique(my91$geomig1_5)[unique(my91$geomig1_5) %notin% geomig5my]
sample<-sum(my91$perwt)
lev1<-my91 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-my91 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.506/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
my91<-my91 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig5, by="geomig1_5") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_5_ur=ur, prov_5_usr=usr) %>%
  #prov_act_cor, prov_5_cor 0 rural, 2 capital, 3 urban, 5 abroad 9 dk-missing 
  #prov_5_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_5_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate5 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 458099, #generated NIU
                              ifelse(migrate5=="Abroad", 458097,
                                     ifelse(migrate5 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 458098, geomig1_pcode))),
         prov_5_ur=ifelse(geomig1_pcode==458099, NA, 
                          ifelse(geomig1_pcode==458097, 5, #458097 abroad
                                 ifelse(geomig1_pcode %in% c(458098, NA), 9, prov_5_ur))), #458098 unknown
         prov_5_usr=ifelse(geomig1_pcode==458099, NA, 
                           ifelse(geomig1_pcode==458097, 5,
                                  ifelse(geomig1_pcode %in% c(458098, NA), 9, prov_5_usr))),
         prov_act_cor=ifelse(geolev1==458097, 5, 
                             ifelse(geolev1 %in% c(458099, 458098, NA), 9,
                                    ifelse(geolev1==458010, 2, #458010 Kuala Lumpur, the capital 
                                           ifelse(geolev1 %notin% c(458097, 458099, 458098, NA, 458010) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(458097, 458099, 458098, NA, 458010) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_5_cor=ifelse(geomig1_pcode==458099, NA, 
                           ifelse(geomig1_pcode==458010, 2, 
                                  ifelse(geomig1_pcode!=458010 & prov_5_usr==5, 5,
                                         ifelse(geomig1_pcode!=458010 & prov_5_usr==9, 9,
                                                ifelse(geomig1_pcode!=458010 & prov_5_usr==0, 0,
                                                       ifelse(geomig1_pcode!=458010 & (prov_5_usr==1 | prov_5_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
#%>%sample_frac(0.1)
write.dta(my91, "asia calibrate rates/5-year in/MY_1991.dta")
write.dta(my91, "asia calibrate rates/5-year out/MY_1991.dta")

#malaysia 2000
my00<-read.dta("malay00.dta")
geomig5my<-grep("State: Malaysia", geomig5$geomig1_5, value=TRUE)
geomig5my[geomig5id %notin% my00$geomig1_5] #15 states not in malay00, doesn't matter
my00$geomig1_5[my00$geomig1_5 %notin% geomig5my]
sample<-sum(my00$perwt)
lev1<-my00 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-my00 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.62/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
my00<-my00 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig5, by="geomig1_5") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_5_ur=ur, prov_5_usr=usr) %>%
  #prov_act_cor, prov_5_cor 0 rural, 2 capital, 3 urban, 5 abroad 9 dk-missing 
  #prov_5_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_5_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate5 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 458099, #generated NIU
                              ifelse(migrate5=="Abroad", 458097,
                                     ifelse(migrate5 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 458098, geomig1_pcode))),
         prov_5_ur=ifelse(geomig1_pcode==458099, NA, 
                          ifelse(geomig1_pcode==458097, 5, #458097 abroad
                                 ifelse(geomig1_pcode %in% c(458098, NA), 9, prov_5_ur))), #458098 unknown
         prov_5_usr=ifelse(geomig1_pcode==458099, NA, 
                           ifelse(geomig1_pcode==458097, 5,
                                  ifelse(geomig1_pcode %in% c(458098, NA), 9, prov_5_usr))),
         prov_act_cor=ifelse(geolev1==458097, 5, 
                             ifelse(geolev1 %in% c(458099, 458098, NA), 9,
                                    ifelse(geolev1==458010, 2, #458010 Kuala Lumpur, the capital 
                                           ifelse(geolev1 %notin% c(458097, 458099, 458098, NA, 458010) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(458097, 458099, 458098, NA, 458010) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_5_cor=ifelse(geomig1_pcode==458099, NA, 
                           ifelse(geomig1_pcode==458010, 2, 
                                  ifelse(geomig1_pcode!=458010 & prov_5_usr==5, 5,
                                         ifelse(geomig1_pcode!=458010 & prov_5_usr==9, 9,
                                                ifelse(geomig1_pcode!=458010 & prov_5_usr==0, 0,
                                                       ifelse(geomig1_pcode!=458010 & (prov_5_usr==1 | prov_5_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"))
#%>%sample_frac(0.1)
write.dta(my00, "asia calibrate rates/5-year in/MY_2000.dta")
write.dta(my00, "asia calibrate rates/5-year out/MY_2000.dta")

#nepal 2001 
np01<-read.dta("nepal01.dta")
geomig5np<-grep("Administrative Zone: Nepal", geomig5$geomig1_5, value=TRUE)
geomig5np[geomig5np %notin% np01$geomig1_5] #foreign country not in nepal01, need to adjust by migrate5
np01$geomig1_5[np01$geomig1_5 %notin% geomig5np] 
WUP=0.139
sample<-sum(np01$perwt)
lev1<-np01 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-np01 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.139/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban) 
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
       usr=ifelse(urban<=0.5, 0, 
                  ifelse(urban>0.5 & urban<=0.85, 1, 2)))
np01<-np01 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig5, by="geomig1_5") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_5_ur=ur, prov_5_usr=usr) %>%
  #prov_act_cor, prov_5_cor 0 rural, 2 capital, 3 urban, 5 abroad 9 dk-missing 
  #prov_5_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_5_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate5 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 524099, 
                              ifelse(migrate5=="Abroad", 524097, #generated abroad
                                     ifelse(migrate5 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 524098, geomig1_pcode))),
         prov_5_ur=ifelse(geomig1_pcode==524099, NA, #524099 NIU
                          ifelse(geomig1_pcode==524097, 5, #524097 abroad
                                 ifelse(geomig1_pcode %in% c(524098, NA), 9, prov_5_ur))), #524098 unknown
         prov_5_usr=ifelse(geomig1_pcode==524099, NA,
                           ifelse(geomig1_pcode==524097, 5,
                                  ifelse(geomig1_pcode %in% c(524098, NA), 9, prov_5_usr))),
         prov_act_cor=ifelse(geolev1==524097, 5, 
                             ifelse(geolev1 %in% c(524098, 524099, NA), 9,
                                    ifelse(geolev1==524005, 2, #524005 bagmati where kathmandu located, the capital 
                                           ifelse(geolev1 %notin% c(524097, 524098, 524099, NA, 524005) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(524097, 524098, 524099, NA, 524005) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_5_cor=ifelse(geomig1_pcode==524099, NA,
                           ifelse(geomig1_pcode==524005, 2, 
                                  ifelse(geomig1_pcode!=524005 & prov_5_usr==5, 5,
                                         ifelse(geomig1_pcode!=524005 & prov_5_usr==9, 9,
                                                ifelse(geomig1_pcode!=524005 & prov_5_usr==0, 0,
                                                       ifelse(geomig1_pcode!=524005 & (prov_5_usr==1 | prov_5_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
#%>% sample_frac(0.05)
write.dta(np01, "asia calibrate rates/5-year in/NP_2001.dta")
write.dta(np01, "asia calibrate rates/5-year out/NP_2001.dta")

#nepal 2011
np11<-read.dta("nepal11.dta")
geomig5np<-grep("Administrative Zone: Nepal", geomig5$geomig1_5, value=TRUE)
geomig5np[geomig5np %notin% np11$geomig1_5] #foreign country not in nepal11, need to adjust by migrate5
np11$geomig1_5[np11$geomig1_5 %notin% geomig5np] 
sample<-sum(np11$perwt)
WUP=0.171
lev1<-np11 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-np11 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.171/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban) 
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
np11<-np11 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig5, by="geomig1_5") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_5_ur=ur, prov_5_usr=usr) %>%
  #prov_act_cor, prov_5_cor 0 rural, 2 capital, 3 urban, 5 abroad 9 dk-missing 
  #prov_5_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_5_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate5 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 524099, #generated NIU
                              ifelse(migrate5=="Abroad", 524097, #generated abroad
                                     ifelse(migrate5 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 524098, geomig1_pcode))),
         prov_5_ur=ifelse(geomig1_pcode==524099, NA, #524099 NIU
                          ifelse(geomig1_pcode==524097, 5, #524097 abroad
                                 ifelse(geomig1_pcode %in% c(524098, NA), 9, prov_5_ur))), #360098 unknown
         prov_5_usr=ifelse(geomig1_pcode==524099, NA,
                           ifelse(geomig1_pcode==524097, 5,
                                  ifelse(geomig1_pcode %in% c(524098, NA), 9, prov_5_usr))),
         prov_act_cor=ifelse(geolev1==524097, 5, 
                             ifelse(geolev1 %in% c(524098, 524099, NA), 9,
                                    ifelse(geolev1==524005, 2, #524005 bagmati where kathmandu located, the capital 
                                           ifelse(geolev1 %notin% c(524097, 524098, 524099, NA, 524005) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(524097, 524098, 524099, NA, 524005) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_5_cor=ifelse(geomig1_pcode==524099, NA,
                           ifelse(geomig1_pcode==524005, 2, 
                                  ifelse(geomig1_pcode!=524005 & prov_5_usr==5, 5,
                                         ifelse(geomig1_pcode!=524005 & prov_5_usr==9, 9,
                                                ifelse(geomig1_pcode!=524005 & prov_5_usr==0, 0,
                                                       ifelse(geomig1_pcode!=524005 & (prov_5_usr==1 | prov_5_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) %>%
  mutate(migr5y=(!is.na(prov_5_ur))) 
#%>%sample_frac(0.05)
write.dta(np11, "asia calibrate rates/5-year in/NP_2011.dta")
write.dta(np11, "asia calibrate rates/5-year out/NP_2011.dta")

#philippines 2000
externalph00<-read.dta13("philippines00 external.dta") %>%
  select(province, urban00, pop00) %>%
  mutate(urban00=as.numeric(as.character(urban00)),
         pop00=as.numeric(as.character(pop00)), 
         province=tolower(province)) %>%
  rename(urban=urban00, pop=pop00)
geomig5ph00<-geomig5 %>%
  mutate(code=as.integer(as.character(code)), 
         geomig1_5=tolower(str_sub(geomig1_5, end=-25))) %>%
  filter(code>=608001 & code<608097)
dif<-as.character(setdiff(geomig5ph00$geomig1_5,externalph00$province)) #check what regions are in geomig5ph00 but not externalph00
WUP=0.461
lev1<-externalph00 %>%
  slice(-1) %>%
  filter(!is.na(urban)) %>%
  arrange(-urban) %>%
  mutate(urban=urban/100,pop=pop/sum(pop),
         province=factor(province,levels = province)) 
popdif<-c(lev1$pop[lev1$province=="basilan"], 
          lev1$pop[lev1$province=="cagayan"]+lev1$pop[lev1$province=="batanes"], 
          lev1$pop[lev1$province=="davao"]+lev1$pop[lev1$province=="compostela valley"], lev1$pop[lev1$province=="iloilo"]+lev1$pop[lev1$province=="guimaras"],
          lev1$pop[lev1$province=="kalinga"]+lev1$pop[lev1$province=="apayao"], 
          lev1$pop[lev1$province=="leyte"]+lev1$pop[lev1$province=="biliran"], 
          lev1$pop[lev1$province=="maguindanao"]+lev1$pop[lev1$province=="cotabato city"],
          lev1$pop[lev1$province=="north cotabato"], lev1$pop[lev1$province=="samar (w samar)"], 
          lev1$pop[lev1$province=="south cotabato"]+lev1$pop[lev1$province=="sarangani"], lev1$pop[lev1$province=="surigao del norte"],
          lev1$pop[lev1$province=="zamboanga del norte"], lev1$pop[lev1$province=="zamboanga de sur"],
          lev1$pop[lev1$province=="city of mandaluyong"]+lev1$pop[lev1$province=="city of manikina"]+
            lev1$pop[lev1$province=="city of pasig"]+lev1$pop[lev1$province=="quezon ciy"]+lev1$pop[lev1$province=="san juan"],
          lev1$pop[lev1$province=="kalooan city"]+lev1$pop[lev1$province=="malabon"]+lev1$pop[lev1$province=="navotas"]+lev1$pop[lev1$province=="city of valenzuela"],
          lev1$pop[lev1$province=="city of las pinas"]+lev1$pop[lev1$province=="city of makati"]+
            lev1$pop[lev1$province=="city of muntinlupa"]+lev1$pop[lev1$province=="city of paranaque"]+
            lev1$pop[lev1$province=="pasay city"]+lev1$pop[lev1$province=="pateros"]+lev1$pop[lev1$province=="taguig"])
urbandif<-c(lev1$urban[lev1$province=="basilan"], 
            (lev1$pop[lev1$province=="cagayan"]*lev1$urban[lev1$province=="cagayan"]+lev1$pop[lev1$province=="batanes"]*lev1$urban[lev1$province=="batanes"])/popdif[2], 
            (lev1$urban[lev1$province=="davao"]*lev1$pop[lev1$province=="davao"]+lev1$urban[lev1$province=="compostela valley"]*lev1$pop[lev1$province=="compostela valley"])/(lev1$pop[lev1$province=="davao"]+lev1$pop[lev1$province=="compostela valley"]), 
            (lev1$pop[lev1$province=="iloilo"]*lev1$urban[lev1$province=="iloilo"]+lev1$pop[lev1$province=="guimaras"]*lev1$urban[lev1$province=="guimaras"])/popdif[4],
            (lev1$pop[lev1$province=="kalinga"]*lev1$urban[lev1$province=="kalinga"]+lev1$pop[lev1$province=="apayao"]*lev1$urban[lev1$province=="apayao"])/popdif[5], 
            (lev1$pop[lev1$province=="leyte"]*lev1$urban[lev1$province=="leyte"]+lev1$pop[lev1$province=="biliran"]*lev1$urban[lev1$province=="biliran"])/popdif[6], 
            (lev1$pop[lev1$province=="maguindanao"]*lev1$urban[lev1$province=="maguindanao"]+lev1$pop[lev1$province=="cotabato city"]*lev1$urban[lev1$province=="cotabato city"])/popdif[7],
            lev1$urban[lev1$province=="north cotabato"], lev1$urban[lev1$province=="samar (w samar)"], 
            (lev1$pop[lev1$province=="south cotabato"]*lev1$urban[lev1$province=="south cotabato"]+lev1$pop[lev1$province=="sarangani"]*lev1$urban[lev1$province=="sarangani"])/(lev1$pop[lev1$province=="south cotabato"]+lev1$pop[lev1$province=="sarangani"]),
            lev1$urban[lev1$province=="surigao del norte"],
            lev1$urban[lev1$province=="zamboanga del norte"], lev1$urban[lev1$province=="zamboanga de sur"],
            (lev1$pop[lev1$province=="city of mandaluyong"]*lev1$urban[lev1$province=="city of mandaluyong"]+lev1$pop[lev1$province=="city of manikina"]*lev1$urban[lev1$province=="city of manikina"]+
               lev1$pop[lev1$province=="city of pasig"]*lev1$urban[lev1$province=="city of pasig"]+lev1$pop[lev1$province=="quezon ciy"]*lev1$urban[lev1$province=="quezon ciy"]+lev1$pop[lev1$province=="san juan"]*lev1$urban[lev1$province=="san juan"])/popdif[14],
            (lev1$pop[lev1$province=="kalooan city"]+lev1$pop[lev1$province=="malabon"]+lev1$pop[lev1$province=="navotas"]+lev1$pop[lev1$province=="city of valenzuela"])/popdif[15],
            lev1$pop[lev1$province=="city of las pinas"]*lev1$urban[lev1$province=="city of las pinas"]+lev1$pop[lev1$province=="city of makati"]*lev1$urban[lev1$province=="city of makati"]+
              (lev1$pop[lev1$province=="city of muntinlupa"]*lev1$urban[lev1$province=="city of muntinlupa"]+lev1$pop[lev1$province=="city of paranaque"]*lev1$urban[lev1$province=="city of paranaque"]+
                 lev1$pop[lev1$province=="pasay city"]*lev1$urban[lev1$province=="pasay city"]+lev1$pop[lev1$province=="pateros"]*lev1$urban[lev1$province=="pateros"]+lev1$pop[lev1$province=="taguig"]*lev1$urban[lev1$province=="taguig"])/popdif[16])
data<-as.data.frame(as.matrix(cbind(dif, urbandif, popdif))) %>%
  rename(province=dif, urban=urbandif, pop=popdif) %>%
  mutate(urban=as.numeric(as.character(urbandif)), 
         pop=as.numeric(as.character(popdif)))
lanaodelsur<-data.table(province="lanao del sur", 
                        urban=(lev1$urban[lev1$province=="marawi city"]*lev1$pop[lev1$province=="marawi city"]+lev1$urban[lev1$province=="lanao del sur"]*lev1$pop[lev1$province=="lanao del sur"])/(lev1$pop[lev1$province=="marawi city"]+lev1$pop[lev1$province=="lanao del sur"]), 
                        pop=lev1$pop[lev1$province=="marawi city"]+lev1$pop[lev1$province=="lanao del sur"])
lev1<-lev1 %>%
  filter(province %in% geomig5ph00$geomig1_5 & province!="lanao del sur") %>%
  bind_rows(data, lanaodelsur) %>%
  full_join(geomig5ph00, by=c("province"="geomig1_5"))
sum(lev1$urban*lev1$pop)
total<-lev1 %>%
  summarise(upert=sum(urban*pop), 
            weight=0.461/upert)
lev1<-lev1 %>% 
  mutate(urban=urban*total$weight,
         ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2))) %>%
  arrange(-urban) 
sum(lev1$urban*lev1$pop)
ph00<-read.dta13("philippines00.dta")
geomig5ph<-grep("Province: Philippines", geomig5$geomig1_5, value=TRUE)
geomig5ph[geomig5ph %notin% unique(ph00$geomig1_5)] 
unique(ph00$geomig1_5)[unique(ph00$geomig1_5) %notin% geomig5ph] 
ph00<-ph00 %>%
  left_join(lev1[,c("code", "usr", "ur")], by=c("geolev1"="code")) %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig5, by="geomig1_5") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("code", "usr", "ur")], by=c("geomig1_pcode"="code")) %>%
  rename(prov_5_ur=ur, prov_5_usr=usr) %>%
  #prov_act_cor, prov_5_cor 0 rural, 2 capital, 3 urban, 5 abroad 9 dk-missing 
  #prov_5_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_5_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate5 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 608099, 
                              ifelse(migrate5=="Abroad", 608097, #generated abroad
                                     ifelse(migrate5 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 608098, geomig1_pcode))),
         prov_5_ur=ifelse(geomig1_pcode==608099, NA, #608099 NIU, 
                          ifelse(geomig1_pcode==608097, 5, #608097 abroad
                          ifelse(geomig1_pcode %in% c(608098, NA), 9, prov_5_ur))), #608098 unknown
         prov_5_usr=ifelse(geomig1_pcode==608099, NA, #608099 NIU, 
                           ifelse(geomig1_pcode==608097, 5,
                           ifelse(geomig1_pcode %in% c(608098, NA), 9, prov_5_usr))),
         prov_act_cor=ifelse(geolev1==608097, 5, 
                             ifelse(geolev1 %in% c(608098, NA), 9,
                                    ifelse(geolev1 %in% c(608039, 608074, 608075, 608076), 2, #manila, the capital 
                                           ifelse(geolev1 %notin% c(608097, 608098, NA, 608039, 608074, 608075, 608076) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(608039, 608097, 608098, NA, 608074, 608075, 608076) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_5_cor=ifelse(geomig1_pcode==608099, NA, #608099 NIU, 
                           ifelse(geomig1_pcode %in% c(608039, 608074, 608075, 608076), 2, 
                           ifelse(geomig1_pcode %notin% c(608039, 608074, 608075, 608076) & prov_5_usr==5, 5,
                                  ifelse(geomig1_pcode %notin% c(608039, 608074, 608075, 608076) & prov_5_usr==9, 9,
                                         ifelse(geomig1_pcode %notin% c(608039, 608074, 608075, 608076) & prov_5_usr==0, 0,
                                                ifelse(geomig1_pcode %notin% c(608039, 608074, 608075, 608076) & (prov_5_usr==1 | prov_5_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"))
#%>%sample_frac(0.05)
write.dta(ph00, "asia calibrate rates/5-year in/PH_2000.dta")
write.dta(ph00, "asia calibrate rates/5-year out/PH_2000.dta")


#philippines 2010
externalph10<-read_excel("externalph10.xlsx") %>%
  mutate(province=tolower(province))
geomig5ph10<-geomig5 %>%
  mutate(code=as.integer(as.character(code)), 
         geomig1_5=tolower(str_sub(geomig1_5, end=-25))) %>%
  filter(code>=608001 & code<608097)
geomig5ph10$geomig1_5[geomig5ph10$geomig1_5 %notin% externalph10$province]
externalph10$province[externalph10$province %notin% geomig5ph10$geomig1_5] #check difference between external source and IPUMS's codebook on geomig1_5
dif<-as.character(setdiff(lev1$province,geomig5ph10$geomig1_5)) #check difference between external source and IPUMS's codebook on geomig1_5
WUP=0.453
lev1<-externalph10 %>%
  filter(!is.na(urban10)) %>%
  arrange(-urban10) %>%
  mutate(province=factor(province,levels = province)) %>%
  rename(urban=urban10, pop=pop10)
basilan<-data.table(province="basilan, city of isabela", 
                    urban=(lev1$urban[lev1$province=="basilan, city of isabela"]*lev1$pop[lev1$province=="basilan, city of isabela"]+lev1$urban[lev1$province=="city of isabela"]*lev1$pop[lev1$province=="city of isabela"])/(lev1$pop[lev1$province=="basilan, city of isabela"]+lev1$pop[lev1$province=="city of isabela"]), 
                    pop=lev1$pop[lev1$province=="basilan, city of isabela"]+lev1$pop[lev1$province=="city of isabela"])
davaodelsur<-data.table(province="davao del sur", 
                        urban=(lev1$urban[lev1$province=="davao occidental"]*lev1$pop[lev1$province=="davao occidental"]+lev1$urban[lev1$province=="davao del sur"]*lev1$pop[lev1$province=="davao del sur"])/(lev1$pop[lev1$province=="davao occidental"]+lev1$pop[lev1$province=="davao del sur"]), 
                        pop=lev1$pop[lev1$province=="davao occidental"]+lev1$pop[lev1$province=="davao del sur"])
lev1<-lev1 %>%
  filter(province %in% geomig5ph10$geomig1_5 & province %notin% c("basilan, city of isabela", "davao del sur")) %>%
  bind_rows(basilan, davaodelsur) %>%
  full_join(geomig5ph10, by=c("province"="geomig1_5"))
sum(lev1$urban*lev1$pop)
total<-lev1 %>%
  summarise(upert=sum(urban*pop), 
            weight=0.453/upert)
lev1<-lev1 %>% 
  mutate(urban=urban*total$weight,
         ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2))) %>%
  arrange(-urban) 
sum(lev1$urban*lev1$pop)
ph10<-read.dta13("philippines10.dta")
geomig5ph<-grep("Province: Philippines", geomig5$geomig1_5, value=TRUE)
geomig5ph[geomig5ph %notin% unique(ph10$geomig1_5)] 
unique(ph10$geomig1_5)[unique(ph10$geomig1_5) %notin% geomig5ph] #check whether geomig1_5 codebook and ipums geomig1_5 corresponds
ph10<-ph10 %>%
  left_join(lev1[,c("code", "usr", "ur")], by=c("geolev1"="code")) %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig5, by="geomig1_5") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("code", "usr", "ur")], by=c("geomig1_pcode"="code")) %>%
  rename(prov_5_ur=ur, prov_5_usr=usr) %>%
  #prov_act_cor, prov_5_cor 0 rural, 2 capital, 3 urban, 5 abroad 9 dk-missing 
  #prov_5_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_5_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate5 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 608099, 
                              ifelse(migrate5=="Abroad", 608097, 
                                     ifelse(migrate5 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), 608098, geomig1_pcode))),
         prov_5_ur=ifelse(geomig1_pcode==608099, NA, #608099 NIU, 
                          ifelse(geomig1_pcode==608097, 5, #608097 abroad
                                 ifelse(geomig1_pcode %in% c(608098, NA), 9, prov_5_ur))), #608098 unknown
         prov_5_usr=ifelse(geomig1_pcode==608099, NA, #608099 NIU, 
                           ifelse(geomig1_pcode==608097, 5,
                                  ifelse(geomig1_pcode %in% c(608098, NA), 9, prov_5_usr))),
         prov_act_cor=ifelse(geolev1==608097, 5, 
                             ifelse(geolev1 %in% c(608098, NA), 9,
                                    ifelse(geolev1 %in% c(608039, 608074, 608075, 608076), 2, #manila, the capital 
                                           ifelse(geolev1 %notin% c(608097, 608098, NA, 608039, 608074, 608075, 608076) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(608039, 608097, 608098, NA, 608074, 608075, 608076) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_5_cor=ifelse(geomig1_pcode==608099, NA, #608099 NIU, 
                           ifelse(geomig1_pcode %in% c(608039, 608074, 608075, 608076), 2, 
                                  ifelse(geomig1_pcode %notin% c(608039, 608074, 608075, 608076) & prov_5_usr==5, 5,
                                         ifelse(geomig1_pcode %notin% c(608039, 608074, 608075, 608076) & prov_5_usr==9, 9,
                                                ifelse(geomig1_pcode %notin% c(608039, 608074, 608075, 608076) & prov_5_usr==0, 0,
                                                       ifelse(geomig1_pcode %notin% c(608039, 608074, 608075, 608076) & (prov_5_usr==1 | prov_5_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
#%>%sample_frac(0.05)
write.dta(ph10, "asia calibrate rates/5-year in/PH_2010.dta")
write.dta(ph10, "asia calibrate rates/5-year out/PH_2010.dta")

#vietnam 1989
vt89<-read.dta("vietnam89.dta")
geomig5vt<-grep("Province: Vietnam", geomig5$geomig1_5, value=TRUE)
geomig5vt[geomig5vt %notin% vt89$geomig1_5] #2 provinces not in viet89, doesn't matter
vt89$geomig1_5[vt89$geomig1_5 %notin% geomig5vt] 
sample<-sum(vt89$perwt)
total<-vt89 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.199/upert)
WUP=0.199
lev1<-vt89 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"])) %>%
  ungroup() %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
vt89<-vt89 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig5, by="geomig1_5") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_5_ur=ur, prov_5_usr=usr) %>%
  #prov_act_cor, prov_5_cor 0 rural, 2 capital, 3 urban, 5 abroad 9 dk-missing 
  #prov_5_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_5_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate5 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 704099, 
                              ifelse(migrate5=="Abroad", 704098, 
                                     ifelse(migrate5 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), NA, geomig1_pcode))),
         prov_5_ur=ifelse(geomig1_pcode==704099, NA, #704099 NIU
                          ifelse(geomig1_pcode==704098, 5, #704098 abroad
                                 ifelse(is.na(geomig1_pcode), 9, prov_5_ur))), 
         prov_5_usr=ifelse(geomig1_pcode==704099, NA,
                           ifelse(geomig1_pcode==704098, 5,
                                  ifelse(is.na(geomig1_pcode), 9, prov_5_usr))),
         prov_act_cor=ifelse(geolev1==704098, 5, 
                             ifelse(geolev1 %in% c(704098, NA), 9,
                                    ifelse(geolev1==704079, 2, #704079 ho chi ming city, the capital 
                                           ifelse(geolev1 %notin% c(704098, 704099, NA, 704079) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(704098, 704099, NA, 704079) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_5_cor=ifelse(geomig1_pcode==704099, NA,
                           ifelse(geomig1_pcode==704079, 2, 
                                  ifelse(geomig1_pcode!=704079 & prov_5_usr==5, 5,
                                         ifelse(geomig1_pcode!=704079 & prov_5_usr==9, 9,
                                                ifelse(geomig1_pcode!=704079 & prov_5_usr==0, 0,
                                                       ifelse(geomig1_pcode!=704079 & (prov_5_usr==1 | prov_5_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
#%>% sample_frac(0.05)
write.dta(vt89, "asia calibrate rates/5-year in/VT_1989.dta")
write.dta(vt89, "asia calibrate rates/5-year out/VT_1989.dta")

#vietnam99
vt99<-read.dta("vietnam99.dta")
geomig5vt<-grep("Province: Vietnam", geomig5$geomig1_5, value=TRUE)
geomig5vt[geomig5vt %notin% vt99$geomig1_5] 
vt99$geomig1_5[vt99$geomig1_5 %notin% geomig5vt] 
sample<-sum(vt99$perwt)
WUP=0.238
total<-vt99 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.238/upert)
lev1<-vt99 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"])) %>%
  ungroup() %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
vt99<-vt99 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig5, by="geomig1_5") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_5_ur=ur, prov_5_usr=usr) %>%
  #prov_act_cor, prov_5_cor 0 rural, 2 capital, 3 urban, 5 abroad 9 dk-missing 
  #prov_5_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_5_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate5 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 704099, 
                              ifelse(migrate5=="Abroad", 704098, 
                                     ifelse(migrate5 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), NA, geomig1_pcode))),
         prov_5_ur=ifelse(geomig1_pcode==704099, NA, #704099 NIU
                          ifelse(geomig1_pcode==704098, 5, #704098 abroad
                                 ifelse(is.na(geomig1_pcode), 9, prov_5_ur))), #360098 unknown
         prov_5_usr=ifelse(geomig1_pcode==704099, NA,
                           ifelse(geomig1_pcode==704098, 5,
                                  ifelse(is.na(geomig1_pcode), 9, prov_5_usr))),
         prov_act_cor=ifelse(geolev1==704098, 5, 
                             ifelse(geolev1 %in% c(704098, NA), 9,
                                    ifelse(geolev1==704079, 2, #704079 ho chi ming city, the capital 
                                           ifelse(geolev1 %notin% c(704098, 704099, NA, 704079) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(704098, 704099, NA, 704079) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_5_cor=ifelse(geomig1_pcode==704099, NA,
                           ifelse(geomig1_pcode==704079, 2, 
                                  ifelse(geomig1_pcode!=704079 & prov_5_usr==5, 5,
                                         ifelse(geomig1_pcode!=704079 & prov_5_usr==9, 9,
                                                ifelse(geomig1_pcode!=704079 & prov_5_usr==0, 0,
                                                       ifelse(geomig1_pcode!=704079 & (prov_5_usr==1 | prov_5_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"))
#%>%sample_frac(0.05)
write.dta(vt99, "asia calibrate rates/5-year in/VT_1999.dta")
write.dta(vt99, "asia calibrate rates/5-year out/VT_1999.dta")

#vietnam09
vt09<-read.dta("vietnam09.dta")
geomig5vt<-grep("Province: Vietnam", geomig5$geomig1_5, value=TRUE)
geomig5vt[geomig5vt %notin% viet09$geomig1_5] 
vt09$geomig1_5[vt09$geomig1_5 %notin% geomig5vt] 
WUP=0.298
sample<-sum(vt09$perwt)
total<-vt09 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.298/upert)
lev1<-vt09 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"])) %>%
  ungroup() %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
vt09<-vt09 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomig5, by="geomig1_5") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_5_ur=ur, prov_5_usr=usr) %>%
  #prov_act_cor, prov_5_cor 0 rural, 2 capital, 3 urban, 5 abroad 9 dk-missing 
  #prov_5_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_5_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migrate5 %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 704099, 
                              ifelse(migrate5=="Abroad", 704098, 
                                     ifelse(migrate5 %in% c("Not reported/missing", "Response suppressed", "Unknown/missing"), NA, geomig1_pcode))),
         prov_5_ur=ifelse(geomig1_pcode==704099, NA, #704099 NIU
                          ifelse(geomig1_pcode==704098, 5, #704098 abroad
                                 ifelse(is.na(geomig1_pcode), 9, prov_5_ur))), #360098 unknown
         prov_5_usr=ifelse(geomig1_pcode==704099, NA,
                           ifelse(geomig1_pcode==704098, 5,
                                  ifelse(is.na(geomig1_pcode), 9, prov_5_usr))),
         prov_act_cor=ifelse(geolev1==704098, 5, 
                             ifelse(geolev1 %in% c(704098, NA), 9,
                                    ifelse(geolev1==704079, 2, #704079 ho chi ming city, the capital 
                                           ifelse(geolev1 %notin% c(704098, 704099, NA, 704079) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(704098, 704099, NA, 704079) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_5_cor=ifelse(geomig1_pcode==704099, NA,
                           ifelse(geomig1_pcode==704079, 2, 
                                  ifelse(geomig1_pcode!=704079 & prov_5_usr==5, 5,
                                         ifelse(geomig1_pcode!=704079 & prov_5_usr==9, 9,
                                                ifelse(geomig1_pcode!=704079 & prov_5_usr==0, 0,
                                                       ifelse(geomig1_pcode!=704079 & (prov_5_usr==1 | prov_5_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20")) 
#%>%sample_frac(0.05)
write.dta(vt09, "asia calibrate rates/5-year in/VT_2009.dta")
write.dta(vt09, "asia calibrate rates/5-year out/VT_2009.dta")
