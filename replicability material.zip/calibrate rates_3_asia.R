#first setwd

`%notin%` <- Negate(`%in%`)
library(pacman)
pacman::p_load(foreign, car, stringi, readxl, gdata, labelled, ipumsr, readstata13, dplyr, tidyr, tidyverse, gmodels)
geomig5<-read.dta13("geomig1_5.dta") %>%
  rename(code=var1, geomig1_5=var3) %>%
  mutate(code=as.integer(code))
geomigp<-read.dta13("geomig1_p.dta") 

#id71, geolev1. length(unique(indo10$geomig1_5))==length(unique(indo05$mig1_5_id))
id71<-read.dta("indo71.dta")
geomig_pid<-grep("Province: Indonesia", geomigp$geomig1_p, value=TRUE)
geomig_pid[geomig_pid %notin% indo71$geomig1_p] #east timor not in indo71
id71$geomig1_p[id71$geomig1_p %notin% geomig_pid] 
WUP=0.173
sample<-sum(id71$perwt)
lev1<-id71 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-id71 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.173/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
id71<-id71 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  #prov_act_cor, prov_3_cor 0 rural, 2 capital, 3 urban, 5 abroad 9 dk-missing 
  #prov_3_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_3_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         #verify that geomig1_pcode is coded consistently with migratep
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 360099, 
                               ifelse(migratep=="Abroad", 360097,
                                      ifelse(migratep %in% c("Not reported/missing", "Response suppressed"), 360098, geomig1_pcode))),
         prov_3_ur=ifelse(geomig1_pcode==360099, NA, #360099 NIU
                          ifelse(geomig1_pcode==360097, 5, #360097 abroad
                                 ifelse(geomig1_pcode %in% c(360098, NA), 9, prov_3_ur))), #360098 unknown
         prov_3_usr=ifelse(geomig1_pcode==360099, NA,
                           ifelse(geomig1_pcode==360097, 5,
                                  ifelse(geomig1_pcode %in% c(360098, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==360097, 5, 
                             ifelse(geolev1 %in% c(360098, 360099, NA), 9,
                                    ifelse(geolev1==360031, 2, #360031 DKI Jakarta, the capital 
                                           ifelse(geolev1 %notin% c(360097, 360098, 360099, NA, 360031) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(360097, 360098, 360099, NA, 360031) & (prov_act_usr==1 | prov_act_usr==2),3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==360099, NA,
                           ifelse(geomig1_pcode==360031, 2, 
                                  ifelse(geomig1_pcode!=360031 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=360031 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=360031 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=360031 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                         ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1) 
#%>% sample_frac(0.05)
write.dta(id71, "/asia calibrate rates/3-year in/ID_1971.dta")
write.dta(id71, "/asia calibrate rates/3-year out/ID_1971.dta")

#id80, not necessary to adjust, use 5-year because migyrs1 has unknown
# id80<-read.dta("id80.dta")
# geomig_pid<-grep("Province: Indonesia", geomigp$geomig1_p, value=TRUE)
# geomig_pid[geomig_pid %notin% id80$geomig1_p] #NIU not in indo80
# id80$geomig1_p[id80$geomig1_p %notin% geomig_pid]
# sample<-sum(id80$perwt)
# lev1<-id80 %>%
#   group_by(geolev1) %>%
#   summarise(pop=sum(perwt), 
#             urban=sum(perwt[urban=="Urban"]))
# total<-id80 %>%
#   summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
#             weight=0.221/upert)
# lev1<-lev1 %>%
#   mutate(urban=urban/pop*total$weight, 
#          pop=pop/sample) %>%
#   arrange(-urban) %>%
#   mutate(ur=ifelse(urban<=0.5, 0, 1),  
#          usr=ifelse(urban<=0.5, 0, 
#                     ifelse(urban>0.5 & urban<=0.85, 1, 2)))
# indo80<-indo80 %>%
#   left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
#   rename(prov_act_ur=ur, prov_act_usr=usr) %>%
#   dplyr::left_join(geomigp, by="geomig1_p") %>%  
#   rename(geomig1_pcode=code) %>%
#   mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
#   left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
#   rename(prov_3_ur=ur, prov_3_usr=usr) %>%
#   #prov_act_cor, prov_3_cor 0 rural, 2 capital, 3 urban, 5 abroad 9 dk-missing 
#   #prov_3_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
#   #prov_3_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
#   mutate(caseid=(serial*100) + pernum,
#          geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 360099, #generated 360099 
#                               ifelse(migratep=="Abroad", 360097,
#                                      ifelse(migratep %in% c("Not reported/missing", "Response suppressed"), 360098, geomig1_pcode))),
#          prov_3_ur=ifelse(geomig1_pcode==360099, NA, #360099 NIU
#                           ifelse(geomig1_pcode==360097, 5, #360097 abroad
#                                  ifelse(geomig1_pcode %in% c(360098, NA), 9, prov_3_ur))), #360098 unknown
#          prov_3_usr=ifelse(geomig1_pcode==360099, NA,
#                            ifelse(geomig1_pcode==360097, 5,
#                                   ifelse(geomig1_pcode %in% c(360098, NA), 9, prov_3_usr))),
#          prov_act_cor=ifelse(geolev1==360097, 5, 
#                              ifelse(geolev1 %in% c(360098, 360099, NA), 9,
#                                     ifelse(geolev1==360031, 2, #360031 DKI Jakarta, the capital 
#                                            ifelse(geolev1 %notin% c(360097, 360098, 360099, NA, 360031) & prov_act_usr==0, 0, 
#                                                   ifelse(geolev1 %notin% c(360097, 360098, 360099, NA, 360031) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
#          prov_3_cor=ifelse(geomig1_pcode==360099, NA,
#                            ifelse(geomig1_pcode==360031, 2, 
#                                   ifelse(geomig1_pcode!=360031 & prov_3_usr==5, 5,
#                                          ifelse(geomig1_pcode!=360031 & prov_3_usr==9, 9,
#                                                 ifelse(geomig1_pcode!=360031 & prov_3_usr==0, 0,
#                                                        ifelse(geomig1_pcode!=360031 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
#          educ=as.integer(edattain),
#          educ=ifelse(educ==1, NA, 
#                      ifelse(educ==2, 0, 
#                             ifelse(educ==3, 1, 
#                                    ifelse(educ>=4 & educ<=5, 2, NA)))),
#          age=as.integer(age)-1,
#          age=ifelse(age>100, NA, age),
#          age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
#                          60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
#          migyrs1=ifelse(migyrs1=="Unknown", NA, 
#                         ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
#          migyrs1=as.integer(migyrs1)-1) %>%
#   arrange(serial, pernum) %>%
#   mutate(rownum=row_number(serial)) %>%
#   sample_frac(0.05)
# id<-indo80$rownum
# write.dta(indo80, "/asia calibrate rates/sample_april2021/3-year in/ID_1980.dta")
# write.dta(indo80, "/asia calibrate rates/sample_april2021/3-year out/ID_1980.dta")

#id85, 3-year
id85<-read.dta("indo85.dta")
geomig_pid<-grep("Province: Indonesia", geomigp$geomig1_p, value=TRUE)
geomig_pid[geomig_pid %notin% id85$geomig1_p]
id85$geomig1_p[id85$geomig1_p %notin% geomig_pid]
sample<-sum(id85$perwt)
lev1<-id85 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-id85 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.261/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%  
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
                              usr=ifelse(urban<=0.5, 0, 
                                         ifelse(urban>0.5 & urban<=0.85, 1, 2)))
id85<-id85 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  #prov_act_cor, prov_3_cor 0 rural, 2 capital, 3 urban, 5 abroad 9 dk-missing 
  #prov_3_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_3_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 360099, 
                              ifelse(migratep=="Abroad", 360097,
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed"), 360098, geomig1_pcode))),
         prov_3_ur=ifelse(geomig1_pcode==360099, NA, #360099 NIU
                          ifelse(geomig1_pcode==360097, 5, #360097 abroad
                                 ifelse(geomig1_pcode %in% c(360098, NA), 9, prov_3_ur))), #360098 unknown
         prov_3_usr=ifelse(geomig1_pcode==360099, NA,
                           ifelse(geomig1_pcode==360097, 5,
                                  ifelse(geomig1_pcode %in% c(360098, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==360097, 5, 
                             ifelse(geolev1 %in% c(360098, 360099, NA), 9,
                                    ifelse(geolev1==360031, 2, #360031 DKI Jakarta, the capital 
                                           ifelse(geolev1 %notin% c(360097, 360098, 360099, NA, 360031) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(360097, 360098, 360099, NA, 360031) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==360099, NA,
                           ifelse(geomig1_pcode==360031, 2, 
                                  ifelse(geomig1_pcode!=360031 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=360031 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=360031 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=360031 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1) 
#%>%sample_frac(0.1)
write.dta(id85, "/asia calibrate rates/3-year in/ID_1985.dta")
write.dta(id85, "/asia calibrate rates/3-year out/ID_1985.dta")

#id90, not necessary to adjust, 3-year
id90<-read.dta("indo90.dta")
geomig_pid<-grep("Province: Indonesia", geomigp$geomig1_p, value=TRUE)
geomig_pid[geomig_pid %notin% indo90$geomig1_p] 
id90$geomig1_5[id90$geomig1_p %notin% geomig_pid]
sample<-sum(id90$perwt)
total<-id90 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.306/upert)
lev1<-id90 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"])) %>%
  ungroup() %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban) %>% 
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
id90<-id90 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  #prov_act_cor, prov_3_cor 0 rural, 2 capital, 3 urban, 5 abroad 9 dk-missing 
  #prov_3_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_3_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 360099, 
                              ifelse(migratep=="Abroad", 360097,
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed"), 360098, geomig1_pcode))),
         prov_3_ur=ifelse(geomig1_pcode==360099, NA, #360099 NIU
                          ifelse(geomig1_pcode==360097, 5, #360097 abroad
                                 ifelse(geomig1_pcode %in% c(360098, NA), 9, prov_3_ur))), #360098 unknown
         prov_3_usr=ifelse(geomig1_pcode==360099, NA,
                           ifelse(geomig1_pcode==360097, 5,
                                  ifelse(geomig1_pcode %in% c(360098, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==360097, 5, 
                             ifelse(geolev1 %in% c(360098, 360099, NA), 9,
                                    ifelse(geolev1==360031, 2, #360031 DKI Jakarta, the capital 
                                           ifelse(geolev1 %notin% c(360097, 360098, 360099, NA, 360031) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(360097, 360098, 360099, NA, 360031) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==360099, NA,
                           ifelse(geomig1_pcode==360031, 2, 
                                  ifelse(geomig1_pcode!=360031 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=360031 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=360031 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=360031 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1) 
#%>%sample_frac(0.05)
write.dta(id90, "/asia calibrate rates/3-year in/ID_1990.dta")
write.dta(id90, "/asia calibrate rates/3-year out/ID_1990.dta")

#id95, 3-year
id95<-read.dta("indo95.dta")
geomig_pid<-grep("Province: Indonesia", geomigp$geomig1_p, value=TRUE)
geomig_pid[geomig_pid %notin% id95$geomig1_p] #unknown not in indo95
id95$geomig1_5[id95$geomig1_p %notin% geomig_pid]
sample<-sum(id95$perwt)
lev1<-id95 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-id95 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.361/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
id95<-id95 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  #prov_act_cor, prov_3_cor 0 rural, 2 capital, 3 urban, 5 abroad 9 dk-missing 
  #prov_3_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_3_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 360099,  
                              ifelse(migratep=="Abroad", 360097,
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed"), 360098, geomig1_pcode))),
         prov_3_ur=ifelse(geomig1_pcode==360099, NA, #360099 NIU
                          ifelse(geomig1_pcode==360097, 5, #360097 abroad
                                 ifelse(geomig1_pcode %in% c(360098, NA), 9, prov_3_ur))), #360098 unknown
         prov_3_usr=ifelse(geomig1_pcode==360099, NA,
                           ifelse(geomig1_pcode==360097, 5,
                                  ifelse(geomig1_pcode %in% c(360098, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==360097, 5, 
                             ifelse(geolev1 %in% c(360098, 360099, NA), 9,
                                    ifelse(geolev1==360031, 2, #360031 DKI Jakarta, the capital 
                                           ifelse(geolev1 %notin% c(360097, 360098, 360099, NA, 360031) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(360097, 360098, 360099, NA, 360031) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==360099, NA,
                           ifelse(geomig1_pcode==360031, 2, 
                                  ifelse(geomig1_pcode!=360031 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=360031 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=360031 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=360031 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1) 
#%>%sample_frac(0.05)
write.dta(id95, "/asia calibrate rates/3-year in/ID_1995.dta")
write.dta(id95, "/asia calibrate rates/3-year out/ID_1995.dta")

#indo05
id05<-read.dta("indo05.dta")
geomig_pid<-grep("Province: Indonesia", geomigp$geomig1_p, value=TRUE)
geomig_pid[geomig_pid %notin% id05$geomig1_p] #east timor not in indo05
id05$geomig1_5[id05$geomig1_p %notin% geomig_pid]
sample<-sum(id05$perwt)
WUP=0.459
lev1<-id05 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-id05 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.459/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
       usr=ifelse(urban<=0.5, 0, 
                  ifelse(urban>0.5 & urban<=0.85, 1, 2)))
id05<-id05 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  #prov_act_cor, prov_3_cor 0 rural, 2 capital, 3 urban, 5 abroad 9 dk-missing 
  #prov_3_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_3_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 360099, 
                              ifelse(migratep=="Abroad", 360097,
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed"), 360098, geomig1_pcode))),
         prov_3_ur=ifelse(geomig1_pcode==360099, NA, #360099 NIU
                          ifelse(geomig1_pcode==360097, 5, #360097 abroad
                                 ifelse(geomig1_pcode %in% c(360098, NA), 9, prov_3_ur))), #360098 unknown
         prov_3_usr=ifelse(geomig1_pcode==360099, NA,
                           ifelse(geomig1_pcode==360097, 5,
                                  ifelse(geomig1_pcode %in% c(360098, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==360097, 5, 
                             ifelse(geolev1 %in% c(360098, 360099, NA), 9,
                                    ifelse(geolev1==360031, 2, #360031 DKI Jakarta, the capital 
                                           ifelse(geolev1 %notin% c(360097, 360098, 360099, NA, 360031) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(360097, 360098, 360099, NA, 360031) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==360099, NA,
                           ifelse(geomig1_pcode==360031, 2, 
                                  ifelse(geomig1_pcode!=360031 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=360031 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=360031 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=360031 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1)
#%>%sample_frac(0.05)
write.dta(id05, "/asia calibrate rates/3-year in/ID_2005.dta")
write.dta(id05, "/asia calibrate rates/3-year out/ID_2005.dta")

#iraq97
iq97<-read.dta("iraq97.dta")
geomig_piq<-grep("Governorate: Iraq", geomigp$geomig1_p, value=TRUE)
geomig_piq[geomig_piq %notin% unique(iq97$geomig1_p)] 
iq97$geomig1_p[iq97$geomig1_p %notin% geomig_piq]
WUP=0.684
sample<-sum(iq97$perwt)
lev1<-iq97 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-iq97 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.684/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
iq97<-iq97 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  #prov_act_cor, prov_3_cor 0 rural, 2 capital, 3 urban, 5 abroad 9 dk-missing 
  #prov_3_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_3_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 368000, #368000 always lived in residential place of birth 
                              ifelse(migratep=="Abroad", 368097,
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed"), 368098, geomig1_pcode))),
         prov_3_ur=ifelse(geomig1_pcode %in% c(368000,368001), NA, #368000 always lived in the residential place of birth, 368001 in this governorate
                          ifelse(geomig1_pcode==368097, 5, #368097 abroad
                                 ifelse(geomig1_pcode %in% c(368098, NA), 9, prov_3_ur))), #368098 unknown
         prov_3_usr=ifelse(geomig1_pcode %in% c(368000,368001), NA,
                           ifelse(geomig1_pcode==368097, 5,
                                  ifelse(geomig1_pcode %in% c(368098, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==368097, 5, 
                             ifelse(geolev1 %in% c(368098, NA), 9,
                                    ifelse(geolev1==368023, 2, #368023 Baghdad, the capital 
                                           ifelse(geolev1 %notin% c(368097, 368098, NA, 368023) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(368097, 368098, NA, 368023) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode %in% c(368000,368001), NA,
                           ifelse(geomig1_pcode==368023, 2, 
                                  ifelse(geomig1_pcode!=368023 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=368023 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=368023 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=368023 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1) 
#%>%sample_frac(0.05)
write.dta(iq97, "/asia calibrate rates/3-year in/IQ_1997.dta")
write.dta(iq97, "/asia calibrate rates/3-year out/IQ_1997.dta")

#kyrgz99 on geolev2
kg99<-read.dta("kyrgz99.dta")
geomig_pky<-grep("Region: Kyrgyz Republic", geomigp$geomig1_p, value=TRUE)
geomig_pky[geomig_pky %notin% unique(kg99$geomig1_p)] 
kg99$geomig1_p[kg99$geomig1_p %notin% geomig_pky]
WUP=0.353
sample<-sum(kg99$perwt)
lev1<-kg99 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-kg99 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.353/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop, 
         pop=pop/sample) %>%
  arrange(-urban)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>% 
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
kg99<-kg99 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  #prov_act_cor, prov_3_cor 0 rural, 2 capital, 3 urban, 5 abroad 9 dk-missing 
  #prov_3_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_3_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 417099,
                              ifelse(migratep=="Abroad", 417097,
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed"), 417098, geomig1_pcode))),
         prov_3_ur=ifelse(geomig1_pcode==417099, NA, #417099 NIU
                          ifelse(geomig1_pcode==417097, 5, #417097 abroad
                                 ifelse(geomig1_pcode %in% c(417098, NA), 9, prov_3_ur))), #417098 unknown
         prov_3_usr=ifelse(geomig1_pcode==417099, NA,
                           ifelse(geomig1_pcode==417097, 5,
                                  ifelse(geomig1_pcode %in% c(417098, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==417097, 5, 
                             ifelse(geolev1 %in% c(417098, 417099, NA), 9,
                                    ifelse(geolev1==417001, 2, #417001 bishkek, the capital 
                                           ifelse(geolev1 %notin% c(417097, 417098, 417099, NA, 417001) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(417097, 417098, 417099, NA, 417001) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==417099, NA,
                           ifelse(geomig1_pcode==417001, 2, 
                                  ifelse(geomig1_pcode!=417001 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=417001 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=417001 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=417001 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1)
#%>%sample_frac(0.1)
write.dta(kg99, "/asia calibrate rates/3-year in/KG_1999.dta")
write.dta(kg99, "/asia calibrate rates/3-year out/KG_1999.dta")

#mongolia2000
externalmn00<-read.dta13("mongolia external.dta") %>%
  rename(province=aimag) %>%
  select(province, urban00, pop00) %>%
  filter(!is.na(urban00)) %>%
  rename(urban=urban00, pop=pop00)
WUP=0.571
lev1<-externalmn00 %>%
  slice(-1) %>%
  filter(!is.na(urban)) %>%
  arrange(-urban) %>%
  mutate(urban=as.numeric(urban),
         pop=as.numeric(pop),
         urban=urban/pop, 
         pop=pop/sum(pop),
         province=factor(province,levels = province)) 
geomigpmn00<-geomigp %>%
  mutate(code=as.integer(as.character(code))) %>%
  filter(code>=496001 & code<=496099)
lev1<-lev1 %>%
  mutate(province=paste0(province, " [Province: Mongolia]")) %>%
  full_join(geomigpmn00, by=c("province"="geomig1_p")) #here we notice some difference between the words in external source and ipums
DornogoviGovisumber<-data.table(province="Dornogovi, Govisumber [Province: Mongolia]", 
                                urban=(0.6109492*0.005103397+0.5698472*0.021212972)/(0.005103397+0.021212972), 
                                pop=0.005103397+0.021212972)
lev1<-lev1 %>%
  mutate(province=ifelse(province=="Khuvsgul [Province: Mongolia]", "Khovsgol [Province: Mongolia]", 
                         ifelse(province=="Bayan-Ulgii [Province: Mongolia]", "Bayan-Olgii [Province: Mongolia]", 
                                ifelse(province=="Umnugovi [Province: Mongolia]", "Omnogovi [Province: Mongolia]", 
                                       ifelse(province=="Uvurkhangai [Province: Mongolia]", "Ovorkhangai [Province: Mongolia]", 
                                              ifelse(province=="Tuv [Province: Mongolia]", "Tov [Province: Mongolia]", province)))))) %>%
  bind_rows(DornogoviGovisumber) %>%
  filter(province %notin% c("Dornogovi [Province: Mongolia]", "Govisumber [Province: Mongolia]")) %>%
  select(-code) %>%
  filter(!is.na(urban)) %>%
  full_join(geomigpmn00, by=c("province"="geomig1_p")) %>%
  filter(province %notin% c("Abroad [Province: Mongolia]", "NIU (not in universe) [Province: Mongolia]"))
sum(lev1$urban*lev1$pop)
total<-lev1 %>%
  summarise(upert=sum(urban*pop), 
            weight=0.571/upert)
lev1<-lev1 %>% 
  mutate(urban=urban*total$weight,
    ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2))) %>%
  arrange(-urban) 
sum(lev1$urban*lev1$pop)
mn00<-read.dta13("mongolia.dta") %>%
  filter(year==2000)
geomig5mn<-grep("Province: Mongolia", geomigp$geomig1_p, value=TRUE)
geomig5mn[geomig5mn %notin% mn00$geomig1_p] 
mn00$geomig1_p[mn00$geomig1_p %notin% geomig5mn] 
mn00<-mn00 %>%
  left_join(lev1[,c("code", "usr", "ur")], by=c("geolev1"="code")) %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("code", "usr", "ur")], by=c("geomig1_pcode"="code")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  #prov_act_cor, prov_3_cor 0 rural, 2 capital, 3 urban, 5 abroad 9 dk-missing 
  #prov_3_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_3_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 496099,
                              ifelse(migratep=="Abroad", 496097,
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed"), NA, geomig1_pcode))), 
         prov_3_ur=ifelse(geomig1_pcode==496099, NA, #496099 NIU
                          ifelse(geomig1_pcode==496097, 5, #496097 abroad
                                 ifelse(is.na(geomig1_pcode), 9, prov_3_ur))),
         prov_3_usr=ifelse(geomig1_pcode==496099, NA,
                           ifelse(geomig1_pcode==496097, 5,
                                  ifelse(is.na(geomig1_pcode), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==496097, 5, 
                             ifelse(geolev1 %in% c(496099, NA), 9,
                                    ifelse(geolev1==496020, 2, #496020 ulaanbaatar, the capital 
                                           ifelse(geolev1 %notin% c(496097, 496099, NA, 496020) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(496097, 496099, NA, 496020) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode==496099, NA,
                           ifelse(geomig1_pcode==496020, 2, 
                                  ifelse(geomig1_pcode!=496020 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=496020 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=496020 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=496020 & (prov_3_usr==1 | prov_3_usr==2), 3,NA)))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1) 
#%>% sample_frac(0.1)
write.dta(mn00, "/asia calibrate rates/3-year in/MN_2000.dta")
write.dta(mn00, "/asia calibrate rates/3-year out/MN_2000.dta")

#philippine 90
ph90<-read.dta("philippine90.dta") #geomig1_p in code not string
sample<-sum(ph90$perwt)
lev1<-ph90 %>%
  group_by(geolev1) %>%
  summarise(pop=sum(perwt), 
            urban=sum(perwt[urban=="Urban"]))
total<-ph90 %>%
  summarise(upert=sum(perwt[urban=="Urban"])/sum(perwt), 
            weight=0.47/upert)
lev1<-lev1 %>%
  mutate(urban=urban/pop*total$weight, 
         pop=pop/sample) %>%
  arrange(-urban) %>%
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
ph90<-ph90 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  rename(geomig1_pcode=geomig1_p) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  #prov_act_cor, prov_3_cor 0 rural, 2 capital, 3 urban, 5 abroad 9 dk-missing 
  #prov_3_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_3_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 608099,
                              ifelse(migratep=="Abroad", 608097,
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed"), 608098, geomig1_pcode))),
         prov_3_ur=ifelse(geomig1_pcode==608097, 5, #608097 abroad
                                 ifelse(geomig1_pcode %in% c(608098, NA), 9, prov_3_ur)), #417098 unknown
         prov_3_usr=ifelse(geomig1_pcode==608097, 5,
                                  ifelse(geomig1_pcode %in% c(608098, NA), 9, prov_3_usr)),
         prov_act_cor=ifelse(geolev1==608097, 5, 
                             ifelse(geolev1 %in% c(608098, NA), 9,
                                    ifelse(geolev1 %in% c(608039,608074, 608075, 608076), 2, #manila, the capital 
                                           ifelse(geolev1 %notin% c(608039,608097, 608098, NA, 608074, 608075, 608076) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(608039,608097, 608098, NA, 608074, 608075, 608076) & (prov_act_usr==1 | prov_act_usr==2), 3,NA))))),
         prov_3_cor=ifelse(geomig1_pcode %in% c(608039,608074, 608075, 608076), 2, 
                                  ifelse(geomig1_pcode %notin% c(608039,608074, 608075, 608076) & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode %notin% c(608039,608074, 608075, 608076) & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode %notin% c(608039,608074, 608075, 608076) & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode %notin% c(608039,608074, 608075, 608076) & (prov_3_usr==1 | prov_3_usr==2), 3,NA))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1) 
#%>%sample_frac(0.05)
write.dta(ph90, "/asia calibrate rates/3-year in/PH_1990.dta")
write.dta(ph90, "/asia calibrate rates/3-year out/PH_1990.dta")

#thailand70
th70<-read.dta("thai70.dta")
geomig_pth<-grep("Province: Thailand", geomigp$geomig1_p, value=TRUE)
geomig_pth[geomig_pth %notin% unique(th70$geomig1_p)] 
th70$geomig1_p[th70$geomig1_p %notin% geomig_pth]
total<-th70 %>%
  summarise(upert=sum(urban=="Urban")/length(urban),
            weight=0.209/upert)
lev1<-th70 %>%
  group_by(geolev1) %>%
  summarise(uperc1=sum(urban=="Urban")/length(urban)*total$weight, 
            pop=length(pernum)) %>%
  ungroup() %>%
  mutate(pop=pop/sum(pop)) %>%
  arrange(-uperc1) %>%
  #ur 0 rural 1 urban, usr 0 rural, 1 semi-urban, 2 urban
  mutate(ur=ifelse(uperc1<=0.5, 0, 1),  
         usr=ifelse(uperc1<=0.5, 0, 
                    ifelse(uperc1>0.5 & uperc1<=0.85, 1, 2)))
th70<-th70 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  #prov_act_cor, prov_3_cor 0 rural, 2 capital, 3 other urban, 4 semi-urban, 5 abroad 9 dk-missing 
  #prov_3_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_3_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 764999,
                              ifelse(migratep=="Abroad", 764997,
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed"), 764998, geomig1_pcode))),
         prov_3_ur=ifelse(geomig1_pcode %in% c(764097, 764999), NA, #764097 same province
                          ifelse(geomig1_pcode==764997, 5,
                                 ifelse(geomig1_pcode %in% c(764098, 764998, NA), 9, prov_3_ur))), #764098 unknown but within thailand, 764998 unknown
         prov_3_usr=ifelse(geomig1_pcode %in% c(764097, 764999), NA,
                           ifelse(geomig1_pcode==764997, 5,
                                  ifelse(geomig1_pcode %in% c(764098, 764998, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==764997, 5, 
                             ifelse(geolev1 %in% c(764098, 764998, 764999, NA), 9,
                                    ifelse(geolev1==764010, 2, 
                                           ifelse(geolev1 %notin% c(764997, 764098, 764998, 764999, NA, 764010) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(764997, 764098, 764998, 764999, NA, 764010) & prov_act_usr==1, 4,
                                                         ifelse(geolev1 %notin% c(764997, 764098, 764998, 764999, NA, 764010) & prov_act_usr==2, 3,NA)))))),
         prov_3_cor=ifelse(geomig1_pcode %in% c(764097, 764999), NA,
                           ifelse(geomig1_pcode==764010, 2, 
                                  ifelse(geomig1_pcode!=764010 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=764010 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=764010 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=764010 & prov_3_usr==1, 4,
                                                              ifelse(geomig1_pcode!=764010 & prov_3_usr==2, 3,NA))))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1) 
#%>%sample_frac(0.05)
write.dta(th70, "/asia calibrate rates/3-year in/TH_1970.dta")
write.dta(th70, "/asia calibrate rates/3-year out/TH_1970.dta")

#thailand80
th80<-read.dta("thai80.dta")
geomig_pth<-grep("Province: Thailand", geomigp$geomig1_p, value=TRUE)
geomig_pth[geomig_pth %notin% unique(th80$geomig1_p)] 
th80$geomig1_p[th80$geomig1_p %notin% geomig_pth]
WUP=0.268
total<-th80 %>%
  summarise(upert=sum(urban=="Urban")/length(urban),
            weight=0.268/upert)
lev1<-th80 %>%
  group_by(geolev1) %>%
  summarise(urban80=sum(urban=="Urban")/length(urban), 
            pop80=length(pernum)) %>%
  ungroup() %>%
  mutate(pop80=pop80/sum(pop80)) %>%
  arrange(-urban80) %>%
  rename(urban=urban80, pop=pop80)
repeat {
  print(WUP-sum(lev1$urban*lev1$pop))
  lev1=lev1 %>%
    mutate(weight=WUP-sum(lev1$urban*lev1$pop), 
           urban=urban*(1+weight),
           uperc1a=ifelse(urban>1, (urban-1)*pop, 0), 
           popa=ifelse(urban>1, pop, 0), 
           popa=sum(popa), 
           urban=ifelse(urban<1, urban*(1+sum(uperc1a)*(1/(1-popa))), 1), 
           urban=ifelse(urban>1, 1, urban))
  if (WUP-sum(lev1$urban*lev1$pop) < 0.0000001){
    break
  }
}
sum(lev1$urban*lev1$pop)
lev1<-lev1 %>%
  #ur 0 rural 1 urban, usr 0 rural, 1 semi-urban, 2 urban
  mutate(ur=ifelse(urban<=0.5, 0, 1),  
         usr=ifelse(urban<=0.5, 0, 
                    ifelse(urban>0.5 & urban<=0.85, 1, 2)))
th80<-th80 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  #prov_act_cor, prov_3_cor 0 rural, 2 capital, 3 other urban, 4 semi-urban, 5 abroad 9 dk-missing 
  #prov_3_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_3_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 764999,
                              ifelse(migratep=="Abroad", 764997,
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed"), 764998, geomig1_pcode))),
         prov_3_ur=ifelse(geomig1_pcode %in% c(764097, 764999), NA, 
                          ifelse(geomig1_pcode==764997, 5,
                                 ifelse(geomig1_pcode %in% c(764098, 764998, NA), 9, prov_3_ur))),
         prov_3_usr=ifelse(geomig1_pcode %in% c(764097, 764999), NA,
                           ifelse(geomig1_pcode==764997, 5,
                                  ifelse(geomig1_pcode %in% c(764098, 764998, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==764997, 5, 
                             ifelse(geolev1 %in% c(764098, 764998, 764999, NA), 9,
                                    ifelse(geolev1==764010, 2, 
                                           ifelse(geolev1 %notin% c(764997, 764098, 764998, 764999, NA, 764010) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(764997, 764098, 764998, 764999, NA, 764010) & prov_act_usr==1, 4,
                                                         ifelse(geolev1 %notin% c(764997, 764098, 764998, 764999, NA, 764010) & prov_act_usr==2, 3,NA)))))),
         prov_3_cor=ifelse(geomig1_pcode %in% c(764097, 764999), NA,
                           ifelse(geomig1_pcode==764010, 2, 
                                  ifelse(geomig1_pcode!=764010 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=764010 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=764010 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=764010 & prov_3_usr==1, 4,
                                                              ifelse(geomig1_pcode!=764010 & prov_3_usr==2, 3,NA))))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, 
                        ifelse(migyrs1=="NIU (not in universe)", 1, migyrs1)),
         migyrs1=as.integer(migyrs1)-1) 
#%>%sample_frac(0.1)
write.dta(th80, "/asia calibrate rates/3-year in/TH_1980.dta")
write.dta(th80, "/asia calibrate rates/3-year out/TH_1980.dta")

#thailand90
th90<-read.dta("thai90.dta")
geomig_pth<-grep("Province: Thailand", geomigp$geomig1_p, value=TRUE)
geomig_pth[geomig_pth %notin% unique(th90$geomig1_p)] 
th90$geomig1_p[th90$geomig1_p %notin% geomig_pth]
th90$migyrs1<-as.character(th90$migyrs1)
#randomly assign those with migyrs1=="less than 5 years" as "3 years"
values<-c("3", "More than 5 years")
lessthan5<-th90 %>%
  filter(migyrs1=="Less than 5 years")
lessthan5$values[sample(1:nrow(lessthan5), nrow(lessthan5), FALSE)] <- rep(values, c(floor(length(lessthan5$country)*0.6), length(lessthan5$country)-floor(length(lessthan5$country)*0.6)))
lessthan5<-lessthan5 %>%
  select(-migyrs1) %>%
  rename(migyrs1=values) %>%
  select(country:geomig1_p, migyrs1, mig1_p_th)
th90<-th90 %>%
  filter(migyrs1!="Less than 5 years") %>%
  bind_rows(lessthan5) %>%
  arrange(serial, pernum)
table(th90$migyrs1)
total<-th90 %>%
  summarise(upert=sum(urban=="Urban")/length(urban),
            weight=0.294/upert)
lev1<-th90 %>%
  group_by(geolev1) %>%
  summarise(uperc1=(sum(urban=="Urban")/length(urban))*total$weight, 
            pop=length(pernum)) %>%
  ungroup() %>%
  mutate(pop=pop/sum(pop)) %>%
  arrange(-uperc1) %>%
  #ur 0 rural 1 urban, usr 0 rural, 1 semi-urban, 2 urban
  mutate(ur=ifelse(uperc1<=0.5, 0, 1),  
         usr=ifelse(uperc1<=0.5, 0, 
                    ifelse(uperc1>0.5 & uperc1<=0.85, 1, 2)))
th90<-th90 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  #prov_act_cor, prov_3_cor 0 rural, 2 capital, 3 other urban, 4 semi-urban, 5 abroad 9 dk-missing 
  #prov_3_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_3_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 764999,
                              ifelse(migratep=="Abroad", 764997,
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed"), 764998, geomig1_pcode))),
         prov_3_ur=ifelse(geomig1_pcode %in% c(764097, 764999), NA, 
                          ifelse(geomig1_pcode==764997, 5,
                                 ifelse(geomig1_pcode %in% c(764098, 764998, NA), 9, prov_3_ur))),
         prov_3_usr=ifelse(geomig1_pcode %in% c(764097, 764999), NA,
                           ifelse(geomig1_pcode==764997, 5,
                                  ifelse(geomig1_pcode %in% c(764098, 764998, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==764997, 5, 
                             ifelse(geolev1 %in% c(764098, 764998, 764999, NA), 9,
                                    ifelse(geolev1==764010, 2, 
                                           ifelse(geolev1 %notin% c(764997, 764098, 764998, 764999, NA, 764010) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(764997, 764098, 764998, 764999, NA, 764010) & prov_act_usr==1, 4,
                                                         ifelse(geolev1 %notin% c(764997, 764098, 764998, 764999, NA, 764010) & prov_act_usr==2, 3,NA)))))),
         prov_3_cor=ifelse(geomig1_pcode %in% c(764097, 764999), NA,
                           ifelse(geomig1_pcode==764010, 2, 
                                  ifelse(geomig1_pcode!=764010 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=764010 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=764010 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=764010 & prov_3_usr==1, 4,
                                                              ifelse(geomig1_pcode!=764010 & prov_3_usr==2, 3,NA))))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, migyrs1)) %>%
  select(-regnth, -edattaind, -migratep) %>%
  mutate(migyrs1=ifelse(migyrs1=="Less than 1 year", 0, 
                        ifelse(migyrs1=="1 year (or 1 year or less)", 1, 
                               ifelse(migyrs1=="2 years", 2, 
                                      ifelse(migyrs1=="3", 3, 
                                             ifelse(migyrs1=="4", 4, 
                                                    ifelse(migyrs1=="More than 5 years", 5, 99))))))) 
#%>%sample_frac(0.1)
write.dta(th90, "/asia calibrate rates/3-year in/TH_1990.dta")
write.dta(th90, "/asia calibrate rates/3-year out/TH_1990.dta")

#thailand00
th00<-read.dta("thai00.dta")
geomig_pth<-grep("Province: Thailand", geomigp$geomig1_p, value=TRUE)
geomig_pth[geomig_pth %notin% unique(th00$geomig1_p)] 
th00$geomig1_p[th00$geomig1_p %notin% geomig_pth]
th00$migyrs1<-as.character(th00$migyrs1)
#randomly assign those with migyrs1=="less than 5 years" as "3 years"
values<-c("3", "More than 5 years")
lessthan5<-th00 %>%
  filter(migyrs1=="Less than 5 years")
lessthan5$values[sample(1:nrow(lessthan5), nrow(lessthan5), FALSE)] <- rep(values, c(26660, 17774))
lessthan5<-lessthan5 %>%
  select(-migyrs1) %>%
  rename(migyrs1=values) %>%
  select(country:geomig1_p, migyrs1, mig1_p_th)
th00<-th00 %>%
  filter(migyrs1!="Less than 5 years") %>%
  bind_rows(lessthan5) %>%
  arrange(serial, pernum)
table(th00$migyrs1)
total<-th00 %>%
  summarise(upert=sum(urban=="Urban")/length(urban),
            weight=0.314/upert)
lev1<-th00 %>%
  group_by(geolev1) %>%
  summarise(uperc1=sum(urban=="Urban")/length(urban), 
            pop=length(pernum)) %>%
  ungroup() %>%
  mutate(pop=pop/sum(pop)) %>%
  arrange(-uperc1) %>%
  #ur 0 rural 1 urban, usr 0 rural, 1 semi-urban, 2 urban
  mutate(ur=ifelse(uperc1<=0.5, 0, 1),  
         usr=ifelse(uperc1<=0.5, 0, 
                    ifelse(uperc1>0.5 & uperc1<=0.85, 1, 2)))
th00<-th00 %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by="geolev1") %>%
  rename(prov_act_ur=ur, prov_act_usr=usr) %>%
  dplyr::left_join(geomigp, by="geomig1_p") %>%  
  rename(geomig1_pcode=code) %>%
  mutate(geomig1_pcode=as.integer(geomig1_pcode)) %>%
  left_join(lev1[,c("geolev1", "usr", "ur")], by=c("geomig1_pcode"="geolev1")) %>%
  rename(prov_3_ur=ur, prov_3_usr=usr) %>%
  #prov_act_cor, prov_3_cor 0 rural, 2 capital, 3 other urban, 4 semi-urban, 5 abroad 9 dk-missing 
  #prov_3_usr, prov_act_usr 0 rural, 1 semi-urban, 2 urban 5 abroad 9 unknown
  #prov_3_ur, prov_act_ur 0 rural, 1 urban 5 abroad 9 unknown
  mutate(caseid=(serial*100) + pernum,
         geomig1_pcode=ifelse(migratep %in% c("NIU (not in universe)", "Same major administrative unit", "Same major, same minor administrative unit"), 764999,
                              ifelse(migratep=="Abroad", 764997,
                                     ifelse(migratep %in% c("Not reported/missing", "Response suppressed"), 764998, geomig1_pcode))),
         prov_3_ur=ifelse(geomig1_pcode %in% c(764097, 764999), NA, 
                          ifelse(geomig1_pcode==764997, 5,
                                 ifelse(geomig1_pcode %in% c(764098, 764998, NA), 9, prov_3_ur))),
         prov_3_usr=ifelse(geomig1_pcode %in% c(764097, 764999), NA,
                           ifelse(geomig1_pcode==764997, 5,
                                  ifelse(geomig1_pcode %in% c(764098, 764998, NA), 9, prov_3_usr))),
         prov_act_cor=ifelse(geolev1==764997, 5, 
                             ifelse(geolev1 %in% c(764098, 764998, 764999, NA), 9,
                                    ifelse(geolev1==764010, 2, 
                                           ifelse(geolev1 %notin% c(764997, 764098, 764998, 764999, NA, 764010) & prov_act_usr==0, 0, 
                                                  ifelse(geolev1 %notin% c(764997, 764098, 764998, 764999, NA, 764010) & prov_act_usr==1, 4,
                                                         ifelse(geolev1 %notin% c(764997, 764098, 764998, 764999, NA, 764010) & prov_act_usr==2, 3,NA)))))),
         prov_3_cor=ifelse(geomig1_pcode %in% c(764097, 764999), NA,
                           ifelse(geomig1_pcode==764010, 2, 
                                  ifelse(geomig1_pcode!=764010 & prov_3_usr==5, 5,
                                         ifelse(geomig1_pcode!=764010 & prov_3_usr==9, 9,
                                                ifelse(geomig1_pcode!=764010 & prov_3_usr==0, 0,
                                                       ifelse(geomig1_pcode!=764010 & prov_3_usr==1, 4,
                                                              ifelse(geomig1_pcode!=764010 & prov_3_usr==2, 3,NA))))))),
         educ=as.integer(edattain),
         educ=ifelse(educ==1, NA, 
                     ifelse(educ==2, 0, 
                            ifelse(educ==3, 1, 
                                   ifelse(educ>=4 & educ<=5, 2, NA)))),
         age=as.integer(age)-1,
         age=ifelse(age>100, NA, age),
         age2=car::recode(age, "0:4=1;5:9=2;10:14=3;15:19=4;20:24=8;25:29=9;30:34=10;35:39=11;40:44=12;45:49=13;50:54=14;55:59=15;
                         60:64=16;65:69=17;70:74=18;75:79=19;else=20"),
         migyrs1=ifelse(migyrs1=="Unknown", NA, migyrs1)) %>%
  select(-regnth, -edattaind, -migratep) %>%
  mutate(migyrs1=ifelse(migyrs1=="Less than 1 year", 0, 
                        ifelse(migyrs1=="1 year (or 1 year or less)", 1, 
                               ifelse(migyrs1=="2 years", 2, 
                                      ifelse(migyrs1=="3", 3, 
                                             ifelse(migyrs1=="4", 4, 
                                                    ifelse(migyrs1=="More than 5 years", 5, 99))))))) 
#%>%sample_frac(0.05)
write.dta(th00, "/asia calibrate rates/3-year in/TH_2000.dta")
write.dta(th00, "/asia calibrate rates/3-year out/TH_2000.dta")
